export interface IBill {
  id: number;
  doc_start_date: string;
  doc_end_date: string;
  date_modified: string;
  cbr_status: number;
  read_status: string;
}

export interface IBillDetails {
  totalCount: number;
  totalBillings: TotalBillings;
  billings: Billing[];
}

export interface Billing {
  id: number;
  type: string;
  billingNumber: string;
  terms: string;
  transactionDate: string;
  transactionMonth: string;
  dueDate: string;
  docStartDate: string;
  docEndDate: string;
  docNumber: string;
  tradeDiscount: string;
  centralDropDiscount: string;
  centralTlcDiscount: string;
  otherSpecialDiscount: string;
  irNumber: string;
  vat: string;
  amount: string;
  ewt: string;
  netAmount: string;
  dateModified: string;
  cbrStatus: string;
  currency: string;
  poNumber: string;
  isRead: boolean;
  netsuiteId: null;
  lastModifiedDate: string;
  createdAt: string;
  updatedAt: string;
  counterReceiptNumber: string;
  supplierInvoiceReference: string;
  grossAmount: string;
  withHoldingTax: string;
  vendorId: number;
  subsidiaryId: number;
  paymentId: number;
  warehouseLocationId: number;
  vendor: Vendor;
}

export interface Vendor {
  id: number;
  name: string;
  netsuiteId: null;
  lastModifiedDate: string;
  createdAt: string;
  updatedAt: string;
}

export interface TotalBillings {
  grossAmount: string;
  vat: string;
  withHoldingTax: string;
  netAmount: string;
}
