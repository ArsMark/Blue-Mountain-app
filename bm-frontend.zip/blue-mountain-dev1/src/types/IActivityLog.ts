export interface IActivityLog {
    totalCount:   number;
    activityLogs: ActivityLog[];
}

export interface ActivityLog {
    id:        number;
    action:    string;
    createdAt: string;
    updatedAt: string;
    userId:    number;
    user:      User;
}

export interface User {
    email: string;
    role:  string;
}
