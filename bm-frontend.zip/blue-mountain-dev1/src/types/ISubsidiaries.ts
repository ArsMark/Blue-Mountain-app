export interface ISubsidiaries {
    totalCount:   number;
    subsidiaries: Subsidiary[];
}

export interface Subsidiary {
    id:         number;
    name:       string;
    logo:       string;
    netsuiteId: null;
    createdAt:  string;
    updatedAt:  string;
}
