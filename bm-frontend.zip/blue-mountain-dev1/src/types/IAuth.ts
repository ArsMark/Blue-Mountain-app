

export interface IAuth {
    id:    number;
    email: string;
    role: string;
    firstName: string
    lastName: string
    iat:   number;
    exp:   number;
}
