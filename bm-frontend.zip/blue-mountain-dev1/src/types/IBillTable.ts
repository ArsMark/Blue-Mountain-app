export interface IBillTable {
    totalCount: number;
    totalBillings: TotalBillings
    billings:   Billing[];
}

interface TotalBillings {
    amount: string
    vat: string
    ewt: string
    netAmount: string
}

export interface Billing {
    transactionMonth: string;
    startDate:     string;
    endDate:       string;
    dateModified:     string;
    cbrStatus:        string;
    isRead: number;
    vendorName: string;
    vendorId: number;
}