export interface INotification {
    totalCount:    number;
    notifications: Notification[];
}

export interface Notification {
    id:          number;
    title:       string;
    description: string;
    type:        string;
    createdAt:   string;
    updatedAt:   string;
}
