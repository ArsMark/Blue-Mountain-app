export interface IModule {
    [key: string]: any
    purchaseOrders:             number;
    itemReceipts:               number;
    vendorReturnAuthorizations: number;
    itemFulfillments:           number;
    billings:                   number;
    payments:                   number;
    debitCreditMemos:           number;
    creditMemos:                number;
}
