export interface IUsersTable {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  vendorId: number | null;
  createdAt: string;
  updatedAt: string;
}
