export interface IDepartment {
    totalCount:  number;
    departments: Department[];
}

export interface Department {
    id:        number;
    name:      string;
    email:     string;
    createdAt: string;
    updatedAt: string;
}
