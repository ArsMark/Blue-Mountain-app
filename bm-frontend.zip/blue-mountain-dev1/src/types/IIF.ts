export interface IItemFulfillmentTable {
  totalCount:       number;
  itemFulfillments: ItemFulfillment[];
}

export interface ItemFulfillment {
  id:                    number;
  netsuiteId:            null;
  fulfillmentDate:       string;
  itemFulFillmentNumber: number;
  documetStatus:         string;
  warehouseLocation:     WarehouseLocation;
  isRead:                boolean;
  pullOutDate: string;
  totalQuantity: number
  vraNumber: string;
  createdAt:             string;
  updatedAt:             string;
  vendorId:              number;
  subsidiaryId:          number;
  vendor:                Subsidiary;
  subsidiary:            Subsidiary;
  items:                 Item[];
}

interface WarehouseLocation {
  address: string
  name: string
  id: number

}

export interface Item {
  id:                number;
  barcode:           string;
  name:              string;
  description:       string;
  cost:              string;
  isRead:            boolean;
  netsuiteId:        null;
  createdAt:         string;
  updatedAt:         string;
  subsidiaryId:      number;
  itemFulfillmentId: number;
}

export interface Subsidiary {
  id:         number;
  name:       string;
  logo?:      string;
  netsuiteId: null;
  createdAt:  string;
  updatedAt:  string;
}

export interface ItemFulfillmentDetails {
  id:                    number;
  netsuiteId:            null;
  fulfillmentDate:       string;
  itemFulFillmentNumber: number;
  documetStatus:         string;
  isRead:                boolean;
  pullOutDate:           string;
  createdAt:             string;
  updatedAt: string;
  approvedBy: string
  preparedBy: string
  vendorId:              number;
  subsidiaryId:          number;
  subsidiary:            Subsidiary;
  vendor:                Subsidiary;
  srsNo:                 String,
  location:              String,
  siteAddress:           String,
  itemFulfillmentItems:  ItemFulfillmentItem[];
}


export interface ItemFulfillmentItem {
  id:                number;
  netsuiteId: null;
  grossNet:          string;
  quantity:          number;
  totalAmount:       string;
  createdAt:         string;
  updatedAt:         string;
  itemId:            number;
  itemFulfillmentId: number;
  subsidiaryId:      number;
  item:              Item;
}

