export function formatType(text: string): string {
  if (text === "billing") {
    return "/bill"
  }
  if (text === "debit credit memo") {
    return "/debit-credit"
  }

  if (text === "credit memo") {
    return "/credit"
  }
  const modifiedText = text.replace(/\s/g, '-');
  return `/${modifiedText}`;
}