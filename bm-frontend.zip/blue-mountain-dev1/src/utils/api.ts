import axios from "axios";
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL as string,
  // baseURL: "http://13.215.209.40"
});


export default api;