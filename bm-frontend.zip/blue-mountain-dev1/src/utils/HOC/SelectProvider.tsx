import { createContext, useContext, useState } from "react";

export const SelectContext = createContext({
  type: "1",
  setType: (val: string) => {},
});

export const useSelectContext = () => {
  return useContext(SelectContext);
};

const SelectProvider = ({ children }: { children: React.ReactNode }) => {
  const [type, setType] = useState("1");

  return (
    <SelectContext.Provider value={{ type, setType }}>
      {children}
    </SelectContext.Provider>
  );
};

export default SelectProvider;
