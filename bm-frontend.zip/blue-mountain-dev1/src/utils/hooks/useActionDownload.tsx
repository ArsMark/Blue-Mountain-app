import { useMutation, useQueryClient } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";
import toast from "react-hot-toast";

export const useActionDownload = () => {
  const queryClient = useQueryClient();
  return useMutation(
    (payload) => {
      return api.post(`/api/activityLogs`, payload, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      });
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["activityLog"] });
      },
      onError: async (err: any, context: any) => {
        await queryClient.setQueryData(
          ["action-download"],
          context.previousData
        );
        toast.error("Download Error");
      },
      onSettled: async () => {
        await queryClient.invalidateQueries({
          queryKey: ["action-download"],
        });
      },
    }
  );
};
