import { useQuery } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";
import { FormValues } from "@/pages/item-fulfillment";
import {
  IItemFulfillmentTable,
  ItemFulfillment,
  ItemFulfillmentDetails,
} from "@/types/IIF";
import { format } from "date-fns";

interface PaginationState {
  pageIndex: number;
  pageSize: number;
}

export const useItemFulfillmentTable = (
  page: PaginationState,
  FormValue: FormValues,
  searchText: string,
  isCsvDownload: boolean,
  setIsCsvDownload: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const fetcher = (
    page: PaginationState,
    FormValue: FormValues,
    searchText: string
  ): Promise<IItemFulfillmentTable> => {
    return api
      .get("/api/items/fulfillments", {
        params: {
          ...(!!isCsvDownload && { csv: true }),
          ...(!!searchText && { q: searchText }),
          page: page?.pageIndex + 1,
          limit: page.pageSize ?? 10,
          subsidiaryId: getCookie("subsidiaryId"),
          ...(!!FormValue.vendor_name && { vendorName: FormValue.vendor_name }),
          ...(!!FormValue.document_status && {
            documentStatus: FormValue.document_status,
          }),
          ...(!!FormValue.if_number && {
            itemFulFillmentNumber: FormValue.if_number,
          }),
          ...(!!FormValue.pullout_date_from &&
            !!FormValue.pullout_date_to && {
              pullOutDate: `${format(
                FormValue.pullout_date_from,
                "yyyy-MM-dd"
              )},${format(FormValue.pullout_date_to, "yyyy-MM-dd")}`,
            }),
          ...(!!FormValue.fulfillment_date_from &&
            !!FormValue.fulfillment_date_to && {
              fulfillmentDate: `${format(
                FormValue.fulfillment_date_from,
                "yyyy-MM-dd"
              )},${format(FormValue.fulfillment_date_to, "yyyy-MM-dd")}`,
            }),
          ...(!!FormValue.read_status &&
            FormValue.read_status !== "all" && {
              isRead: FormValue.read_status,
            }),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
        ...(!!isCsvDownload && { responseType: "blob" }),
      })
      .then((res) => {
        if (isCsvDownload) {
          const href = URL.createObjectURL(res.data);
          const link = document.createElement("a");
          link.href = href;
          link.setAttribute("download", `Item Fulfillment.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(href);
          setIsCsvDownload(false);
        }
        return res.data;
      });
  };
  return useQuery({
    queryKey: ["item-fulfillment", page, FormValue, searchText, isCsvDownload],
    queryFn: () => fetcher(page, FormValue, searchText),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useItemFulfillmentDetails = (id: number) => {
  const fetcher = (id: number): Promise<ItemFulfillmentDetails> => {
    return api
      .get(`/api/items/fulfillments/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["item-fulfillment-details", id],
    queryFn: () => fetcher(id),
    keepPreviousData: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
    enabled: id > 0,
  });
};

export const useItemFulfillmentStatus = () => {
  const fetcher = (): Promise<Array<string>> => {
    return api
      .get(`/api/items/fulfillments/documentStatuses`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["if-status"],
    queryFn: fetcher,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
