import { IActivityLog } from "@/types/IActivityLog";
import { useQuery } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";

export const useActivityLog = () => {
  const fetcher = (): Promise<IActivityLog> => {
    return api
      .get(`/api/activityLogs/`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["activityLog"],
    queryFn: fetcher,
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
