import { getCookie } from "cookies-next";
import api from "../api";
import { useQuery } from "@tanstack/react-query";

export const usePostingType = () => {
  const fetcher = (): Promise<Array<string>> => {
    return api
      .get(`/api/debitCreditMemos/posting-types`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["posting-type"],
    queryFn: fetcher,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
