import { getCookie } from "cookies-next";
import api from "../api";
import { useQuery } from "@tanstack/react-query";

interface VendorData {
  id: number;
  name: string;
}

export const useVendorDetails = (id: string | string[] | undefined) => {
  const fetcher = (id: string | string[] | undefined): Promise<VendorData> => {
    return api
      .get(`/api/vendors/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["vendor", id],
    queryFn: () => fetcher(id),
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
