import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";
import {
  IFormValues,
  IPurchaseOrderDetails,
  IPurchaseOrderTable,
  PurchaseOrder,
} from "@/types/IPurchase";
import { format } from "date-fns";

interface Pagination {
  pageIndex: number;
  pageSize: number;
}

export const usePurchaseOrderTable = (
  FormValues: Partial<IFormValues>,
  page: Pagination,
  search: string,
  isCsvDownload: boolean,
  setIsCsvDownload: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const fetcher = (
    FormValues: Partial<IFormValues>,
    page: Pagination,
    search: string
  ): Promise<IPurchaseOrderTable> => {
    return api
      .get(`api/purchaseOrders`, {
        params: {
          ...(!!isCsvDownload && { csv: true }),
          ...(!!search && { q: search }),
          page: page.pageIndex + 1,
          limit: page.pageSize ?? 10,
          subsidiaryId: getCookie("subsidiaryId"),
          ...(!!FormValues.po_number && { poNumber: FormValues.po_number }),
          ...(!!FormValues.receipt_date_from &&
            !!FormValues.receipt_date_to && {
              poDateRange: `${format(
                FormValues.receipt_date_from,
                "yyyy-MM-dd"
              )},${format(FormValues.receipt_date_to, "yyyy-MM-dd")}`,
            }),
          ...(!!FormValues.delivery_date_from &&
            !!FormValues.delivery_date_to && {
              deliveryDateRange: `${format(
                FormValues.delivery_date_from,
                "yyyy-MM-dd"
              )},${format(FormValues.delivery_date_to, "yyyy-MM-dd")}`,
            }),
          ...(!!FormValues.warehouse_location && {
            warehouseLocationId: FormValues.warehouse_location,
          }),
          ...(!!FormValues.vendor_name && {
            vendorName: FormValues.vendor_name,
          }),
          ...(!!FormValues.document_status && {
            documentStatus: FormValues.document_status,
          }),
          ...(!!FormValues?.read_status &&
            FormValues.read_status !== "all" && {
              isRead: FormValues.read_status,
            }),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
        ...(!!isCsvDownload && { responseType: "blob" }),
      })
      .then((res) => {
        if (isCsvDownload) {
          const href = URL.createObjectURL(res.data);
          const link = document.createElement("a");
          link.href = href;
          link.setAttribute("download", `Purchase Order.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(href);
          setIsCsvDownload(false);
        }
        return res.data;
      });
  };
  return useQuery({
    queryKey: ["purchase-order", FormValues, page, search, isCsvDownload],
    queryFn: () => fetcher(FormValues, page, search),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const usePurchaseOrderDetails = (id: number) => {
  const fetcher = (id: number): Promise<IPurchaseOrderDetails> => {
    return api
      .get(`/api/purchaseOrders/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["purchase-order-details", id],
    queryFn: () => fetcher(id),
    enabled: id > 0,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const usePurchaseOrderStatus = () => {
  const fetcher = (): Promise<Array<string>> => {
    return api
      .get(`/api/purchaseOrders/documentStatuses`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["purchase-order-status"],
    queryFn: () => fetcher(),
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
