import { getCookie } from "cookies-next";
import api from "../api";
import { useInfiniteQuery } from "@tanstack/react-query";
import { INotification } from "@/types/INotification";

export const useNotification = (page: number) => {
  const fetcher = (page: number): Promise<INotification> => {
    return api
      .get(`api/notifications`, {
        params: {
          page: page,
          limit: 10,
          subsidiaryId: getCookie("subsidiaryId"),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useInfiniteQuery({
    queryKey: ["notifications"],
    queryFn: () => fetcher(page),
    getNextPageParam: () => page,
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
