import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";
import {
  IItemReceiptDetails,
  IItemReceiptTable,
  ItemReceipt,
} from "@/types/ItemReceipt";
import { FormValues } from "@/pages/item-receipt";
import { format } from "date-fns";

interface PaginationState {
  pageIndex: number;
  pageSize: number;
}

export const useItemReceiptTable = (
  formValue: FormValues,
  page: PaginationState,
  searchText: string,
  isCsvDownload: boolean,
  setIsCsvDownload: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const fetcher = (
    formValue: FormValues,
    page: PaginationState,
    searchText: string
  ): Promise<IItemReceiptTable> => {
    return api
      .get("/api/items/receipts", {
        params: {
          ...(!!isCsvDownload && { csv: true }),
          ...(!!searchText && { q: searchText }),
          page: page.pageIndex + 1,
          subsidiaryId: getCookie("subsidiaryId"),
          limit: page.pageSize ?? 10,
          ...(!!formValue.po_number && {
            poNumber: formValue.po_number,
          }),
          ...(!!formValue.vendor_name && {
            vendorName: formValue.vendor_name,
          }),
          ...(!!formValue.ir_number && {
            irNumber: formValue.ir_number,
          }),
          ...(!!formValue.warehouse_location && {
            warehouseLocationId: formValue.warehouse_location,
          }),
          ...(!!formValue.receipt_date_from &&
            !!formValue.receipt_date_to && {
              receivedDateRange: `${format(
                formValue.receipt_date_from,
                "yyyy-MM-dd"
              )},${format(formValue.receipt_date_to, "yyyy-MM-dd")}`,
            }),
          ...(!!formValue.delivery_date_from &&
            !!formValue.delivery_date_to && {
              receivedDateRange: `${format(
                formValue.delivery_date_from,
                "yyyy-MM-dd"
              )},${format(formValue.delivery_date_to, "yyyy-MM-dd")}`,
            }),

          ...(!!formValue.document_status && {
            status: formValue.document_status,
          }),
          ...(!!formValue.read_status &&
            formValue.read_status !== "all" && {
              isRead: formValue.read_status,
            }),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
        ...(!!isCsvDownload && { responseType: "blob" }),
      })
      .then((res) => {
        if (isCsvDownload) {
          const href = URL.createObjectURL(res.data);
          const link = document.createElement("a");
          link.href = href;
          link.setAttribute("download", `Item Receipt.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(href);
          setIsCsvDownload(false);
        }
        return res.data;
      });
  };
  return useQuery({
    queryKey: ["item-receipt", formValue, page, searchText, isCsvDownload],
    queryFn: () => fetcher(formValue, page, searchText),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useItemReceiptDetails = (id: number) => {
  const fetcher = (id: number): Promise<IItemReceiptDetails> => {
    return api
      .get(`/api/items/receipts/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["item-receipt-details", id],
    queryFn: () => fetcher(id),
    keepPreviousData: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
    enabled: id > 0,
  });
};

export const useItemReceiptStatus = () => {
  const fetcher = (): Promise<Array<string>> => {
    return api
      .get(`/api/items/receipts/statuses`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["item-receipt-status"],
    queryFn: fetcher,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
