import api from "../api";

export const useLogout = async (token: string) => {
  return await api.get("/api/auth/logout", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};
