import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { getCookie } from "cookies-next";
import toast from "react-hot-toast";

export const useGetUsersTable = (
  page?: number | undefined,
  searchText?: string | undefined
) => {
  const fetcher = (
    page?: number | undefined,
    searchText?: string | undefined
  ) => {
    return api
      .get("/users", {
        params: {
          search: searchText,
          limit: 5,
          page: page,
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["users", page, searchText],
    queryFn: () => fetcher(page, searchText),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useAdminVendorDetails = (id: number) => {
  const fetcher = (id: number) => {
    return api
      .get(`/users/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["users", id],
    queryFn: () => fetcher(id),
    enabled: id > 0,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useAddAdminVendor = () => {
  const queryClient = useQueryClient();
  return useMutation(
    (payload) => {
      return api.post("api/query", payload, {
        headers: { Authorization: "Bearer " + getCookie("user") },
      });
    },
    {
      onSuccess: () => {
        toast.success("Data has been added.");
        queryClient.invalidateQueries({ queryKey: ["query"] });
      },
      onError: async (err: any, context: any) => {
        await queryClient.setQueryData(["query"], context.previousData);
      },
      onSettled: async () => {
        await queryClient.invalidateQueries({ queryKey: ["query"] });
      },
    }
  );
};

export const useUpdateActionData = (id: number) => {
  const queryClient = useQueryClient();

  const updateData = async (data: string) => {
    return await api.put(`/api/query/${id}`, data, {
      headers: {
        Authorization: "Bearer " + getCookie("user"),
      },
    });
  };

  return useMutation(updateData, {
    onMutate: async (newData) => {
      await queryClient.cancelQueries(["query", newData]);
      const previousData = queryClient.getQueryData(["query", newData]);
      queryClient.setQueryData(["query", newData], newData);

      return {
        previousData,
        newData,
      };
    },
    onSuccess: () => {
      toast.success("Data has been updated.");
      queryClient.invalidateQueries({ queryKey: ["query"] });
    },
    onError: (err, newData, context) => {
      queryClient.setQueryData(
        ["query", context?.newData],
        context?.previousData
      );
    },
    onSettled: (newData) => {
      queryClient.invalidateQueries({ queryKey: ["query", newData] });
    },
  });
};

export const useDeleteAdminVendor = () => {
  const queryClient = useQueryClient();

  const deleteData = async (id: number) => {
    return await api.delete(`/api/query/${id}`, {
      headers: {
        Authorization: "Bearer " + getCookie("user"),
      },
    });
  };

  return useMutation(deleteData, {
    onMutate: async (newData) => {
      await queryClient.cancelQueries(["query", newData]);
      const previousData = queryClient.getQueryData(["query", newData]);
      queryClient.setQueryData(["query", newData], newData);
      return {
        previousData,
        newData,
      };
    },
    onSuccess: () => {
      toast.success("Data has been deleted.");
      queryClient.invalidateQueries({ queryKey: ["query"] });
    },
    onError: (err, newData, context) => {
      queryClient.setQueryData(
        ["query", context?.newData],
        context?.previousData
      );
    },
    onSettled: (newData) => {
      queryClient.invalidateQueries({ queryKey: ["query", newData] });
    },
  });
};
