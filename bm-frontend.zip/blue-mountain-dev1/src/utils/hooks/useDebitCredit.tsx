import { useQuery } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";
import { FormValues } from "@/pages/debit-credit";
import { IDebitCreditDetails, IDebitCreditTable } from "@/types/IDebitCredit";
import { format } from "date-fns";

interface PaginationState {
  pageIndex: number;
  pageSize: number;
}

export const useDebitCreditTable = (
  FormValue: FormValues,
  page: PaginationState,
  searchText: string,
  isCsvDownload: boolean,
  setIsCsvDownload: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const fetcher = (
    FormValue: FormValues | undefined,
    page: PaginationState,
    searchText: string
  ): Promise<IDebitCreditTable> => {
    return api
      .get("/api/debitCreditMemos", {
        params: {
          ...(!!isCsvDownload && { csv: true }),
          ...(!!searchText && { q: searchText }),
          page: page.pageIndex + 1,
          limit: page.pageSize ?? 10,
          subsidiaryId: getCookie("subsidiaryId"),
          ...(!!FormValue?.dm_number && {
            debitCreditMemoNumber: FormValue.dm_number,
          }),
          ...(!!FormValue?.vendorName && {
            vendorName: FormValue.vendorName,
          }),
          ...(!!FormValue?.dm_status && {
            debitCreditMemoStatus: FormValue.dm_status,
          }),
          ...(!!FormValue?.document_date_from &&
            !!FormValue.document_date_to && {
              docDateRange: `${format(
                FormValue?.document_date_from,
                "yyyy-MM-dd"
              )},${format(FormValue?.document_date_to, "yyyy-MM-dd")}`,
            }),
          ...(FormValue?.posting_type && {
            postingType: FormValue.posting_type,
          }),
          ...(!!FormValue?.read_status &&
            FormValue.read_status !== "all" && {
              isRead: FormValue.read_status,
            }),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
        ...(!!isCsvDownload && { responseType: "blob" }),
      })
      .then((res) => {
        if (isCsvDownload) {
          const href = URL.createObjectURL(res.data);
          const link = document.createElement("a");
          link.href = href;
          link.setAttribute("download", `Debit-Credit.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(href);
          setIsCsvDownload(false);
        }
        return res.data;
      });
  };
  return useQuery({
    queryKey: ["debit-credit", FormValue, page, searchText, isCsvDownload],
    queryFn: () => fetcher(FormValue, page, searchText),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useDebitCreditDetails = (id: number) => {
  const fetcher = (id: number): Promise<IDebitCreditDetails> => {
    return api
      .get(`/api/debitCreditMemos/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["debit-credit-details", id],
    queryFn: () => fetcher(id),
    keepPreviousData: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
    enabled: id > 0,
  });
};

export const useDebitCreditStatus = () => {
  const fetcher = (): Promise<Array<string>> => {
    return api
      .get(`/api/debitCreditMemos/statuses`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["debit-credit-status"],
    queryFn: fetcher,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
