import { getCookie } from "cookies-next";
import api from "../api";
import { useQuery } from "@tanstack/react-query";
import { IActivityLog } from "@/types/IActivityLog";

export const useLastLogin = () => {
  const fetcher = (): Promise<IActivityLog> => {
    return api
      .get("api/activityLogs", {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
        params: {
          page: 2,
          limit: 1,
          sort: "desc",
          q: "logged-in",
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["activityLogsLogin"],
    queryFn: fetcher,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
