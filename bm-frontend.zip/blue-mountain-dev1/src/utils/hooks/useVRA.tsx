import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";
import { IVRADetails, IVraTable } from "@/types/IVRA";
import { FormValues } from "@/pages/vendor-return-authorization";
import { format } from "date-fns";

interface Pagination {
  pageIndex: number;
  pageSize: number;
}

export const useVRATable = (
  formValue: FormValues,
  page: Pagination,
  searchText: string,
  isCsvDownload: boolean,
  setIsCsvDownload: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const fetcher = (
    formValue: FormValues,
    page: Pagination,
    searchText: string
  ): Promise<IVraTable> => {
    return api
      .get("/api/vendors/returnAuthorizations", {
        params: {
          ...(!!isCsvDownload && { csv: true }),
          ...(!!searchText && { q: searchText }),
          page: page.pageIndex + 1,
          subsidiaryId: getCookie("subsidiaryId"),
          limit: page.pageSize ?? 10,
          ...(!!formValue.document_status && {
            vraStatus: formValue.document_status,
          }),
          ...(!!formValue.warehouse_location && {
            warehouseLocationId: formValue.warehouse_location,
          }),
          ...(!!formValue.vra_number && {
            vraNumber: formValue.vra_number,
          }),
          ...(!!formValue.vendor_name && {
            vendorName: formValue.vendor_name,
          }),
          ...(!!formValue.quantity && {
            quantity: formValue.quantity,
          }),
          ...(!!formValue.total_amount && {
            totalAmount: formValue.total_amount,
          }),
          ...(!!formValue.read_status &&
            formValue.read_status !== "all" && {
              isRead: formValue.read_status,
            }),
          ...(!!formValue.pullout_date_from &&
            !!formValue.pullout_date_to && {
              pullOutDate: `${format(
                formValue.pullout_date_from,
                "yyyy-MM-dd"
              )},${format(formValue.pullout_date_to, "yyyy-MM-dd")}`,
            }),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
        ...(!!isCsvDownload && { responseType: "blob" }),
      })
      .then((res) => {
        if (isCsvDownload) {
          const href = URL.createObjectURL(res.data);
          const link = document.createElement("a");
          link.href = href;
          link.setAttribute("download", `VRA.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(href);
          setIsCsvDownload(false);
        }
        return res.data;
      });
  };
  return useQuery({
    queryKey: ["vra", formValue, page, searchText, isCsvDownload],
    queryFn: () => fetcher(formValue, page, searchText),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useVRADetails = (id: number) => {
  const fetcher = (id: number): Promise<IVRADetails> => {
    return api
      .get(`/api/vendors/returnAuthorizations/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["vra-details", id],
    queryFn: () => fetcher(id),
    keepPreviousData: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
    enabled: id > 0,
  });
};

export const useVRAStatus = () => {
  const fetcher = (): Promise<Array<string>> => {
    return api
      .get(`/api/vendors/returnAuthorizations/vraStatuses`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["vra-status"],
    queryFn: fetcher,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
