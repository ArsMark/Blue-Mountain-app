import { useQuery } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";
import { IDepartment } from "@/types/IDepartment";

export const useDepartmentEmail = () => {
  const fetcher = (): Promise<IDepartment> => {
    return api
      .get(`api/departments`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["department-email"],
    queryFn: fetcher,
    keepPreviousData: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
