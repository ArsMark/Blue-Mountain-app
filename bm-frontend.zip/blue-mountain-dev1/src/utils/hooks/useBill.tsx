import { useQuery } from "@tanstack/react-query";
import { getCookie } from "cookies-next";
import api from "../api";
import { IBillDetails } from "@/types/IBill";
import { IBillTable } from "@/types/IBillTable";
import { FormValues } from "@/pages/bill";
import { IBillModal } from "@/types/IBillModal";
import { format } from "date-fns";

interface PaginationState {
  pageIndex: number;
  pageSize: number;
}

export const useBillTable = (
  formValue: FormValues,
  page: PaginationState,
  searchText: string,
  isCsvDownload: boolean,
  setIsCsvDownload: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const fetcher = (
    formValue: FormValues | undefined,
    page: PaginationState,
    searchText: string
  ): Promise<IBillTable> => {
    return api
      .get("/api/billings/monthly", {
        params: {
          ...(!!isCsvDownload && { csv: true }),
          ...(!!searchText && { q: searchText }),
          page: page.pageIndex + 1,
          limit: page.pageSize ?? 10,
          subsidiaryId: getCookie("subsidiaryId"),
          ...(!!formValue?.vendor_name && {
            vendorName: formValue.vendor_name,
          }),
          ...(!!formValue?.document_status && {
            cbrStatus: formValue.document_status,
          }),
          ...(!!formValue?.warehouse_location && {
            warehouseLocationId: formValue.warehouse_location,
          }),
          ...(!!formValue?.post_date_from &&
            !!formValue?.post_date_to && {
              postDateRange: `${format(
                formValue?.post_date_from,
                "yyyy-MM-dd"
              )},${format(formValue?.post_date_to, "yyyy-MM-dd")}`,
            }),
          ...(!!formValue?.doc_date_from &&
            !!formValue?.doc_date_to && {
              docDateRange: `${format(
                formValue?.doc_date_from,
                "yyyy-MM-dd"
              )},${format(formValue?.doc_date_to, "yyyy-MM-dd")}`,
            }),
          ...(!!formValue?.read_status &&
            formValue.read_status !== "all" && {
              isRead: formValue.read_status,
            }),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
        ...(!!isCsvDownload && { responseType: "blob" }),
      })
      .then((res) => {
        if (isCsvDownload) {
          const href = URL.createObjectURL(res.data);
          const link = document.createElement("a");
          link.href = href;
          link.setAttribute("download", `Billings.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(href);
          setIsCsvDownload(false);
        }
        return res.data;
      });
  };
  return useQuery({
    queryKey: ["bill", formValue, page, searchText, isCsvDownload],
    queryFn: () => fetcher(formValue, page, searchText),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useBillDetails = (
  pagination: PaginationState,
  id?: string | string[] | undefined,
  subsidiaryId?: any 
) => {
  const fetcher = (
    pagination: PaginationState,
    id: string | string[] | undefined,
    subsidiaryId: number 
  ): Promise<IBillDetails> => {
    return api
      .get(`/api/billings/monthly/${id?.[0]}`, {
        params: {
          page: pagination.pageIndex + 1,
          limit: pagination.pageSize,
          vendorId: id?.[1],
          subsidiaryId: subsidiaryId
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["bill-details", pagination, id, subsidiaryId],
    queryFn: () => fetcher(pagination, id, subsidiaryId),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useBillModal = (id: number) => {
  const fetcher = (id: number): Promise<IBillModal> => {
    return api
      .get(`/api/billings/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["bill-modal", id],
    queryFn: () => fetcher(id),
    enabled: id > 0,
    keepPreviousData: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const useBillStatus = () => {
  const fetcher = (): Promise<Array<string>> => {
    return api
      .get(`/api/billings/cbrStatuses`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["bill-status"],
    queryFn: fetcher,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
