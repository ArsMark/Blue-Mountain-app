import { useRouter } from "next/router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import apiAuth from "../apiAuth";
import { setCookie } from "cookies-next";

export const useAuthLogin = () => {
  const queryClient = useQueryClient();
  const router = useRouter();
  const addData = async (data: { email: string; password: string }) => {
    const response = await apiAuth.post(`/api/auth/login`, data);
    const { accessToken } = await response.data;

    if (response.status === 200) {
      setCookie("user", accessToken);
      router.push("/select");
    } else {
      toast.error(
        "Error logging in. There's something wrong with your credentials."
      );
      throw new Error("Error logging in");
    }
  };
  return useMutation(addData, {
    onSuccess: () => {
      toast.success("Logged in successfully");
      return queryClient.invalidateQueries(["login"]);
    },
    onError: (err: any) => {
      toast.error(`${err.response.data}`);
    },
  });
};
