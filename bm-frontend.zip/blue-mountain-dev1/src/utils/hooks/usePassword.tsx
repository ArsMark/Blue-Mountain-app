import { getCookie } from "cookies-next";
import api from "../api";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";

export const useChangePassword = () => {
  const queryClient = useQueryClient();
  return useMutation(
    (payload) => {
      return api.patch("/api/users/changePassword", payload, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      });
    },
    {
      onSuccess: () => {
        toast.success("Your password has been changed.");
      },
      onError: async (err: any, context: any) => {
        await queryClient.setQueryData(
          ["change-password"],
          context.previousData
        );
        toast.error(`${err.response.data}`);
      },
      onSettled: async () => {
        await queryClient.invalidateQueries(["change-password"]);
      },
    }
  );
};
export const useResetPasswordLink = () => {
  const queryClient = useQueryClient();
  return useMutation(
    (payload) => {
      return api.post("/api/users/resetPasswordLink", payload, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      });
    },
    {
      onSuccess: () => {
        toast.success("A reset password link has been sent to your email.");
      },
      onError: async (err: any, context: any) => {
        await queryClient.setQueryData(
          ["reset-password-link"],
          context.previousData
        );
        toast.error(`${err.response.data}`);
      },
      onSettled: async () => {
        await queryClient.invalidateQueries(["reset-password-link"]);
      },
    }
  );
};

export const useResetPassword = (token?: string | string[]) => {
  const queryClient = useQueryClient();
  return useMutation(
    (payload) => {
      return api.patch("/api/users/resetPassword", payload, {
        headers: {
          Authorization: "Bearer " + token,
        },
      });
    },
    {
      onSuccess: () => {
        toast.success("Your password has been reset.");
      },
      onError: async (err: any, context: any) => {
        await queryClient.setQueryData(
          ["reset-password"],
          context.previousData
        );
        toast.error(`${err.response.data}`);
      },
      onSettled: async () => {
        await queryClient.invalidateQueries(["reset-password"]);
      },
    }
  );
};
