import { useMutation, useQueryClient } from "@tanstack/react-query";
import api from "../api";
import { getCookie } from "cookies-next";
import toast from "react-hot-toast";

export const useSendMessages = () => {
  const queryClient = useQueryClient();
  return useMutation(
    (payload) => {
      return api.post("api/messages", payload, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      });
    },
    {
      onSuccess: () => {
        toast.success("Message sent successfully");
        //refetch if there's a new data
      },
      onError: async (err: any, context: any) => {
        await queryClient.setQueryData(["api-messages"], context.previousData);
        toast.error("Error sending message");
      },
      onSettled: async () => {
        await queryClient.invalidateQueries(["api-messages"]);
      },
    }
  );
};
