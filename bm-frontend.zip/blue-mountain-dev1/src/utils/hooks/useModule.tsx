import api from "../api";
import { getCookie } from "cookies-next";
import { useQuery } from "@tanstack/react-query";
import { IModule } from "@/types/IModule";

export const useModule = () => {
  const fetcher = (): Promise<IModule> => {
    return api
      .get(`api/modules/count`, {
        params: {
          isRead: false,
          subsidiaryId: getCookie("subsidiaryId"),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data)
  };
  return useQuery({
    queryKey: ["module"],
    queryFn: fetcher,
    keepPreviousData: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
