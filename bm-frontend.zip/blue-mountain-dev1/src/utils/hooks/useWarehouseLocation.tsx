import { getCookie } from "cookies-next";
import api from "../api";
import {
  InfiniteData,
  useInfiniteQuery,
  useQuery,
} from "@tanstack/react-query";
import { IWarehouseLocationResponse } from "@/types/IWarehouseLocation";

export const useWarehouseLocationData = (
  search: string | number,
  page: number,
  subsidiaryId: any
) => {
  const fetcher = (page: number): Promise<IWarehouseLocationResponse> => {
    
    return api
      .get(`/api/warehouseLocations`, {
        params: {
          page: search ? 1 : page,
          limit: 10,
          subsidiaryId: subsidiaryId,
          ...(search && { q: search }),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useInfiniteQuery({
    queryKey: ["payment-details", search],
    queryFn: () => fetcher(page),
    getNextPageParam: () => page,
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
