import { getCookie } from "cookies-next";
import { useQuery } from "@tanstack/react-query";

import { IAuth } from "@/types/IAuth";

import api from "../api";

export const useAuthMe = () => {
  const fetcher = (): Promise<IAuth> => {
    return api
      .get("api/auth/me", {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["auth-me"],
    queryFn: fetcher,
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
