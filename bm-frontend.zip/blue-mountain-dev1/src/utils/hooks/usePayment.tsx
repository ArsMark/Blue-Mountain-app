import { getCookie } from "cookies-next";
import { format } from "date-fns";
import { useQuery } from "@tanstack/react-query";

import { FormValues } from "@/pages/payment";
import { IPaymentDetails, IPaymentTable } from "@/types/IPayment";

import api from "../api";

interface PaginationState {
  pageIndex: number;
  pageSize: number;
}

export const usePaymentTable = (
  FormValue: FormValues,
  page: PaginationState,
  searchText: string,
  isCsvDownload: boolean,
  setIsCsvDownload: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const fetcher = (
    FormValue: FormValues,
    page: PaginationState,
    searchText: string
  ): Promise<IPaymentTable> => {
    return api
      .get("/api/payments", {
        params: {
          ...(!!isCsvDownload && { csv: true }),
          ...(!!searchText && { q: searchText }),
          page: page.pageIndex + 1,
          limit: page.pageSize ?? 10,
          subsidiaryId: getCookie("subsidiaryId"),
          ...(!!FormValue.vendor_name && { vendorName: FormValue.vendor_name }),
          ...(FormValue.transaction_no && {
            transactionNo: FormValue.transaction_no,
          }),
          ...(FormValue.voucher_name && {
            voucherName: FormValue.voucher_name,
          }),
          ...(!!FormValue?.read_status &&
            FormValue.read_status !== "all" && {
              isRead: FormValue.read_status,
            }),
          ...(!!FormValue.check_date_from &&
            !!FormValue.check_date_to && {
              cvDateRange: `${format(
                FormValue.check_date_from,
                "yyyy-MM-dd"
              )},${format(FormValue.check_date_to, "yyyy-MM-dd")}`,
            }),
          ...(!!FormValue.releasing_date_from &&
            !!FormValue.releasing_date_to && {
              releaseDateRange: `${format(
                FormValue.releasing_date_from,
                "yyyy-MM-dd"
              )},${format(FormValue.releasing_date_to, "yyyy-MM-dd")}`,
            }),
        },
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
        ...(!!isCsvDownload && { responseType: "blob" }),
      })
      .then((res) => {
        if (isCsvDownload) {
          const href = URL.createObjectURL(res.data);
          const link = document.createElement("a");
          link.href = href;
          link.setAttribute("download", `Payment.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(href);
          setIsCsvDownload(false);
        }
        return res.data;
      });
  };
  return useQuery({
    queryKey: ["payment", FormValue, page, searchText, isCsvDownload],
    queryFn: () => fetcher(FormValue, page, searchText),
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};

export const usePaymentDetails = (id: number) => {
  const fetcher = (id: number): Promise<IPaymentDetails> => {
    return api
      .get(`/api/payments/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["payment-details", id],
    queryFn: () => fetcher(id),
    keepPreviousData: false,
    refetchOnWindowFocus: false,
    refetchInterval: false,
    enabled: id > 0,
  });
};
