import { CookieValueTypes, getCookie } from "cookies-next";
import api from "../api";
import { useQuery } from "@tanstack/react-query";
import { ISubsidiaries, Subsidiary } from "@/types/ISubsidiaries";

export const useSubsidiary = () => {
  const fetcher = (): Promise<ISubsidiaries> => {
    return api
      .get(`/api/subsidiaries`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data);
  };
  return useQuery({
    queryKey: ["subsidiary"],
    queryFn: fetcher,
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
export const useSubsidiaryDetails = (id: CookieValueTypes) => {
  const fetcher = (): Promise<Subsidiary> => {
    return api
      .get(`/api/subsidiaries/${id}`, {
        headers: {
          Authorization: "Bearer " + getCookie("user"),
        },
      })
      .then((res) => res.data)
  };
  return useQuery({
    queryKey: ["subsidiary-details", id],
    queryFn: fetcher,
    keepPreviousData: true,
    refetchOnWindowFocus: false,
    refetchInterval: false,
  });
};
