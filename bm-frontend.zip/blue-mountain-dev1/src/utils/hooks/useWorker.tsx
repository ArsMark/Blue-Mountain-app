import { getCookie } from "cookies-next";
import { useQuery } from "@tanstack/react-query";
import api from "../api";

export const useWorker = () => {
    const fetcher = (): Promise<any> => {
        return api
            .get("api/workers/status", {
                headers: {
                    Authorization: "Bearer " + getCookie("user"),
                },
            })
            .then((res) => res.data);
    };
    return useQuery({
        queryKey: ["get-worker"],
        queryFn: fetcher,
        keepPreviousData: false,
        refetchOnWindowFocus: false,
        refetchInterval: false,
    });
};