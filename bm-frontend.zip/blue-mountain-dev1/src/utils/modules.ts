import { CustomButtonProps } from "@/components/custom-button";

export const modules:Array<Omit<CustomButtonProps, "count"> & {key: string}> = [
    {
        key: "purchaseOrders",
        color: "blue",
        role: ['admin', 'admin-accounting', 'accounting', 'purchasing', 'vendor'],
        text: "Purchase Order",
        link: "/purchase-order",
    },
    {
        key: "itemReceipts",
        color: "yellow",
        role: ['admin', 'admin-accounting', 'accounting', 'purchasing', 'warehouse', 'vendor'],
        text: "Item Receipt",
        link: "/item-receipt",
    },
    {
        key: "vendorReturnAuthorizations",
        color: "green",
        role: ['admin', 'admin-accounting', 'accounting', 'purchasing', 'vendor'],
        text: "VRA",
        link: "/vendor-return-authorization",
    },
    {
        key: "itemFulfillments",
        color: "green",
        role: ['admin', 'admin-accounting', 'accounting', 'purchasing', 'warehouse', 'vendor'],
        text: "Item Fulfillment",
        link: "/item-fulfillment",
    },
    {
        key: "billings",
        color: "violet",
        role: ['admin', 'admin-accounting', 'accounting', 'vendor'],
        text: "Bill",
        link: "/bill",
    },
    {
        key: "payments",
        color: "destructive",
        role: ['admin', 'admin-accounting', 'accounting','vendor'],
        text: "Payment",
        link: "/payment",
    },

    {
        key: "debitCreditMemos",
        color: "teal",
        role: ['admin', 'admin-accounting', 'accounting', 'vendor'],
        text: "Debit Memo",
        link: "/debit-credit",
    },

    {
        key: "creditMemos",
        color: "teal",
        role: ['admin-accounting', 'vendor'],
        text: "Credit Memo",
        link: "/credit",
    },
 
]