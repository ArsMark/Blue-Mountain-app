import axios from "axios";

const apiAuth = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL as string,
  params: {
    api_key: process.env.NEXT_PUBLIC_API_KEY,
  },
});

export default apiAuth;