import React from "react";
import { Button } from "./ui/button";
import { HiFolder } from "react-icons/hi";
import Link from "next/link";

export interface CustomButtonProps {
  text: string;
  link: string;
  count: number;
  color:
    | "yellow"
    | "violet"
    | "destructive"
    | "blue"
    | "green"
    | "teal"
    | "kiwi";
    role: string[];
}

const CustomButton = ({ text, link, count, color, role }: CustomButtonProps) => {
  return (
    <div className="flex flex-col justify-center items-center w-fit">
      <Button asChild className={`rounded-full w-20 h-20`} variant={color}>
        <Link href={link}>
          <HiFolder size="30" />
        </Link>
      </Button>
      <p>{text}</p>
      <p className="text-sm text-red-500 font-medium">{count} Unread</p>
    </div>
  );
};

export default CustomButton;
