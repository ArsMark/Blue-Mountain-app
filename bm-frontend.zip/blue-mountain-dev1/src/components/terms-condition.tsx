import React from "react";

const TermsAndCondition = () => {
  const terms = [
    {
      key: 1,
      description:
        "1. Copy of this P.O must be attached to invoice upon delivery.",
    },
    {
      key: 2,
      description:
        "2. Receiving of deliveries is from Monday - Friday 8:00 AM - 11:00 AM only.",
    },
    {
      key: 3,
      description:
        "3. Goods must not be in excess of the quantities ordered. Any excess will not be received by our warehouse personnel",
    },
    {
      key: 4,
      description:
        "4. Penalties will apply on the ff. unless assigned Buyer is informed at least 24 hours before delivery date:",
      subItem: [
        { subKey: 1, item: "LATE DELIVERY: Penalty of Php 20,000.00" },
        {
          subkey: 2,
          item: "INCOMPLETE DELIVERY: Penalty of 15% based on P.O value of undelivered items",
        },
        {
          subkey: 3,
          item: "NON DELIVERY: Penalty of 15% based on P.O value of undelivered items",
        },
      ],
    },
    {
      key: 5,
      description:
        "5. WRONG BARCODE & NEW PACKAGING: Penalty of Php 20,000.00 / SKU unless assigned Buyer is informed at least 30 days before delivery date.",
    },
    {
      key: 6,
      description:
        "6. BAD ORDERS & NEAR EXPIRY ITEM will be returned to supplier.",
    },
  ];

  return (
    <div className="border border-blue-500">
      <div className="bg-blue-800 p-2 text-white text-center">
        <p>TERMS AND CONDITION</p>
      </div>
      <div className="p-4">
        {terms.map((item) => {
          return (
            <ol key={item.key}>
              <li>{item.description}</li>
              <ul className="list-disc ml-10">
                {item.subItem?.map((item, index) => (
                  <li key={index}>{item.item}</li>
                ))}
              </ul>
            </ol>
          );
        })}
      </div>
    </div>
  );
};

export default TermsAndCondition;
