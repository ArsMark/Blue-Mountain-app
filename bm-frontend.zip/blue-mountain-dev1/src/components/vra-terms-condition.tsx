import React from "react";

const VRATermsAndCondition = () => {
  const terms = [
    {
      key: 1,
      description: "1. Copy of this VRA must be presented upon pullout.",
    },
    {
      key: 2,
      description:
        "2. Kindly pullout above mentioned item on or before Deadline for Pull Out.",
    },
    {
      key: 3,
      description:
        "3. Deadline for Pull Out gives suppliers a maximum prescription period of 30 days.",
    },
    {
      key: 4,
      description:
        "4. All unclaimed Bad Orders beyond 30 days shall be authomatically disposed without prior notice.",
    },
    {
      key: 5,
      description:
        "5. A disposal fee of ₱50.00 per bottle will be charged to supplier.",
    },
  ];

  return (
    <div className="border border-blue-500">
      <div className="bg-blue-700 p-2 text-white text-center">
        <p>TERMS AND CONDITION</p>
      </div>
      <div className="p-4">
        {terms.map((item) => {
          return (
            <ol key={item.key}>
              <li>{item.description}</li>
            </ol>
          );
        })}
      </div>
    </div>
  );
};

export default VRATermsAndCondition;
