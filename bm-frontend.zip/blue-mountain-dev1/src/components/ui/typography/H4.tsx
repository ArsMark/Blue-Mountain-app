interface Props {
  children: React.ReactNode;
}

const H4 = ({ children }: Props) => {
  return (
    <h4 className="scroll-m-20 text-xl font-medium tracking-tight">
      {children}
    </h4>
  );
};
export default H4;
