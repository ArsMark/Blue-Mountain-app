interface Props {
  children: React.ReactNode;
}

const H2 = ({ children }: Props) => {
  return (
    <h2 className="scroll-m-20 border-b pb-2 text-3xl font-medium tracking-tight transition-colors first:mt-0">
      {children}
    </h2>
  );
};

export default H2;
