interface Props {
  children: React.ReactNode;
}

const H3 = ({ children }: Props) => {
  return (
    <h3 className="scroll-m-20 text-2xl font-medium tracking-tight">
      {children}
    </h3>
  );
};
export default H3;
