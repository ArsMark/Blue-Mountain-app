import React from "react";

interface Props {
  name: string | undefined;
  size: string | number;
}

const Avatar = ({ name, size }: Props) => {
  return (
    <div
      className={`w-${size} h-${size} rounded-full bg-blue-700 grid place-items-center uppercase text-white font-medium`}
    >
      {name?.charAt(0)}
    </div>
  );
};

export default Avatar;
