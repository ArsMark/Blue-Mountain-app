import React from 'react';

interface LoadingSkeletonProps {
  details: string;
}

const LoadingScreen: React.FC<LoadingSkeletonProps> = ({ details }) => {
  return (
    <div className="absolute top-0 left-0 bg-white  h-full w-full flex  font-semibold text-lg">
      <div className=" shadow rounded-md p-4 h-full w-full mx-auto flex flex-col justify-center items-center">
        <div className="animate-pulse flex flex-col space-y-4 justify-center items-center w-full">
          <div className="rounded-full bg-slate-200 h-10 w-10"></div>
          <div className="flex-1 space-y-6 py-1 w-full">
            <div className="h-2 bg-slate-200 rounded"></div>
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-4">
                <div className="h-2 bg-slate-200 rounded col-span-2"></div>
                <div className="h-2 bg-slate-200 rounded col-span-1"></div>
              </div>
              <div className="h-2 bg-slate-200 rounded"></div>
            </div>
          </div>
        </div>
        <div className="mt-4 text-center text-blue-700">Fetching {details} details..</div>
      </div>
    </div>
  );
};

export default LoadingScreen;
