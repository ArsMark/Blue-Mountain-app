import React, { useState, useEffect } from "react";
import { format } from "date-fns";

function DateTime() {
  const [currentDateTime, setCurrentDateTime] = useState(new Date());

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    // If useEffect hook return a function - it will be called
    // when something in depsArray changed or when unmounting
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div>
      <p className="font-medium">
        {format(currentDateTime, "MMMM d, yyyy | h:mm a")}
      </p>
    </div>
  );
}

export default DateTime;
