export type SidebarItem = {
  name: string;
  href: string;
};

export const sidebarItems: SidebarItem[] = [
  {
    name: "Purchase Order",
    href: "/purchase-order",
  },
  {
    name: "Item Receipt",
    href: "/item-receipt",
  },
  {
    name: "VRA",
    href: "/vendor-return-authorization",
  },
  {
    name: "Item Fulfillment",
    href: "/item-fulfillment",
  },
  {
    name: "Bill",
    href: "/bill",
  },
  {
    name: "Payment",
    href: "/payment",
  },
  {
    name: "Debit",
    href: "/debit-credit",
  },
  {
    name: "Credit",
    href: "/credit",
  }
];
