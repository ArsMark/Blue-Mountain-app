import { useAuthMe } from "@/utils/hooks/useAuth";
import { useSubsidiaryDetails } from "@/utils/hooks/useSubsidiary";
import { deleteCookie, getCookie } from "cookies-next";
import { AnimatePresence } from "framer-motion";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react";
import { useMediaQuery } from "react-responsive";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
interface Props {
  children: React.ReactNode;
}

const Layout = ({ children }: Props) => {
  const router = useRouter();
  const { data, isError } = useAuthMe();
  const isTabletOrMobile = useMediaQuery({ query: "(max-width: 900px)" });
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const subsidiaryId = getCookie("subsidiaryId");
  const { data: subsidiary } = useSubsidiaryDetails(subsidiaryId);

  useEffect(() => {
    if (isTabletOrMobile) {
      setSidebarVisible(false);
    } else {
      setSidebarVisible(true);
    }
  }, [isTabletOrMobile]);

  useEffect(() => {
    if (isTabletOrMobile && router.pathname) {
      setSidebarVisible(false);
    }
  }, [router]);

  useEffect(() => {
    if (!subsidiaryId) {
      router.push("/select");
    }
  }, [subsidiaryId]);

  useEffect(() => {
    if (isError) {
      deleteCookie("user");
      deleteCookie("subsidiaryId");
      deleteCookie("notificationId");
    }
  }, [isError]);

  const toggleSidebar = () => {
    setSidebarVisible(!sidebarVisible);
  };

  return (
    <div className="flex relative">
      <AnimatePresence mode="wait">
        {sidebarVisible && (
          <Sidebar
            sidebarVisible={sidebarVisible}
            toggleSidebar={toggleSidebar}
            subsidiary={subsidiary}
            data={data}
          />
        )}
      </AnimatePresence>

      <div className="w-full overflow-hidden">
        <main className="p-4 bg-[#F2F8FF] border-none min-h-screen md:min-h-screen lg:h-[88vh] overflow-y-auto">
          <Navbar
            toggleSidebar={toggleSidebar}
            data={data}
            subsidiary={subsidiary}
          />
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
