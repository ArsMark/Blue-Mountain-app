import { Subsidiary } from "@/types/ISubsidiaries";
import { Variants, motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import { BiSolidUser } from "react-icons/bi";
import { ImHome3 } from "react-icons/im";
import { RiCloseCircleFill } from "react-icons/ri";
import { IAuth } from "@/types/IAuth";
import { Button } from "../button";
interface Props {
  sidebarVisible: boolean;
  toggleSidebar: () => void;
  subsidiary: Subsidiary | undefined;
  data: IAuth | undefined;
}

const Sidebar = ({ sidebarVisible, toggleSidebar, subsidiary, data}: Props) => {
  const router = useRouter();
  const handleHardReload = (e: any) => {
    e.preventDefault();
    window.location.href = '/home';
  };
  const sidebar: Variants = {
    animate: {
      width: 300,
      opacity: 1,
    },
    exit: {
      width: 0,
      opacity: 0,
    },
  };
  const current_role = data?.role
  let first_link = "/purchase-order"
  if (current_role == 'warehouse') {
    first_link = "/item-receipt"
  }
  return (
    <motion.aside
      variants={sidebar}
      initial="exit"
      animate={sidebarVisible ? "animate" : "exit"}
      exit="exit"
      className={`h-full absolute top-0 left-0 z-10 border-none bg-[#171E4C] text-white w-3/4 ${
        sidebarVisible ? "block md:block md:w-80" : "hidden md:hidden"
      } md:static md:min-h-screen`}
    >
      <div className="bg-white p-4 mb-10 grid place-items-center">
        {subsidiary?.logo && (
          <div className="w-44 h-20 relative">
            <Image
              src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${subsidiary.logo}`}
              alt={"Logo"}
              fill
              objectFit="contain"
              quality={100}
              draggable={false}
            />
          </div>
        )}
      </div>
      <button
        onClick={toggleSidebar}
        className="absolute top-0 right-0 p-4 text-black md:hidden"
      >
        <RiCloseCircleFill size="20" className="text-red-500" />
      </button>
      <div className="space-y-2">
        <p className="ml-3">Overview</p>

        <motion.ul className="flex flex-col space-y-3 w-full justify-center">
          <motion.li className="flex justify-between items-center p-0">
            <Button
              onClick={handleHardReload}
              asChild
              variant={
                router.pathname == "/home"
                  ? "gradientPrimary"
                  : "gradientSecondary"
              }
              size="gradient"
              className="w-[85%] ml-3 flex justify-start px-8"
            >
              <Link href="/home" passHref onClick={handleHardReload} className="flex gap-4 items-center">
                
                <ImHome3 /> HOME
                
              </Link>
            </Button>
            {router.pathname == "/home" && (
              <div
                style={{
                  clipPath: "polygon(0 50%, 100% 100%, 100% 0)",
                  backgroundColor: "#F2F8FF",
                  width: "20px",
                  height: "20px",
                  marginRight: "-1px",
                }}
              />
            )}
          </motion.li>
          <motion.li>
            <Button
              asChild
              variant={
                [
                  "/purchase-order",
                  "/item-receipt",
                  "/vendor-return-authorization",
                  "/item-fulfillment",
                  "/bill",
                  "/bill/[...id]",
                  "/payment",
                  "/debit-credit",
                  "/credit",
                ].includes(router.pathname)
                  ? "gradientPrimary"
                  : "gradientSecondary"
              }
              size="gradient"
              className="w-[85%] ml-3 flex justify-start px-8"
            >
              <Link href={first_link} className="flex gap-4 items-center">
                <BiSolidUser /> TRANSACTION
              </Link>
            </Button>
            {[
              "/purchase-order",
              "/item-receipt",
              "/vendor-return-authorization",
              "/item-fulfillment",
              "/bill",
              "/payment",
              "/debit-credit",
              "/credit",
            ].includes(router.pathname) && (
              <div className="flex flex-col gap-2 ml-8 my-2">
             {(current_role == 'admin-accounting' || current_role == 'vendor' || current_role == 'accounting' || current_role == 'admin' || current_role == 'purchasing') && (
                <div className="flex justify-between items-center">
                  <Link
                    href="/purchase-order"
                    className={
                      router.pathname == "/purchase-order"
                        ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                        : "font-medium text-white"
                    }
                  >
                    PURCHASE ORDER
                  </Link>
                  {router.pathname == "/purchase-order" && (
                    <div
                      style={{
                        clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                        backgroundColor: "#F2F8FF",
                        width: "20px",
                        height: "20px",
                        marginRight: "-1px",
                      }}
                    />
                  )}
                </div>
              )}
               {(current_role == 'admin-accounting' || current_role == 'vendor' || current_role == 'accounting' || current_role == 'admin' || current_role == 'purchasing' || current_role == 'warehouse') && (
                  <div className="flex justify-between items-center">
                    <Link
                      href="/item-receipt"
                      className={
                        router.pathname == "/item-receipt"
                          ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                          : "font-medium text-white"
                      }
                    >
                      ITEM RECEIPT
                    </Link>
                    {router.pathname == "/item-receipt" && (
                      <div
                        style={{
                          clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                          backgroundColor: "#F2F8FF",
                          width: "20px",
                          height: "20px",
                          marginRight: "-1px",
                        }}
                      />
                    )}
                  </div>
               )}
                {(current_role == 'admin-accounting' || current_role == 'vendor' || current_role == 'accounting' || current_role == 'admin' || current_role == 'purchasing') && (
                  <div className="flex justify-between items-center">
                    <Link
                      href="/vendor-return-authorization"
                      className={
                        router.pathname == "/vendor-return-authorization"
                          ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                          : "font-medium text-white"
                      }
                    >
                      VRA
                    </Link>
                    {router.pathname == "/vendor-return-authorization" && (
                      <div
                        style={{
                          clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                          backgroundColor: "#F2F8FF",
                          width: "20px",
                          height: "20px",
                          marginRight: "-1px",
                        }}
                      />
                    )}
                  </div>
                )}
                {(current_role == 'admin-accounting' || current_role == 'vendor' || current_role == 'accounting' || current_role == 'admin' || current_role == 'purchasing' || current_role == 'warehouse') && (
                   <div className="flex justify-between items-center">
                    <Link
                      href="/item-fulfillment"
                      className={
                        router.pathname == "/item-fulfillment"
                          ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                          : "font-medium text-white"
                      }
                    >
                      ITEM FULFILLMENT
                    </Link>
                    {router.pathname == "/item-fulfillment" && (
                      <div
                        style={{
                          clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                          backgroundColor: "#F2F8FF",
                          width: "20px",
                          height: "20px",
                          marginRight: "-1px",
                        }}
                      />
                    )}
                  </div>
                 )}
                {(current_role == 'admin-accounting' || current_role == 'vendor' || current_role == 'accounting' || current_role == 'admin') && (
                  <div className="flex justify-between items-center">
                    <Link
                      href="/bill"
                      className={
                        router.pathname == "/bill"
                          ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                          : "font-medium text-white"
                      }
                    >
                      BILL
                    </Link>
                    {router.pathname == "/bill" && (
                      <div
                        style={{
                          clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                          backgroundColor: "#F2F8FF",
                          width: "20px",
                          height: "20px",
                          marginRight: "-1px",
                        }}
                      />
                    )}
                  </div>
                )}
                 {(current_role == 'admin-accounting' || current_role == 'vendor' || current_role == 'accounting' || current_role == 'admin') && (
                  <div className="flex justify-between items-center">
                    <Link
                      href="/payment"
                      className={
                        router.pathname == "/payment"
                          ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                          : "font-medium text-white"
                      }
                    >
                      PAYMENT
                    </Link>
                    {router.pathname == "/payment" && (
                      <div
                        style={{
                          clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                          backgroundColor: "#F2F8FF",
                          width: "20px",
                          height: "20px",
                          marginRight: "-1px",
                        }}
                      />
                    )}
                  </div>
                 )}
                {(current_role == 'admin-accounting' || current_role == 'vendor' || current_role == 'accounting' || current_role == 'admin') && (
                  <div className="flex justify-between items-center">
                    <Link
                      href="/debit-credit"
                      className={
                        router.pathname == "/debit-credit"
                          ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                          : "font-medium text-white"
                      }
                    >
                      DEBIT
                    </Link>
                    {router.pathname == "/debit-credit" && (
                      <div
                        style={{
                          clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                          backgroundColor: "#F2F8FF",
                          width: "20px",
                          height: "20px",
                          marginRight: "-1px",
                        }}
                      />
                    )}
                  </div>
                )}
               
                {(current_role == 'admin-accounting' || current_role == 'vendor') && (
                  <div className="flex justify-between items-center">
                  <Link
                    href="/credit"
                    className={
                      router.pathname == "/credit"
                        ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                        : "font-medium text-white"
                    }
                  >
                     CREDIT
                  </Link>
                  {router.pathname == "/credit" && (
                    <div
                      style={{
                        clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                        backgroundColor: "#F2F8FF",
                        width: "20px",
                        height: "20px",
                        marginRight: "-1px",
                      }}
                    />
                  )}
                </div>
                )}
                
              </div>
            )}
          </motion.li>
        </motion.ul>
      </div>
    </motion.aside>
  );
};

export default Sidebar;
