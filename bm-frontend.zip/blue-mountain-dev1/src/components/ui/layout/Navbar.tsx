import React, { useEffect, useState } from "react";
import { AiOutlineMenu } from "react-icons/ai";
import Link from "next/link";
import { RiArrowDownSFill } from "react-icons/ri";
import Avatar from "../avatar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { BiSolidBell } from "react-icons/bi";
import { ScrollArea } from "../scroll-area";
import H4 from "../typography/H4";
import { Button } from "../button";
import Image from "next/image";
import { deleteCookie, getCookie, setCookie } from "cookies-next";
import { useMutation } from "@tanstack/react-query";
import { useLogout } from "@/utils/hooks/useLogout";
import { useRouter } from "next/router";
import { toast } from "react-hot-toast";
import Spinner from "../spinner";
import { IAuth } from "@/types/IAuth";
import { Subsidiary } from "@/types/ISubsidiaries";
import { useNotification } from "@/utils/hooks/useNotifications";
import { formatType } from "../../../utils/helpers/helpers";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../dialog";
import { Input } from "../input";
import { z } from "zod";
import { forgotPasswordSchema, passwordSchema } from "@/schema/passwordSchema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../form";
import { Eye, EyeOff } from "lucide-react";
import { DialogDescription } from "@radix-ui/react-dialog";
import {
  useChangePassword,
  useResetPasswordLink,
} from "@/utils/hooks/usePassword";
interface Props {
  toggleSidebar: () => void;
  data: IAuth | undefined;
  subsidiary: Subsidiary | undefined;
}

type FormValues = z.infer<typeof passwordSchema>;

const Navbar = ({ toggleSidebar, data, subsidiary }: Props) => {
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [toggleCurrentPassword, setToggleCurrentPassword] = useState(false);
  const [toggleNewPassword, setToggleNewPassword] = useState(false);
  const [toggleConfirmPassword, setToggleConfimPassword] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const {
    data: notification,
    isFetching,
    isSuccess,
    fetchNextPage,
  } = useNotification(page);
  const { mutateAsync, isLoading } = useMutation(useLogout);
  const { mutate: changePassword, isLoading: isChangingPassword } =
    useChangePassword();

  const form = useForm<FormValues>({
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmNewPassword: "",
    },
    resolver: zodResolver(passwordSchema),
  });

  useEffect(() => {
    fetchNextPage();
  }, [page]);

  useEffect(() => {
    if (isSuccess) {
      setCookie(
        "notificationId",
        `${notification?.pages[0]?.notifications[0]?.id}`
      );
    }
  }, [isSuccess]);

  const showNotification =
    String(notification?.pages[0]?.notifications[0]?.id) !==
    getCookie("notificationId");

  const handleLogout = async () => {
    const token = getCookie("user");
    mutateAsync(`${token}`).then((res) => {
      if (res.status === 204) {
        deleteCookie("user");
        deleteCookie("subsidiaryId");
        deleteCookie("notificationId");
        router.push("/login");
        toast.success("Logged out successfully");
      }
    });
  };

  const onSubmit = (values: FormValues) => {
    changePassword(values, {
      onSuccess: () => {
        setIsModalOpen(false);
        deleteCookie("user");
        deleteCookie("subsidiaryId");
        deleteCookie("notificationId");
        router.push("/login");
      },
    });
  };

  const handleTogglePassword = (
    toggleFunction: React.Dispatch<React.SetStateAction<boolean>>
  ) => {
    toggleFunction((prev) => !prev);
  };
  const handleCurrentPassword = () => {
    handleTogglePassword(setToggleCurrentPassword);
  };
  const handleNewPassword = () => {
    handleTogglePassword(setToggleNewPassword);
  };
  const handleConfirmPassword = () => {
    handleTogglePassword(setToggleConfimPassword);
  };

  const hasNotification = !!notification?.pages?.[0].notifications.length;

  return (
    <nav className="bg-[#F2F8FF] min-w-full flex items-center justify-between md:justify-end text-black p-5">
      <button onClick={toggleSidebar} className="block md:flex-1 lg:hidden">
        <AiOutlineMenu />
      </button>
      <div className="flex space-x-2 items-center">
        <Popover>
          <PopoverTrigger className="relative rounded-full bg-white p-2 text-blue-700">
            <BiSolidBell />
            {showNotification ? (
              <div className="absolute top-0 right-0 bg-red-500 w-2 h-2 rounded-full" />
            ) : null}
          </PopoverTrigger>
          <PopoverContent className="p-0">
            <ScrollArea className="h-[60vh] p-2">
              <H4>Notifications</H4>
              {notification?.pages.map((pages, index) => (
                <div key={index}>
                  {pages.notifications.map((data) => {
                    return (
                      <Link
                        href={formatType(data.type)}
                        className="flex flex-col py-2 rounded-md px-1 hover:bg-gray-100 transition-colors"
                        key={data.id}
                      >
                        <p className="text-blue-700 font-semibold text-xs uppercase">
                          {data.type}
                        </p>
                        <h1 className="font-medium mb-1">{data.title}</h1>
                        <p className="text-sm text-gray-500 w-[250px] truncate overflow-hidden">
                          {data.description}
                        </p>
                      </Link>
                    );
                  })}
                </div>
              ))}
              {!hasNotification && (
                <p className="text-center text-black mt-2">No Notifications</p>
              )}

              {hasNotification ? (
                <Button
                  onClick={() => {
                    setPage((prev) => prev + 1);
                  }}
                  disabled={isFetching}
                  variant="icon"
                >
                  {isFetching ? <Spinner /> : "Load more"}
                </Button>
              ) : null}
            </ScrollArea>
          </PopoverContent>
        </Popover>
        <div className="flex flex-col space-y-1">
          <h1 className="text-lg font-medium leading-none">
            {data?.firstName} {data?.lastName}
          </h1>
          <p className="text-sm text-muted-foreground">{data?.role}</p>
        </div>
        <Avatar name={data?.firstName} size="10" />
        <Popover>
          <PopoverTrigger title="Settings">
            <RiArrowDownSFill />
          </PopoverTrigger>
          <PopoverContent>
            <div>
              <div className="flex flex-wrap justify-between items-center mb-1">
                <div
                  className={`w-14 h-14 rounded-full bg-blue-700 grid place-items-center uppercase text-white font-medium`}
                >
                  {data?.firstName?.charAt(0)}
                </div>
                <div className="ml-2 flex-1 break-words">
                  <p className="text-sm ml-2">{data?.email}</p>
                </div>
              </div>
              <hr className="border my-2" />
              <div className="flex flex-col">
              {(data?.role == 'admin-accounting' || data?.role == 'admin') && (
                <Button variant="ghost" onClick={() => setIsModalOpen(true)}>
                Change Password
              </Button>
              )}
                
                <Button onClick={handleLogout} disabled={isLoading}>
                  {isLoading ? <Spinner /> : "Logout"}
                </Button>
              </div>
            </div>
            <hr className="border my-2" />
            <div className="flex justify-between items-center">
              {subsidiary?.logo && (
                <div className="w-28 h-12 relative">
                  <Image
                    src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${subsidiary.logo}`}
                    alt={"Logo"}
                    fill
                    objectFit="contain"
                    draggable={false}
                  />
                </div>
              )}
              <Link href="/select">Switch</Link>
            </div>
          </PopoverContent>
        </Popover>
      </div>
      <Dialog onOpenChange={(val) => setIsModalOpen(val)} open={isModalOpen}>
        <DialogContent className="w-3/4 md:min-w-1/4">
          <DialogTitle>Change Password</DialogTitle>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="currentPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          {...field}
                          type={toggleCurrentPassword ? "text" : "password"}
                        />
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 cursor-pointer">
                          {toggleCurrentPassword ? (
                            <EyeOff
                              className="h-5 w-5"
                              onClick={handleCurrentPassword}
                            />
                          ) : (
                            <Eye
                              className="h-5 w-5"
                              onClick={handleCurrentPassword}
                            />
                          )}
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="newPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          {...field}
                          type={toggleNewPassword ? "text" : "password"}
                        />
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 cursor-pointer">
                          {toggleNewPassword ? (
                            <EyeOff
                              className="h-5 w-5"
                              onClick={handleNewPassword}
                            />
                          ) : (
                            <Eye
                              className="h-5 w-5"
                              onClick={handleNewPassword}
                            />
                          )}
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="confirmNewPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirm Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          {...field}
                          type={toggleConfirmPassword ? "text" : "password"}
                        />
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 cursor-pointer">
                          {toggleConfirmPassword ? (
                            <EyeOff
                              className="h-5 w-5"
                              onClick={handleConfirmPassword}
                            />
                          ) : (
                            <Eye
                              className="h-5 w-5"
                              onClick={handleConfirmPassword}
                            />
                          )}
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex gap-1 justify-end ">
                <Button
                  variant="ghost"
                  className="md:w-1/5"
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" className="md:w-1/5">
                  {isChangingPassword ? <Spinner /> : "Save"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </nav>
  );
};

export default Navbar;
