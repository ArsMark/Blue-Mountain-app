import React, { useState, useEffect } from 'react';

const Unauthorized = () => {
  const [showUnauthorized, setShowUnauthorized] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowUnauthorized(true);
    }, 1000); // 1000ms delay

    return () => clearTimeout(timer);
  }, []);

  if (!showUnauthorized) {
    return null;
  }

  return (
    <div style={unauthorizedStyle.container}>
      <div style={unauthorizedStyle.box}>
        <div style={unauthorizedStyle.symbolContainer}>
          <div style={unauthorizedStyle.symbol}>
            <div style={unauthorizedStyle.symbolBefore}></div>
            <div style={unauthorizedStyle.symbolAfter}></div>
          </div>
        </div>
        <h1 style={unauthorizedStyle.title}>Access Denied</h1>
        <p style={unauthorizedStyle.message}>
          You don&lsquo;t have access to this page...
        </p>
      </div>
    </div>
  );
};

const unauthorizedStyle = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundColor: '#f0f2f5',
  },
  box: {
    textAlign: 'center' as 'center',
    padding: '3rem',
    borderRadius: '12px',
    backgroundColor: '#ffffff',
    boxShadow: '0 10px 20px rgba(0,0,0,0.1)',
    maxWidth: '400px',
    width: '90%',
  },
  symbolContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: '2rem',
  },
  symbol: {
    width: '60px',
    height: '60px',
    borderRadius: '50%',
    backgroundColor: '#ff4d4d',
    position: 'relative' as 'relative',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    color: '#fff',
    fontSize: '24px',
  },
  symbolBefore: {
    content: '""',
    width: '30px',
    height: '6px',
    backgroundColor: '#fff',
    position: 'absolute' as 'absolute',
    transform: 'rotate(45deg)',
  },
  symbolAfter: {
    content: '""',
    width: '30px',
    height: '6px',
    backgroundColor: '#fff',
    position: 'absolute' as 'absolute',
    transform: 'rotate(-45deg)',
  },
  title: {
    fontSize: '2.5rem',
    marginBottom: '1rem',
    color: '#333',
  },
  message: {
    fontSize: '1.2rem',
    color: '#666',
  },
};

export default Unauthorized;
