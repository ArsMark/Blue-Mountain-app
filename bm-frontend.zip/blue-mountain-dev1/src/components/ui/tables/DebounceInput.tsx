import { useEffect, useState } from "react";
import { Input } from "../input";
import { HiSearch } from "react-icons/hi";

function DebouncedInput({
  value: initialValue,
  onChange,
  debounce = 300,
  ...props
}: {
  value: string | number;
  onChange: (value: string | number) => void;
  debounce?: number;
} & Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange">) {
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      onChange(value);
    }, debounce);

    return () => clearTimeout(timeout);
  }, [value]);

  return (
    <div className="flex gap-1 bg-white rounded-md p-2 items-center w-full md:w-1/4">
      <HiSearch size="18" color="#707070" />
      <input
        {...props}
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Search"
        className="outline-none w-full"
      />
    </div>
  );
}
export default DebouncedInput;
