import * as React from "react";
import {
  RxChevronLeft,
  RxChevronRight,
  RxDoubleArrowLeft,
  RxDoubleArrowRight,
} from "react-icons/rx";
import {
  ColumnDef,
  PaginationState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  useReactTable,
} from "@tanstack/react-table";

import { cn } from "@/lib/utils";
import { TotalBillings } from "@/types/IBill";

import { Button } from "../button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableFooter,
} from "../table";

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  loading?: boolean;
  page?: PaginationState;
  setPage?: React.Dispatch<React.SetStateAction<PaginationState>>;
  displayPagination: boolean;
  vendorVisibility?: boolean;
  displayFooter?: boolean;
  footerData?: TotalBillings | undefined;
  total: number | undefined;
  rowClassName?: string;
  wrapperClassName?: string;
  textAlign: string;
}

export function DataTable<TData, TValue>({
  columns,
  data,
  displayFooter,
  footerData,
  page,
  loading,
  setPage,
  displayPagination,
  total = 100,
  vendorVisibility = true,
  rowClassName,
  wrapperClassName,
  textAlign
}: DataTableProps<TData, TValue>) {
  const table = useReactTable({
    data,
    columns,
    enableRowSelection: true,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    pageCount: Math.ceil(total / Number(page?.pageSize)),
    onPaginationChange: setPage,
    state: {
      columnVisibility: {
        vendorName: vendorVisibility,
      },
      pagination: {
        pageIndex: page?.pageIndex ?? 1,
        pageSize: page?.pageSize ?? 5,
      },
    },
    manualPagination: true,
  });

  const isLastPage = table.getState().pagination.pageIndex + 1 === table.getPageCount();

  return (
    <div className={cn("space-y-4", wrapperClassName)}>
      <div className="rounded-md relative">
        {loading && (
          <div className="absolute top-0 left-0 bg-green h-full w-full z-50 bg-white bg-opacity-90 text-black font-semibold text-xl flex justify-center items-center">
            Please Wait...
          </div>
        )}
        {/* Table Header */}
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id} className={rowClassName}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id} className={textAlign}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  );
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                  className={rowClassName}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id} className={textAlign}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No results.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
          {displayFooter && isLastPage && (
            <TableFooter>
              <TableRow className="bg-[#F2F8FF] hover:bg-[#F2F8FF]">
                <TableCell colSpan={3}>
                  <p className="text-gray-800 text-right">Total:</p>
                </TableCell>
                <TableCell>
                  <p className="text-gray-800">
                    {Number(footerData?.grossAmount).toLocaleString("en-US", {
                      style: "currency",
                      currency: "PHP",
                    })}
                  </p>
                </TableCell>
                <TableCell>
                  <p className="text-gray-800">
                    {Number(footerData?.vat).toLocaleString("en-US", {
                      style: "currency",
                      currency: "PHP",
                    })}
                  </p>
                </TableCell>
                <TableCell>
                  <p className="text-gray-800">
                    {Number(footerData?.withHoldingTax).toLocaleString("en-US", {
                      style: "currency",
                      currency: "PHP",
                    })}
                  </p>
                </TableCell>
                <TableCell>
                  <p className="text-gray-800">
                    {Number(footerData?.netAmount).toLocaleString("en-US", {
                      style: "currency",
                      currency: "PHP",
                    })}
                  </p>
                </TableCell>
              </TableRow>
            </TableFooter>
          )}
        </Table>
      </div>
      {displayPagination && (
        <div className="flex items-center space-x-2 justify-end mt-2">
          <div className="flex w-[100px] items-center justify-center text-sm font-medium">
            Page {table.getState().pagination.pageIndex + 1} of{" "}
            {table.getPageCount()}
          </div>

          <Button
            variant="outline"
            className="h-8 w-8 p-0"
            onClick={() => table.setPageIndex(0)}
            disabled={!table.getCanPreviousPage() || loading}
            size="icon"
          >
            <RxDoubleArrowLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            className="h-8 w-8 p-0"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage() || loading}
            size="icon"
          >
            <RxChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            className="h-8 w-8 p-0"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage() || loading}
            size="icon"
          >
            <RxChevronRight className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            className="h-8 w-8 p-0"
            onClick={() => table.setPageIndex(table.getPageCount() - 1)}
            disabled={!table.getCanNextPage() || loading}
            size="icon"
          >
            <RxDoubleArrowRight className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
}
