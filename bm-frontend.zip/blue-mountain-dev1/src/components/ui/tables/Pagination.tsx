import React, { Dispatch, SetStateAction } from "react";
import { RxChevronLeft, RxChevronRight } from "react-icons/rx";
import ReactPaginate from "react-paginate";
import { PurchaseOrder } from "@/types/IPurchase";

interface Props {
  page: number;
  setPage: Dispatch<SetStateAction<number>>;
  perPage: number | undefined;
  rows: number;
}

const Pagination = ({ page, setPage, perPage = 5, rows }: Props) => {
  const pageSize = Math.ceil(perPage / rows);

  const paginate = (event: { selected: number }) => {
    setPage(event.selected + 1);
  };

  return (
    <div className="flex items-center mt-2 space-x-2 justify-between">
      <p className="text-sm font-medium">
        Page {page} of {pageSize}
      </p>
      <ReactPaginate
        breakLabel="..."
        nextLabel={<RxChevronRight className="h-4 w-4" />}
        onPageChange={paginate}
        pageRangeDisplayed={3}
        pageCount={pageSize}
        renderOnZeroPageCount={null}
        previousLabel={<RxChevronLeft className="h-4 w-4" />}
        activeClassName="font-bold text-white bg-blue-700 rounded-md"
        pageLinkClassName="p-2 px-3"
        className="flex items-center gap-4"
      />
    </div>
  );
};

export default Pagination;
