import React from "react";
import { CgSpinner } from "react-icons/cg";
const Spinner = () => {
  return (
    <div>
      <CgSpinner className="animate-spin w-6 h-6" />
    </div>
  );
};

export default Spinner;
