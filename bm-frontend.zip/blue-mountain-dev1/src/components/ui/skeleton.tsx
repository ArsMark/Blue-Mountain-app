import React from "react";

const SkeletonComponent: React.FC = () => {
  const array = Array(10).fill(1);

  return (
    <>
      {array.map((_, index) => {
        return (
          <div key={index} className="flex flex-col my-2 gap-1">
            <div className="h-3 w-1/2 animate-pulse bg-gray-300 rounded-full" />
            <div className="h-3 w-10/12 animate-pulse bg-gray-300 rounded-full" />
            <div className="h-3 w-full animate-pulse bg-gray-300 rounded-full" />
          </div>
        );
      })}
    </>
  );
};

export default SkeletonComponent;
