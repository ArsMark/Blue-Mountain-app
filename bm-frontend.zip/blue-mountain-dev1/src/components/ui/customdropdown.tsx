import React, { useState } from "react";
import { Button } from "./button";
import { BiSolidUser } from "react-icons/bi";
import { useRouter } from "next/router";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { SidebarItem } from "./layout/sidebaritems";
import { cn } from "@/lib/utils";

type Props = {
  items: SidebarItem[];
  title: String;
};

const CustomDropdown = ({ items, title }: Props) => {
  const router = useRouter();
  const [showItems, setShowItems] = useState(false);

  const container = {
    open: {
      scaleY: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.05,
      },
    },
    closed: {
      scaleY: 0,
      transition: {
        when: "afterChildren",
        staggerChildren: 0.05,
      },
    },
  };

  const itemVariants = {
    open: {
      opacity: 1,
      y: 0,
      transition: {
        when: "beforeChildren",
      },
    },
    closed: {
      opacity: 0,
      y: -15,
      transition: {
        when: "afterChildren",
      },
    },
  };
  return (
    <div className="flex flex-col gap-2">
      <Button
        variant={
          [
            "/purchase-order",
            "/item-receipt",
            "/vendor-return-authorization",
            "/item-fulfillment",
            "/bill",
            "/payment",
            "/debit-credit",
            "/credit"
          ].includes(router.pathname)
            ? "gradientPrimary"
            : "gradientSecondary"
        }
        size="gradient"
        onClick={() => setShowItems(!showItems)}
        className="w-[85%] ml-3 flex gap-2 justify-start px-8 hover:bg-gradient-to-r hover:from-cyan-500 hover:to-blue-500 transition-colors duration-200"
      >
        <BiSolidUser /> {title}
      </Button>
      <AnimatePresence>
        {showItems && (
          <motion.ul
            variants={container}
            initial="closed"
            animate="open"
            exit="closed"
          >
            {items.map((item) => (
              <motion.li
                key={item.href}
                variants={itemVariants}
                className="flex flex-col gap-2 ml-8 my-2"
              >
                <div className="flex justify-between items-center">
                  <Link
                    href={item.href}
                    className={cn(
                      "hover:text-blue-400 hover:underline w-4/5 transition-colors duration-200",
                      router.pathname == item.href
                        ? "font-medium text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500"
                        : "font-medium text-white"
                    )}
                  >
                    {item.name}
                  </Link>
                  {router.pathname == item.href && (
                    <div
                      style={{
                        clipPath: "polygon(0 50%, 100% 99%, 100% 0)",
                        backgroundColor: "white",
                        width: "20px",
                        height: "20px",
                      }}
                    />
                  )}
                </div>
              </motion.li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CustomDropdown;
