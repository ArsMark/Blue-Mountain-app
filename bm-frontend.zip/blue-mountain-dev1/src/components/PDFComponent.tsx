import { IPurchaseOrderDetails } from "@/types/IPurchase";
import {
  Document,
  Font,
  Image,
  Page,
  StyleSheet,
  Text,
  View,
} from "@react-pdf/renderer";

Font.register({
  family: "Mulish",
  src: "/assets/fonts/Mulish-Regular.ttf",
});
interface Props {
  data: IPurchaseOrderDetails | undefined;
}

// Create styles
const styles = StyleSheet.create({
  page: {
    fontFamily: "Mulish",
    flexDirection: "column",
    gap: 14,
    padding: 25,
    backgroundColor: "#F2F8FF",
  },
  logo: {
    width: "100",
    height: "40",
    justifyContent: "flex-start",
  },
  description: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 1,
  },
  descriptionContainer: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
    marginBottom: 5,
    justifyContent: "space-between",
    // gap: 15,
  },
  descriptionTitle: { color: "#2D459C", fontSize: 10 },
  text: {
    fontSize: 10,
    fontWeight: "medium",
  },
  table: {
    width: "100%",
    borderRadius: "8px",
  },
  tableRow: {
    margin: "auto",
    flexDirection: "row",
  },
  tableCol: {
    width: "20%",
    // borderStyle: "solid",
    // borderBottom: "1px",
    // borderColor: "#2D459C",
  },
  tableCell: {
    marginTop: 5,
    fontSize: 10,
    marginBottom: 5,
    textAlign: "left",
    marginVertical: "2px",
  },
});

// Create Document Component
const PDFComponent = ({ data }: Props) => {
  const length = data?.purchaseOrderItems?.length ?? 0;
  const osd = data?.totalOtherSpecialDiscount ?? 0;
  const tctd = data?.totalCentralTlcDiscount ?? 0;
  const tcdd = data?.totalCentralDropDiscrount ?? 0;
  const ttd = data?.totalTradeDiscount ?? 0;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <View>
            {data?.subsidiary && (
              <Image
                src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${data?.subsidiary.logo}`}
                style={styles.logo}
              />
            )}
          </View>
          <View>
            <Text style={{ fontSize: 13, fontWeight: 700 }}>
              Purchase Order
            </Text>
            <Text style={{ fontSize: 10, fontWeight: "medium" }}>
              Primary Information
            </Text>
            <View
              style={{
                display: "flex",
                flexDirection: "row",
                gap: 10,
                paddingTop: 2,
              }}
            >
              <View style={{ display: "flex", flexDirection: "column" }}>
                <Text style={{ fontSize: 10, fontWeight: "medium" }}>
                  P.O No
                </Text>
                <Text style={styles.text}>{data?.poNumber}</Text>
              </View>
              <View style={{ display: "flex", flexDirection: "column" }}>
                <Text style={{ fontSize: 10, fontWeight: "medium" }}>
                  P.O Date
                </Text>
                <Text style={styles.text}>
                  {!!data?.poDate &&
                    new Date(data?.poDate).toLocaleDateString()}
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 15,
          }}
        >
          <View
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              alignItems: "flex-start",
              gap: 1,
            }}
          >
            <View>
              <Text style={styles.descriptionTitle}>Vendor</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.vendor?.name}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Shipping address</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.shippingAddress}</Text>
            </View>
          </View>
        </View>
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <View
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              alignItems: "flex-start",
              gap: 1,
            }}
          >
            <View>
              <Text style={styles.descriptionTitle}>Delivery Area</Text>
              <Text style={styles.text}>{data?.deliveryArea}</Text>
            </View>
          </View>
          <View
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "flex-start",
              gap: 15,
              margin: "auto",
            }}
          >
            <View>
              <Text style={styles.descriptionTitle}>Delivery Date</Text>
              <Text style={styles.text}>
                {!!data?.deliveryDate &&
                  new Date(data?.deliveryDate).toLocaleDateString()}
              </Text>
            </View>
            <View>
              <Text style={styles.descriptionTitle}>Total Cases</Text>
              <Text style={styles.text}>{data?.totalCases}</Text>
            </View>
            <View>
              <Text style={styles.descriptionTitle}>Terms</Text>
              <Text style={styles.text}>{data?.terms}</Text>
            </View>
          </View>
        </View>
        <View>
          <hr
            style={{
              border: "1px solid #2D459C",
            }}
          />
        </View>
        <View>
          <Text style={styles.text}>Item Information</Text>
        </View>
        {/* table */}
        {/* <View style={styles.table}>
          <View style={styles.tableRow}>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Barcode
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Item Desription
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Quantity
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>Cost</Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Total Amount
              </Text>
            </View>
          </View>
          {data?.purchaseOrderItems?.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.barcode}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.description}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.quantity}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.cost).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.amount).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
            </View>
          ))}
        </View> */}
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingBottom: 8,
          }}
        >
          <Text
            style={{
              width: "16.66%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Barcode
          </Text>
          <Text
            style={{
              width: "50%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Item Desription
          </Text>
          <Text
            style={{
              width: "12%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Quantity
          </Text>
          <Text
            style={{
              width: "12%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Cost
          </Text>
          <Text
            style={{
              width: "16.66%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Amount
          </Text>
        </View>
        {data?.purchaseOrderItems?.map((item, index) => (
          <View
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
            key={index}
          >
            <Text
              style={{
                width: "16.66%",
                fontWeight: "medium",

                fontSize: 8,
              }}
            >
              {item.barcode}
            </Text>
            <Text
              style={{
                width: "50%",
                fontWeight: "medium",
                fontSize: 8,
                margin: "auto",
              }}
            >
              {item.description}
            </Text>
            <Text
              style={{
                width: "12%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {item.quantity}
            </Text>
            <Text
              style={{
                width: "12%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {Number(item.cost).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </Text>
            <Text
              style={{
                width: "16.66%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {Number(item.amount).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </Text>
          </View>
        ))}
        {/* terms and condition */}
        <View>
          <View>
            <hr
              style={{
                border: "1px solid #2D459C",
              }}
            />
          </View>

          <View style={styles.descriptionContainer}>
            <View>
              <Text style={styles.descriptionTitle}>Total Amount</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {Number(data?.totalAmount).toLocaleString("en-US", {
                  style: "currency",
                  currency: "PHP",
                })}
              </Text>
            </View>
          </View>
          <View>
            <hr
              style={{
                border: "1px solid #2D459C",
              }}
            />
          </View>
          {(ttd != 0 || tcdd != 0 || tctd != 0 || osd != 0) && (
            <View>
             <Text
               style={{
                 marginTop: 5,
                 marginBottom: 5,
                 color: "#2D459C",
                 fontSize: 10,
               }}
             >
               Discounts
             </Text>
           </View>
          )}
         
          {ttd != 0 && (
            <View style={styles.descriptionContainer}>
              <View>
                <Text style={{ fontSize: 10 }}>Total Trade Discount</Text>
              </View>
              <View>
                <Text style={styles.text}>
                  {Number(data?.totalTradeDiscount).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
            </View>
          )}
          {tcdd != 0 && (
            <View style={styles.descriptionContainer}>
              <View>
                <Text style={{ fontSize: 10 }}>
                  Total Central Drop Discount
                </Text>
              </View>
              <View>
                <Text style={styles.text}>
                  {Number(data?.totalCentralDropDiscrount).toLocaleString(
                    "en-US",
                    {
                      style: "currency",
                      currency: "PHP",
                    }
                  )}
                </Text>
              </View>
            </View>
          )}
          {tctd != 0 && (
            <View style={styles.descriptionContainer}>
              <View>
                <Text style={{ fontSize: 10 }}>Total Central TLC Discount</Text>
              </View>
              <View>
                <Text style={styles.text}>
                  {Number(data?.totalCentralTlcDiscount).toLocaleString(
                    "en-US",
                    {
                      style: "currency",
                      currency: "PHP",
                    }
                  )}
                </Text>
              </View>
            </View>
          )}
          {osd != 0 && (
            <View style={styles.descriptionContainer}>
              <View>
                <Text style={{ fontSize: 10 }}>
                  Total Other Discount
                </Text>
              </View>
              <View>
                <Text style={styles.text}>
                  {Number(data?.totalOtherSpecialDiscount).toLocaleString(
                    "en-US",
                    {
                      style: "currency",
                      currency: "PHP",
                    }
                  )}
                </Text>
              </View>
            </View>
          )}
          <View
            style={{ borderColor: "#1a245c", borderWidth: 1, marginTop: '10px' }}
            break={length > 15 || length == 12 ? true : false}
          >
            <Text
              style={{
                textAlign: "center",
                backgroundColor: "#1a245c",
                padding: 2,
                fontSize: 10,
                color: "#fff",
              }}
            >
              TERMS AND CONDITION
            </Text>
            <View
              style={{
                flexDirection: "column",
                padding: 8,
                width: 800,
              }}
            >
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 7 }}
              >
                <Text style={{ marginHorizontal: 4 }}>1.</Text>
                <Text>
                  Copy of this P.O must be attached to invoice upon delivery.
                </Text>
              </View>
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 7 }}
              >
                <Text style={{ marginHorizontal: 4 }}>2.</Text>
                <Text>
                  Receiving of deliveries is from Monday - Friday 8:00 AM -
                  11:00 AM only.
                </Text>
              </View>
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 7 }}
              >
                <Text style={{ marginHorizontal: 4 }}>3.</Text>
                <Text>
                  Goods must not be in excess of the quantities ordered. Any
                  excess will not be received by our warehouse personnel.
                </Text>
              </View>
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 7 }}
              >
                <Text style={{ marginHorizontal: 4 }}>4.</Text>
                <Text>
                  Penalties will apply on the ff. unless assigned Buyer is
                  informed at least 24 hours before delivery date:
                </Text>
              </View>
              <View style={{ flexDirection: "column", fontSize: 7 }}>
                <View style={{ flexDirection: "row", marginBottom: 1 }}>
                  <Text style={{ marginHorizontal: 8 }}>•</Text>
                  <Text>LATE DELIVERY: Penalty of Php 20,000.00</Text>
                </View>
                <View style={{ flexDirection: "row", marginBottom: 1 }}>
                  <Text style={{ marginHorizontal: 8 }}>•</Text>
                  <Text>
                    INCOMPLETE DELIVERY: Penalty of 15% based on P.O value of
                    undelivered items
                  </Text>
                </View>
                <View style={{ flexDirection: "row", marginBottom: 1 }}>
                  <Text style={{ marginHorizontal: 8 }}>•</Text>
                  <Text>
                    NON DELIVERY: Penalty of 15% based on P.O value of
                    undelivered items
                  </Text>
                </View>

                <View
                  style={{
                    flexDirection: "row",
                    marginBottom: 1,
                    fontSize: 7,
                  }}
                >
                  <Text style={{ marginHorizontal: 4 }}>5.</Text>
                  <Text>
                    WRONG BARCODE & NEW PACKAGING: Penalty of Php 20,000.00 /
                    SKU unless assigned Buyer is informed at least 30 days
                    before delivery date.
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    marginBottom: 1,
                    fontSize: 7,
                  }}
                >
                  <Text style={{ marginHorizontal: 4 }}>6.</Text>
                  <Text>
                    BAD ORDERS & NEAR EXPIRY ITEM will be returned to supplier.
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.descriptionContainer}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Prepared By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.preparedBy}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Checked By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.checkedBy}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Approved By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.approvedBy}</Text>
            </View>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default PDFComponent;
