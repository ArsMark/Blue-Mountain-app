import { IVRADetails } from "@/types/IVRA";
import {
  Document,
  Font,
  Image,
  Page,
  StyleSheet,
  Text,
  View,
} from "@react-pdf/renderer";

Font.register({
  family: "Mulish",
  src: "/assets/fonts/Mulish-Regular.ttf",
});

interface Props {
  data: IVRADetails | undefined | null;
}

// Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    fontFamily: "Mulish",
    gap: 14,
    padding: 25,
    backgroundColor: "#F2F8FF",
  },
  logo: {
    width: "100",
    height: "40",
    justifyContent: "flex-start",
  },
  description: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 1,
  },
  descriptionContainer: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  descriptionTitle: { color: "#2D459C", fontSize: 10 },
  text: {
    fontSize: 10,
    fontWeight: "medium",
  },
  table: {
    width: 550,
    borderRadius: "8px",
  },
  tableRow: {
    margin: "auto",
    flexDirection: "row",
  },
  tableCol: {
    width: "20%",
  },
  tableCell: {
    margin: "auto",
    marginTop: 5,
    fontSize: 10,
    marginBottom: 5,
  },
  headerTitle: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
  },
});

// Create Document Component
const VraPDF = ({ data }: Props) => {
  const length = data?.vendorReturnAutorizationItems.length ?? 0;
  const siteName = data?.warehouseLocation?.name ?? '';
  const siteAddress = data?.warehouseLocation?.address?? '';
  const gsubSiteName = siteName.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const gsubSiteAddress = siteAddress.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const isNameIncludedInAddress = gsubSiteAddress.includes(gsubSiteName);
  const ttd = data?.totalTradeDiscount ?? 0;
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View>
            {data?.subsidiary && (
              <Image
                src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${data?.subsidiary.logo}`}
                style={styles.logo}
              />
            )}
          </View>
          <View>
            <Text style={styles.text}>Vendor Return Authorization</Text>
          </View>
        </View>
        <View style={styles.headerTitle}>
          <View>
            <Text style={styles.text}>Primary Information</Text>
          </View>
          <View>
            <Text style={styles.text}>NO: {data?.vraNumber}</Text>
          </View>
        </View>

        <View style={styles.description}>
          <View>
            <Text style={styles.descriptionTitle}>SRS No.</Text>
          </View>
          <View>
            <Text style={styles.text}>{data?.srsNumber}</Text>
          </View>
        </View>

        <View style={styles.description}>
          <View>
            <Text style={styles.descriptionTitle}>Vendor</Text>
          </View>
          <View>
            <Text style={styles.text}>{data?.vendor.name}</Text>
          </View>
        </View>
        <View style={styles.description}>
          <View>
            <Text style={styles.descriptionTitle}>Site Address</Text>
          </View>
          <View>
            <Text style={styles.text}>{isNameIncludedInAddress}</Text>
          </View>
        </View>

        <View style={{ display: "flex", flexDirection: "row", gap: 20 }}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Date Created</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.createdAt &&
                  new Date(data?.createdAt).toLocaleDateString()}
              </Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Deadline for Pull Out</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.pullOutDate &&
                  new Date(data?.pullOutDate).toLocaleDateString()}
              </Text>
            </View>
          </View>
        </View>

        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View>
          <Text style={styles.text}>Item Information</Text>
        </View>
        {/* <View style={styles.table}>
          <View style={styles.tableRow}>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Barcode
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Item Desription
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Gross / Net
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Quantity
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Total Amount
              </Text>
            </View>
          </View>
          {data?.vendorReturnAutorizationItems.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.item.barcode}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.item.description}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.grossNet).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.quantity}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.totalAmount).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
            </View>
          ))}
        </View> */}
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingBottom: 8,
          }}
        >
          <Text
            style={{
              width: "16.66%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Barcode
          </Text>
          <Text
            style={{
              width: "50%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Item Desription
          </Text>
          <Text
            style={{
              width: "12%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Gross / Net
          </Text>
          <Text
            style={{
              width: "12%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Quantity
          </Text>
          <Text
            style={{
              width: "16.66%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Total Amount
          </Text>
        </View>
        {data?.vendorReturnAutorizationItems?.map((item, index) => (
          <View
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
            key={index}
          >
            <Text
              style={{
                width: "16.66%",
                fontWeight: "medium",

                fontSize: 8,
              }}
            >
              {item.item.barcode}
            </Text>
            <Text
              style={{
                width: "50%",
                fontWeight: "medium",
                fontSize: 8,
                margin: "auto",
              }}
            >
              {item.item.description}
            </Text>
            <Text
              style={{
                width: "12%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {Number(item.grossPrice).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </Text>
            <Text
              style={{
                width: "12%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {item.quantity}
            </Text>
            <Text
              style={{
                width: "16.66%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {Number(item.totalAmount).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </Text>
          </View>
        ))}
        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View style={styles.descriptionContainer}>
          <View>
            <Text style={styles.descriptionTitle}>Total Amount</Text>
          </View>
          <View>
            <Text style={styles.text}>
              {Number(data?.totalAmount).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </Text>
          </View>
        </View>
        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View>
          <View style={{ borderColor: "#1a245c", borderWidth: 1 }}>
            <Text
              style={{
                textAlign: "center",
                backgroundColor: "#1a245c",
                padding: 2,
                fontSize: 10,
                color: "#fff",
              }}
            >
              TERMS AND CONDITION
            </Text>
            <View
              style={{
                flexDirection: "column",
                padding: 8,
                width: 800,
              }}
            >
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 8 }}
              >
                <Text style={{ marginHorizontal: 4 }}>1.</Text>
                <Text>Copy of this VRA must be presented upon pullout.</Text>
              </View>
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 8 }}
              >
                <Text style={{ marginHorizontal: 4 }}>2.</Text>
                <Text>
                  Kindly pullout above mentioned item on or before Deadline for Pull Out.
                </Text>
              </View>
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 8 }}
              >
                <Text style={{ marginHorizontal: 4 }}>3.</Text>
                <Text>
                Deadline for Pull Out gives suppliers a maximum prescription period of
                  30 days.
                </Text>
              </View>
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 8 }}
              >
                <Text style={{ marginHorizontal: 4 }}>4.</Text>
                <Text>
                  All unclaimed Bad Orders beyond 30 days shall be
                  authomatically disposed without prior notice.
                </Text>
              </View>
              <View
                style={{ flexDirection: "row", marginBottom: 1, fontSize: 8 }}
              >
                <Text style={{ marginHorizontal: 4 }}>5.</Text>
                <Text>
                  A disposal fee of ₱50.00 per bottle will be charged to
                  supplier after disposal.
                </Text>
              </View>
            </View>
          </View>

          <View style={{ ...styles.description, marginTop: 3 }}>
            <View>
              <Text style={styles.descriptionTitle}>Prepared By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.preparedBy}</Text>
            </View>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default VraPDF;
