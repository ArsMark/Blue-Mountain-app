import React from "react";
import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Font,
} from "@react-pdf/renderer";

import { IPaymentDetails, Billing, DebitCreditBill } from "@/types/IPayment";

Font.register({
  family: "Mulish",
  src: "/assets/fonts/Mulish-Regular.ttf",
});

interface Props {
  data: IPaymentDetails | undefined;
}

// Create styles
const styles = StyleSheet.create({
  page: {
    fontFamily: "Mulish",
    flexDirection: "column",
    gap: 14,
    padding: 25,
    backgroundColor: "#F2F8FF",
  },
  logo: {
    width: "100",
    height: "40",
    justifyContent: "flex-start",
  },
  description: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 1,
  },
  descriptionContainer: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  descriptionTitle: { color: "#2D459C", fontSize: 10 },
  text: {
    fontSize: 10,
    fontWeight: "medium",
  },
  table: {
    width: 550,
    borderRadius: "8px",
  },
  tableRow: {
    // margin: "auto",
    flexDirection: "row",
  },
  tableCol: {
    width: "14%",
    textAlign: "left",
    // borderStyle: "solid",
    // borderBottom: "1px",
    // borderColor: "#2D459C",
  },
  tableCell: {
    margin: "auto",
    marginTop: 5,
    fontSize: 10,
    marginBottom: 5,
  },
});

// Create Document Component
const BillPaymentPDF = ({ data }: Props) => {
  if (!data) return null;

  const deductions_length = data?.deductions.length ?? 0;
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View>
          <Text style={styles.text}>Bill Payment</Text>
        </View>
        <View>
          <Text style={styles.text}>Primary Information</Text>
        </View>

        {/* date */}
        <View style={styles.descriptionContainer}>
          <View>
            <View>
              <Text style={styles.descriptionTitle}>CV Number</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.cvNumber}</Text>
            </View>
          </View>
          <View style={{ ...styles.description, marginRight: "2%" }}>
            <View>
              <Text style={styles.descriptionTitle}>Vendor</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.vendor?.name}</Text>
            </View>
          </View>
          <View style={{ ...styles.description, marginRight: "4%" }}>
            <View>
              <Text style={styles.descriptionTitle}>CV Date</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.cvDate && new Date(data?.cvDate).toLocaleDateString()}
              </Text>
            </View>
          </View>
        </View>
        <View style={styles.descriptionContainer}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Payment Method</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.paymentMethod}</Text>
            </View>
          </View>
          <View style={{ ...styles.description, marginRight: "2%" }}>
            <View>
              <Text style={styles.descriptionTitle}>Bank</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.bank}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Check Number</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.checkNumber}</Text>
            </View>
          </View>
        </View>

        <View
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "flex-end",
          }}
        >
          <View>
            <Text style={styles.descriptionTitle}>Amount</Text>
          </View>
          <View>
            <Text style={styles.text}>
              {Number(data?.amount).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </Text>
          </View>
        </View>
        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View>
          <Text style={styles.text}>Item Information</Text>
        </View>
        {/* table */}
        <View style={styles.table}>
          <View style={styles.tableRow}>
            <View
              style={{
                width: "8%",
                textAlign: "left",
                // borderStyle: "solid",
                // borderBottom: "1px",
              }}
            >
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>Date</Text>
            </View>
            <View
              style={{
                width: "8%",
                textAlign: "left",
                // borderStyle: "solid",
                // borderBottom: "1px",
              }}
            >
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>Type</Text>
            </View>
            <View
              style={{
                width: "18%",
                textAlign: "left",
                // borderStyle: "solid",
                // borderBottom: "1px",
              }}
            >
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Counter Receipt No.
              </Text>
            </View>
            <View
              style={{
                width: "18%",
                textAlign: "left",
                // borderStyle: "solid",
                // borderBottom: "1px",
              }}
            >
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Supplier Inovice Ref
              </Text>
            </View>
            <View
              style={{
                width: "18%",
                textAlign: "left",
                // borderStyle: "solid",
                // borderBottom: "1px",
              }}
            >
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                PO No.
              </Text>
            </View>
            <View
              style={{
                width: "14%",
                textAlign: "left",
                // borderStyle: "solid",
                // borderBottom: "1px",
              }}
            >
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Gross Amount
              </Text>
            </View>
            <View
              style={{
                width: "14%",
                textAlign: "left",
                // borderStyle: "solid",
                // borderBottom: "1px",
              }}
            >
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                WH Tax
              </Text>
            </View>
          </View>
          {data?.paymentInvoices?.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <View
                style={{
                  width: "8%",
                  textAlign: "left",
                  // borderStyle: "solid",
                  // borderBottom: "1px",
                }}
              >
                <Text style={styles.tableCell}>
                  {!!item.billing?.transactionDate &&
                    new Date(
                      item.billing?.transactionDate
                    ).toLocaleDateString()}
                </Text>
              </View>
              <View
                style={{
                  width: "8%",
                  textAlign: "left",
                  // borderStyle: "solid",
                  // borderBottom: "1px",
                }}
              >
                <Text style={styles.tableCell}>{item?.type}</Text>
              </View>
              <View
                style={{
                  width: "18%",
                  textAlign: "left",
                  // borderStyle: "solid",
                  // borderBottom: "1px",
                }}
              >
                <Text style={styles.tableCell}>{item?.refNum}</Text>
              </View>
              <View
                style={{
                  width: "18%",
                  alignItems: "flex-start",
                  alignSelf: "center",
                  justifyContent: "center",
                }}
              >
                <Text style={styles.tableCell}>
                  {item?.billing?.supplierInvoiceReference
                    .trim()
                    .split(",")
                    .map((number, index, array) => {
                      const trimmedNumber = number.trim();
                      const displayNumber =
                        trimmedNumber === "" ? "N/A" : trimmedNumber;
                      return (
                        <React.Fragment key={index}>
                          {displayNumber}
                          {index !== array.length - 1 ? "," : " "}
                          {"\n"}
                        </React.Fragment>
                      );
                    })}
                </Text>
              </View>
              <View
                style={{
                  width: "18%",
                  textAlign: "left",

                  // borderStyle: "solid",
                  // borderBottom: "1px",
                }}
              >
                <Text style={styles.tableCell}>{item?.billing?.poNumber}</Text>
              </View>
              <View
                style={{
                  width: "14%",
                  textAlign: "left",
                  // borderStyle: "solid",
                  // borderBottom: "1px",
                }}
              >
                <Text style={styles.tableCell}>
                  {Number(item?.billing?.grossAmount).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
              <View
                style={{
                  width: "14%",
                  textAlign: "left",
                  // borderStyle: "solid",
                  // borderBottom: "1px",
                }}
              >
                <Text style={styles.tableCell}>
                  {Number(item?.billing?.withHoldingTax).toLocaleString(
                    "en-US",
                    {
                      style: "currency",
                      currency: "PHP",
                    }
                  )}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* refactor */}
        {/* <View
          style={{
            display: "flex",
            flexDirection: "row",
            fontSize: 10,
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Text style={{ width: "16.666667%" }}>Date</Text>
          <Text style={{ width: "12%" }}>Type</Text>
          <Text style={{ width: "25%" }}>Counter Receipt No.</Text>

          <Text style={{ width: "40%" }}>Supplier Inovice Ref</Text>

          <Text style={{ width: "16.666667%" }}>PO No.</Text>
          <Text style={{ width: "16.666667%" }}>Gross Amount</Text>
          <Text style={{ width: "16.666667%" }}>WH Tax</Text>
        </View> */}

        <hr style={{ border: "1px solid #1D4ED8",  marginBottom: "10px" }} />
        <View style={styles.descriptionContainer}>
          <View>
            <Text>{""}</Text>
          </View>
          <View>
            <Text style={styles.text}>
              Total Orig Amount:{" "}
              {Number(data?.amount).toLocaleString("en-US", {
                currency: "PHP",
                style: "currency",
              })}
            </Text>
          </View>
        </View>
        <hr style={{ border: "1px solid #1D4ED8" }} />
        <View>
          {deductions_length != 0 && (
            <View style={styles.table}>
              <View style={{ marginBottom: "10px" }}>
                <Text style={styles.text}>Total Deductions</Text>
              </View>
              <View style={{ ...styles.tableRow, marginBottom: "5px" }}>
                <View
                  style={{
                    width: "10%",
                    textAlign: "left",
                  }}
                >
                  <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                    Date
                  </Text>
                </View>
                <View
                  style={{
                    width: "20%",
                    textAlign: "left",
                  }}
                >
                  <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                    Type
                  </Text>
                </View>
                <View
                  style={{
                    width: "20%",
                    textAlign: "left",
                  }}
                >
                <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                    Ref No.
                  </Text>
                </View>
                <View
                  style={{
                    width: "20%",
                    textAlign: "left",
                  }}
                >
                  <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                    Applied To.
                  </Text>
                </View>
                <View
                  style={{
                    width: "20%",
                    textAlign: "left",
                  }}
                >
                  <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                    Payment
                  </Text>
                </View>
              </View>
              {data?.deductions?.map((deduction, index) => (
                <View style={styles.tableRow} key={index}>
                  <View
                    style={{
                      width: "10%",
                      textAlign: "left",
                    }}
                  >
                    <Text style={styles.tableCell}>
                      {!!deduction?.debitcreditmemo.documentDate &&
                        new Date(deduction?.debitcreditmemo.documentDate).toLocaleDateString()}
                    </Text>
                  </View>
                  <View
                    style={{
                      width: "20%",
                      textAlign: "left",
                    }}
                  >
                    <Text style={styles.tableCell}>
                      {deduction.debitcreditmemo.documentNumber.includes("JRNL")
                        ? "Journal"
                        : "Bill Credit"}
                    </Text>
                  </View>
                  <View
                    style={{
                      width: "20%",
                      textAlign: "left",
                    }}
                  >
                    <Text style={styles.tableCell}>
                      {deduction?.debitcreditmemo.debitCreditMemoNumber}
                    </Text>
                  </View>
                  <View
                    style={{
                      width: "20%",
                      textAlign: "left",
                    }}
                  >
                    <Text style={styles.tableCell}>
                      Bill #{deduction?.billing.billingNumber}
                    </Text>
                  </View>
                  <View
                    style={{
                      width: "20%",
                      textAlign: "left",
                    }}
                  >
                    <Text style={styles.tableCell}>
                      {`${Number(deduction?.debitcreditmemo.checkAmount).toLocaleString(
                        "en-US",
                        {
                          currency: "PHP",
                          style: "currency",
                        }
                      )}`}
                    </Text>
                  </View>
                </View>
              ))}
               <hr style={{ border: "1px solid #1D4ED8",  marginBottom: "10px", marginTop: "10px" }} />
            </View>
          )}

          <View style={styles.descriptionContainer}>
            <View>
              <Text>{""}</Text>
            </View>
            <View style={{ border: "1px solid #707070", padding: 5 }}>
              <Text style={styles.text}>
                Net Amount:{" "}
                {`${Number(data?.amount).toLocaleString("en-US", {
                  currency: "PHP",
                  style: "currency",
                })}`}
              </Text>
            </View>
          </View>
          {/* <hr style={{ border: "1px solid #707070" }} /> */}
          <View style={{ ...styles.descriptionContainer, marginTop: "5px" }}>
            <View>
              <Text>{""}</Text>
            </View>
            <View>
              <Text style={styles.text}>
                Total Withholding tax:{" "}
                {`${Number(data?.totalWithHoldingTax).toLocaleString("en-US", {
                  currency: "PHP",
                  style: "currency",
                })}`}
              </Text>
            </View>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default BillPaymentPDF;
