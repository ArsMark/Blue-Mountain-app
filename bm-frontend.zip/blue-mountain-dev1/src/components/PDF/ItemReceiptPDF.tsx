import { IItemReceiptDetails } from "@/types/ItemReceipt";
import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Image,
} from "@react-pdf/renderer";
import { format } from "date-fns";

interface Props {
  data: IItemReceiptDetails | undefined;
}

// Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    gap: 14,
    padding: 25,
    backgroundColor: "#F2F8FF",
  },
  logo: {
    width: "100",
    height: "40",
    justifyContent: "flex-start",
  },
  description: {
    display: "flex",
    flexDirection: "column",
    // justifyContent: "center",
    alignItems: "flex-start",
    // gap: 1,
  },
  descriptionLabel: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 1,
  },
  headerTitle: {
    display: "flex",
    flexDirection: "row",
    // justifyContent: "space-between",
  },
  descriptionContainer: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    // gap: 18,
    flex: 1,
  },
  descriptionTitle: { color: "#2D459C", 
  fontSize: 10,
  paddingBottom: 5 },
  text: {
    fontSize: 10,
    fontWeight: "medium",
  },
  table: {
    width: 550,
    borderRadius: "8px",
  },
  tableRow: {
    margin: "auto",
    flexDirection: "row",
  },
  tableCol: {
    width: "33%",
  },
  tableCell: {
    margin: "auto",
    marginTop: 5,
    fontSize: 10,
    marginBottom: 5,
  },
});

// Create Document Component
const ItemReceiptPDF = ({ data }: Props) => {
  const siteName = data?.warehouseLocation?.name ?? '';
  const siteAddress = data?.warehouseLocation?.address?? '';
  const gsubSiteName = siteName.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const gsubSiteAddress = siteAddress.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const isNameIncludedInAddress = gsubSiteAddress.includes(gsubSiteName);
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View>
          {data?.subsidiary && (
            <Image
              src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${data?.subsidiary.logo}`}
              style={styles.logo}
            />
          )}
        </View>
        <View style={styles.headerTitle}>
          <View>
            <Text style={styles.text}>Item Receipt</Text>
          </View>
          <View>
            <Text style={styles.text}>NO: {data?.irNumber}</Text>
          </View>
        </View>
        <View>
          <Text style={styles.text}>Primary Information</Text>
        </View>

        <View style={styles.headerTitle}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>P.O Number</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.poNumber}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>
                Supplier Invoice Reference
              </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.supplierInvoiceReference}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Received Date</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.receivedDate &&
                  new Date(data?.receivedDate).toLocaleDateString()}
              </Text>
            </View>
          </View>
        </View>

        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View>
          <Text style={styles.text}>Item Information</Text>
        </View>
       
        <View style={styles.headerTitle}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>P.O Date</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.poDate && format(new Date(data?.poDate), "yyyy-MM-dd")}
              </Text>
            </View>
          </View>
        </View>
        <View style={styles.headerTitle}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Vendor Name</Text>
            </View>
            <View style={{paddingBottom: 5}}>
              <Text style={styles.text}>{data?.vendor?.name}</Text>
            </View>
            <View>
              <Text style={styles.descriptionTitle}>Site Address</Text>
            </View>
            <View>
              <Text style={styles.text}>
                  {gsubSiteAddress}
              </Text>
            </View>
          </View>
          
        </View>
        <View style={{display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between"}}>
          <View >
            <View>
              <Text style={styles.descriptionTitle}>Site Address</Text>
            </View>
            <View>
              <Text style={{width: "100%",
                fontWeight: "medium",
                fontSize: 10}}>
                  {gsubSiteAddress}
              </Text>
            </View>
          </View>
        </View>           
        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        {/* table */}
        {/* <View style={styles.table}>
          <View style={styles.tableRow}>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Items
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Expected Quantity
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Delivered Quantity
              </Text>
            </View>
          </View>
          {data?.itemReceiptItems.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <View style={styles.tableCol}>
                <Text style={{ marginTop: 5, fontSize: 8, marginBottom: 5 }}>
                  {item.item.name}
                </Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.expectedQuantity}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.deliveredQuantity}</Text>
              </View>
            </View>
          ))}
        </View> */}
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingBottom: 5,
          }}
          >
          <Text
            style={{
              width: "50%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Item
          </Text>
          <Text
            style={{
              width: "20%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Expected Quantity
          </Text>
          <Text
            style={{
              width: "20%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Delivered Quantity
          </Text>
        </View>
        {data?.itemReceiptItems?.map((item, index) => (
          <View
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
            key={index}
          >
            <Text
              style={{
                width: "50%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {item.item.name}
            </Text>
            <Text
              style={{
                width: "12%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {item.expectedQuantity}
            </Text>
            <Text
              style={{
                width: "12%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {item.deliveredQuantity}
            </Text>
          </View>
        ))}
      
        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View style={{ display: "flex", flexDirection: "row" }}>
          <View style={styles.descriptionContainer}>
            <View style={styles.description}>
              <View>
                <Text style={styles.descriptionTitle}>Prepared By: </Text>
              </View>
              <View>
                <Text style={styles.text}>{data?.preparedBy}</Text>
              </View>
            </View>
            <View style={styles.description}>
              <View>
                <Text style={styles.descriptionTitle}>Approved By: </Text>
              </View>
              <View>
                <Text style={styles.text}>{data?.approvedBy}</Text>
              </View>
            </View>
          </View>
          <View style={styles.descriptionContainer}>
            <View style={styles.description}>
              <View>
                <Text style={styles.descriptionTitle}>Checked By: </Text>
              </View>
              <View>
                <Text style={styles.text}>{data?.checkedBy}</Text>
              </View>
            </View>
            <View style={styles.description}>
              <View>
                <Text style={styles.descriptionTitle}>Received By: </Text>
              </View>
              <View>
                <Text style={styles.text}>{data?.receivedBy}</Text>
              </View>
            </View>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default ItemReceiptPDF;
