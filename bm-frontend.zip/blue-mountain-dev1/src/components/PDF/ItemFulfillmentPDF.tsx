import { ItemFulfillmentDetails } from "@/types/IIF";
import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Image,
  Font,
} from "@react-pdf/renderer";
import { format } from "date-fns";

Font.register({
  family: "Mulish",
  src: "/assets/fonts/Mulish-Regular.ttf",
});

interface Props {
  data: ItemFulfillmentDetails | undefined;
}

// Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    fontFamily: "Mulish",
    gap: 14,
    padding: 25,
    backgroundColor: "#F2F8FF",
  },
  logo: {
    width: "100",
    height: "40",
    justifyContent: "flex-start",
  },
  description: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 1,
  },
  descriptionContainer: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  descriptionContainerDate: {
    display: "flex",
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 15,
  },
  descriptionTitle: { color: "#2D459C", fontSize: 10 },
  text: {
    fontSize: 10,
    fontWeight: "medium",
  },
  table: {
    width: 550,
    borderRadius: "8px",
  },
  tableRow: {
    margin: "auto",
    flexDirection: "row",
  },
  tableCol: {
    width: "20%",
  },
  tableCell: {
    margin: "auto",
    marginTop: 5,
    fontSize: 10,
    marginBottom: 5,
  },
});

// Create Document Component
const ItemFulfillmentPDF = ({ data }: Props) => {
  const length = data?.itemFulfillmentItems.length ?? 0;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.descriptionContainer}>
          <View>
            {data?.subsidiary && (
              <Image
                src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${data?.subsidiary.logo}`}
                style={styles.logo}
              />
            )}
          </View>
          <View>
            <Text style={styles.text}>Item Fulfillment</Text>
          </View>
        </View>

        <View style={styles.descriptionContainer}>
          <View>
            <Text style={styles.text}>Primary Information</Text>
          </View>
          <View>
            <Text style={styles.text}>NO: {data?.itemFulFillmentNumber}</Text>
          </View>
        </View>
        <View style={styles.description}>
          <View>
            <Text style={styles.descriptionTitle}>SRS No.</Text>
          </View>
          <View>
            <Text style={styles.text}>{data?.srsNo}</Text>
          </View>
        </View>

        <View style={styles.descriptionContainerDate}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Vendor</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.vendor.name}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Location</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.location}</Text>
            </View>
          </View>
        </View>
        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        {/* date */}
        <View>
          <Text style={styles.text}>Date Information</Text>
        </View>
        <View style={styles.descriptionContainerDate}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Date Created</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.createdAt &&
                  format(new Date(data?.createdAt), "yyyy-MM-dd")}
              </Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Deadline for Pull Out</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.pullOutDate &&
                  format(new Date(data?.pullOutDate), "yyyy-MM-dd")}
              </Text>
            </View>
          </View>
        </View>

        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View>
          <Text style={styles.text}>Item Information</Text>
        </View>
        {/* table */}
        {/* <View style={styles.table}>
          <View style={styles.tableRow}>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Barcode
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Item Desription
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Quantity
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>Cost</Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Total Amount
              </Text>
            </View>
          </View>
          {data?.itemFulfillmentItems?.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.item.barcode}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.item.description}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.quantity}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.item.cost).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.totalAmount).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
            </View>
          ))}
        </View> */}
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            paddingBottom: 8,
          }}
        >
          <Text
            style={{
              width: "16.66%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Barcode
          </Text>
          <Text
            style={{
              width: "50%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Item Desription
          </Text>
          <Text
            style={{
              width: "12%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Quantity
          </Text>
          <Text
            style={{
              width: "12%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Cost
          </Text>
          <Text
            style={{
              width: "16.66%",
              fontWeight: "medium",
              color: "#1D4ED8",
              fontSize: 10,
            }}
          >
            Amount
          </Text>
        </View>
        {data?.itemFulfillmentItems?.map((item, index) => (
          <View
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
            key={index}
          >
            <Text
              style={{
                width: "16.66%",
                fontWeight: "medium",

                fontSize: 8,
              }}
            >
              {item.item.barcode}
            </Text>
            <Text
              style={{
                width: "50%",
                fontWeight: "medium",
                fontSize: 8,
                margin: "auto",
              }}
            >
              {item.item.description}
            </Text>
            <Text
              style={{
                width: "12%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {item.quantity}
            </Text>
            <Text
              style={{
                width: "12%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {Number(item.item.cost).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </Text>
            <Text
              style={{
                width: "16.66%",
                fontWeight: "medium",
                fontSize: 8,
              }}
            >
              {Number(item.totalAmount).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </Text>
          </View>
        ))}

        <View break={length > 10 ? true : false}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Prepared By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.preparedBy}</Text>
            </View>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default ItemFulfillmentPDF;
