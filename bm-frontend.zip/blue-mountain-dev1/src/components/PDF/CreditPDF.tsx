import { IDebitCreditDetails } from "@/types/ICredit";
import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Font,
} from "@react-pdf/renderer";

Font.register({
  family: "Mulish",
  src: "/assets/fonts/Mulish-Regular.ttf",
});

// Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    gap: 16,
    padding: 25,
    backgroundColor: "#F2F8FF",
  },
  logo: {
    width: "100",
    height: "40",
    justifyContent: "flex-start",
  },
  description: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 1,
    width: "100%",
  },
  descriptionContainer: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  descriptionTitle: { color: "#2D459C", fontSize: 10 },
  text: {
    fontSize: 10,
    fontWeight: "medium",
  },
});

// Create Document Component
const DebitPDF = ({ data }: { data: IDebitCreditDetails | undefined }) => {
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View>
          <Text style={styles.text}>Debit Memo</Text>
        </View>

        {/* date */}
        <View style={styles.descriptionContainer}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Document No</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.documentNumber}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Date</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.documentDate &&
                  new Date(data?.documentDate).toLocaleDateString()}
              </Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Reference No.</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.referenceNumber}</Text>
            </View>
          </View>
        </View>
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Bill To</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.billTo}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Bill Address</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.billingAddress}</Text>
            </View>
          </View>
        </View>

        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View>
          <Text style={styles.descriptionTitle}>Particular</Text>
        </View>

        <View>
          <Text style={styles.text}>{data?.particular}</Text>
        </View>
        <View style={{ display: "flex", gap: 2, flexDirection: "row" }}>
          <Text style={styles.descriptionTitle}>Total Amount: </Text>
          <Text style={styles.text}>
            {Number(data?.total).toLocaleString("en-US", {
              currency: "PHP",
              style: "currency",
            })}
          </Text>
        </View>
        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>

        <View style={styles.descriptionContainer}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Prepared By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.preparedBy}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Checked By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.checkedBy}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Approved By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.approvedBy}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Received By: </Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.receivedBy}</Text>
            </View>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default DebitPDF;
