import { IBillModal } from "@/types/IBillModal";
import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Font,
  Image,
} from "@react-pdf/renderer";

Font.register({
  family: "Mulish",
  src: "/assets/fonts/Mulish-Regular.ttf",
});

// Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    fontFamily: "Mulish",
    gap: 14,
    padding: 25,
    backgroundColor: "#F2F8FF",
  },
  logo: {
    width: "100",
    height: "40",
    justifyContent: "flex-start",
  },
  description: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 1,
  },
  descriptionContainer: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    marginTop: 5,
    marginBottom: 5,
    justifyContent: "space-between",
    // gap: 15,
  },
  descriptionTitle: { color: "#2D459C", fontSize: 10 },
  text: {
    fontSize: 10,
    fontWeight: "medium",
  },
  table: {
    width: 550,
    borderRadius: "8px",
  },
  tableRow: {
    margin: "auto",
    flexDirection: "row",
  },
  tableCol: {
    width: "16%",
  },
  tableCell: {
    margin: "auto",
    marginTop: 5,
    fontSize: 10,
    marginBottom: 5,
  },
});

// Create Document Component
const BillPDF = ({ data }: { data: IBillModal}) => {
  const osd = data?.otherSpecialDiscount ?? 0;
  const ctd = data?.centralTlcDiscount ?? 0;
  const ttd = data?.tradeDiscount ?? 0;
  const tcdd = data?.centralDropDiscount ?? 0;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View>
          {data?.subsidiary && (
            <Image
              src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${data?.subsidiary.logo}`}
              style={styles.logo}
            />
          )}
        </View>

        <View>
          <Text style={styles.text}>Bill</Text>
        </View>
        <View>
          <Text style={styles.text}>Primary Information</Text>
        </View>

        {/* date */}
        <View style={styles.descriptionContainer}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Transaction #</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.billingNumber}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Vendor</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.vendor?.name}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Terms</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.terms}</Text>
            </View>
          </View>
        </View>

        <View>
          <Text style={styles.text}>Remarks</Text>
        </View>
        <View style={styles.descriptionContainer}>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Transaction Date</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.transactionDate &&
                  new Date(data?.transactionDate).toLocaleDateString()}
              </Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Due Date</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {!!data?.dueDate &&
                  new Date(data?.dueDate).toLocaleDateString()}
              </Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>P.O Number</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.poNumber}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>I.R Number</Text>
            </View>
            <View>
              <Text style={styles.text}>{data?.irNumber}</Text>
            </View>
          </View>
          <View style={styles.description}>
            <View>
              <Text style={styles.descriptionTitle}>Status</Text>
            </View>
            <View>
              {data?.isRead ? (
                <Text style={{ color: "green", fontSize: 10 }}>Read</Text>
              ) : (
                <Text style={{ color: "red", fontSize: 10 }}>Unread</Text>
              )}
            </View>
          </View>
        </View>
        <View>
          <hr style={{ border: "1px solid #2D459C" }} />
        </View>
        <View>
          <Text style={styles.text}>Billing Information</Text>
        </View>
        {/* table */}
        <View style={styles.table}>
          <View style={styles.tableRow}>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>Item</Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Gross Amount
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Tax Amount
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Net Amount
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Discount
              </Text>
            </View>
            <View style={styles.tableCol}>
              <Text style={[styles.tableCell, { color: "#1a245c" }]}>
                Total
              </Text>
            </View>
          </View>
          {data?.billingPOs.map((item, index) => (
            <View style={styles.tableRow} key={index}>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>{item.item.name}</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.grossAmount).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.taxAmount).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.netAmount).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.discount).toLocaleString("en-US", {
                    style: "percent",
                  })}
                </Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableCell}>
                  {Number(item.total).toLocaleString("en-US", {
                    style: "currency",
                    currency: "PHP",
                  })}
                </Text>
              </View>
            </View>
          ))}
        </View>
        <View style={ {marginTop: 3}}>
          <View>
            <hr style={{ border: "1px solid #2D459C" }} />
          </View>
          <View style={styles.descriptionContainer}>
            <View>
              <Text style={{ fontSize: 10 }}>Total</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {Number(data?.grossAmount).toLocaleString("en-US", {
                  style: "currency",
                  currency: "PHP",
                })}
              </Text>
            </View>
          </View>
          <View>
            <hr style={{ border: "1px solid #2D459C" }} />
          </View>
          <View>
            <Text style={styles.descriptionTitle}>Discount</Text>
          </View>

          <View style={styles.descriptionContainer}>
            <View>
              <Text style={{ fontSize: 10 }}>Trade Discount</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {Number(data?.tradeDiscount).toLocaleString("en-US", {
                  style: "currency",
                  currency: "PHP",
                })}
              </Text>
            </View>
          </View>

          <View style={styles.descriptionContainer}>
            <View>
              <Text style={{ fontSize: 10 }}>Central Drop Discount</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {Number(data?.centralDropDiscount).toLocaleString("en-US", {
                  style: "currency",
                  currency: "PHP",
                })}
              </Text>
            </View>
          </View>
          {ctd > 0 && (
          <View style={styles.descriptionContainer}>
            <View>
              <Text style={{ fontSize: 10 }}>Central TLC Discount</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {Number(ctd).toLocaleString("en-US", {
                  style: "currency",
                  currency: "PHP",
                })}
              </Text>
            </View>
          </View>
          )}
        {osd > 0 && (
          <View style={styles.descriptionContainer}>
            <View>
              <Text style={{ fontSize: 10 }}>Other Special Discount</Text>
            </View>
            <View>
              <Text style={styles.text}>
                {Number(osd).toLocaleString('en-US', {
                  style: 'currency',
                  currency: 'PHP',
                })}
              </Text>
            </View>
          </View>
        )}
          
          
        </View>
      </Page>
    </Document>
  );
};

export default BillPDF;
