import { string, z } from "zod";

export const PaymentSchema = z
  .object({
    transaction_no: string().optional(),
    check_date_from: z.date().optional(),
    check_date_to: z.date().optional(),
    read_status: z.string(),
    releasing_date_from: z.date().optional(),
    releasing_date_to: z.date().optional(),
    results: z.string(),
    vendor_name: z.string(),
    voucher_name: z.string(),
  })
  .refine(
    (data) =>
      new Date(data.check_date_to ?? "3000-01-01") >=
      new Date(data.check_date_from ?? "1000-01-01"),
    {
      path: ["check_date_to"],
      message: "End date cannot be earlier than start date.",
    }
  )
  .refine(
    (data) =>
      new Date(data.releasing_date_to ?? "3000-01-01") >=
      new Date(data.releasing_date_from ?? "1000-01-01"),
    {
      path: ["releasing_date_to"],
      message: "End date cannot be earlier than start date.",
    }
  )
  .refine(
    (data) => {
      if (data.check_date_from && !data.check_date_to) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["check_date_to"], message: "End date is required" }
  )
  .refine(
    (data) => {
      if (data.check_date_to && !data.check_date_from) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["check_date_from"], message: "Start date is required" }
  )
  .refine(
    (data) => {
      if (data.releasing_date_from && !data.releasing_date_to) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["releasing_date_to"], message: "End date is required" }
  )
  .refine(
    (data) => {
      if (data.releasing_date_to && !data.releasing_date_from) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["releasing_date_from"], message: "Start date is required" }
  );
