import { z } from "zod";

export const VRASchema = z
  .object({
    document_status: z.string(),
    pullout_date_from: z.date().optional(),
    pullout_date_to: z.date().optional(),
    quantity: z
      .string()
      .refine((val) => !isNaN(Number(val)), {
        message: "Quantity should be a number!",
      })
      .default(""),
    read_status: z.string(),
    results: z.string(),
    total_amount: z
      .string()
      .refine((val) => !isNaN(Number(val)), {
        message: "Total amount should be a number!",
      })
      .default(""),
    vendor_name: z.string(),
    vra_number: z.string(),
    warehouse_location: z.string(),
  })
  .refine(
    (data) =>
      new Date(data.pullout_date_to ?? "3000-01-01") >=
      new Date(data.pullout_date_from ?? "1000-01-01"),
    {
      path: ["pullout_date_to"],
      message: "End date cannot be earlier than start date.",
    }
  )
  .refine(
    (data) => {
      if (data.pullout_date_from && !data.pullout_date_to) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["pullout_date_to"], message: "End date is required" }
  )
  .refine(
    (data) => {
      if (data.pullout_date_to && !data.pullout_date_from) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["pullout_date_from"], message: "Start date is required" }
  );
