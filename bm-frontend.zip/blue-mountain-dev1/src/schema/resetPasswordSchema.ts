import { z } from "zod"

export const resetPasswordSchema = z.object({
    new_password: z.string().min(6, { message: "Password must be at least 6 characters" }),
    confirm_password: z.string().min(6, { message: "Password must be at least 6 characters" }),
}).refine((data) => data.confirm_password === data.new_password, {
    message: "Passwords do not match",
    path: ["confirm_password"]
})