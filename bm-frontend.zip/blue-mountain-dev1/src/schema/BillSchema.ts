import { z } from "zod";

export const BillSchema = z
  .object({
    post_date_from: z.date().optional(),
    post_date_to: z.date().optional(),
    doc_date_from: z.date().optional(),
    doc_date_to: z.date().optional(),
    document_status: z.string().optional(),
    read_status: z.string().optional(),
    results: z.string().optional(),
    vendor_name: z.string().optional(),
    warehouse_location: z.string().optional(),
  })
  .refine(
    (data) =>
      new Date(data.post_date_to ?? "3000-01-01") >=
      new Date(data.post_date_from ?? "1000-01-01"),
    {
      path: ["post_date_to"],
      message: "End date cannot be earlier than start date.",
    }
  )
  .refine(
    (data) =>
      new Date(data.doc_date_to ?? "3000-01-01") >=
      new Date(data.doc_date_from ?? "1000-01-01"),
    {
      path: ["doc_date_to"],
      message: "End date cannot be earlier than start date.",
    }
  )
  .refine(
    (data) => {
      if (data.doc_date_from && !data.doc_date_to) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["doc_date_to"], message: "End date is required" }
  )
  .refine(
    (data) => {
      if (data.doc_date_to && !data.doc_date_from) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["doc_date_from"], message: "Start date is required" }
  )
  .refine(
    (data) => {
      if (data.post_date_from && !data.post_date_to) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["post_date_to"], message: "End date is required" }
  )
  .refine(
    (data) => {
      if (data.post_date_to && !data.post_date_from) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["post_date_from"], message: "Start date is required" }
  );
