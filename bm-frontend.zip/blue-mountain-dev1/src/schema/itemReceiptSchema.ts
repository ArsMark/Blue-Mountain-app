import { z } from "zod";
export const itemReceiptSchema = z
  .object({
    ir_number: z.string(),
    document_status: z.string(),
    po_number: z.string(),
    receipt_date_from: z.date().optional(),
    receipt_date_to: z.date().optional(),
    vendor_name: z.string(),
    delivery_date_from: z.date().optional(),
    delivery_date_to: z.date().optional(),
    warehouse_location: z.string(),
    read_status: z.string().optional(),
    results: z.string(),
  })
  .refine(
    (data) =>
      new Date(data.receipt_date_to ?? "3000-01-01") >=
      new Date(data.receipt_date_from ?? "1000-01-01"),
    {
      path: ["receipt_date_to"],
      message: "End date cannot be earlier than start date.",
    }
  )
  .refine(
    (data) =>
      new Date(data.delivery_date_to ?? "3000-01-01") >=
      new Date(data.delivery_date_from ?? "1000-01-01"),
    {
      path: ["delivery_date_to"],
      message: "End date cannot be earlier than start date.",
    }
  )
  .refine(
    (data) => {
      if (data.receipt_date_from && !data.receipt_date_to) {
        return false;
      }
      return true;
    },
    {
      path: ["receipt_date_to"],
      message: "End date is required",
    }
  )
  .refine(
    (data) => {
      if (!data.receipt_date_from && data.receipt_date_to) {
        return false;
      }
      return true;
    },
    {
      path: ["delivery_date_from"],
      message: "Start date is required",
    }
  )
  .refine(
    (data) => {
      if (data.delivery_date_from && !data.delivery_date_to) {
        return false;
      }
      return true;
    },
    {
      path: ["delivery_date_to"],
      message: "End date is required",
    }
  )
  .refine(
    (data) => {
      if (!data.delivery_date_from && data.delivery_date_to) {
        return false;
      }
      return true;
    },
    {
      path: ["delivery_date_from"],
      message: "Start date is required",
    }
  );
