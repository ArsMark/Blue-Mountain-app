import { z } from "zod"

export const ContactSchema = z.object({
    fullName: z.string({ required_error: "This field is required!" }),
    departmentId: z.string({ required_error: "This field is required!" }),
    senderEmail: z.string({ required_error: "This field is required!" }),
    subject: z.string({ required_error: "This field is required!" }),
    content: z.string({ required_error: "This field is required!" })
})