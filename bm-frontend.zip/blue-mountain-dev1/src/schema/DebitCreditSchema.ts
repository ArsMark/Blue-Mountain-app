import { z } from "zod";

export const DebitCreditSchema = z
  .object({
    dm_number: z.string(),
    vendorName: z.string(),
    dm_status: z.string(),
    document_date_from: z.date().optional(),
    document_date_to: z.date().optional(),
    posting_type: z.string(),
    read_status: z.string(),
    results: z.string(),
  })
  .refine(
    (data) =>
      new Date(data.document_date_to ?? "3000-01-01") >=
      new Date(data.document_date_from ?? "1000-01-01"),
    {
      path: ["document_date_to"],
      message: "End date cannot be earlier than start date.",
    }
  )
  .refine(
    (data) => {
      if (data.document_date_from && !data.document_date_to) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["document_date_to"], message: "End date is required" }
  )
  .refine(
    (data) => {
      if (data.document_date_to && !data.document_date_from) {
        return false;
      } else {
        return true;
      }
    },
    { path: ["document_date_from"], message: "Start date is required" }
  );
