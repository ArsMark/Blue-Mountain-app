import { z } from "zod"

export const passwordSchema = z.object({
    currentPassword: z.string(),
    newPassword: z.string().min(6, { message: "Password must be at least 6 characters" }),
    confirmNewPassword: z.string().min(6, { message: "Password must be at least 6 characters" }),
}).refine((data) => data.confirmNewPassword === data.newPassword, {
    message: "Passwords do not match",
    path: ["confirm_password"]
})

export const forgotPasswordSchema = z.object({
    email: z.string().email({ message: "Please provide a valid email" }),
})