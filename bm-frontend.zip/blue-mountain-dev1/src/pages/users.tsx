import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { DataTable } from "@/components/ui/tables/DataTable";
import DebouncedInput from "@/components/ui/tables/DebounceInput";
import { FormSchema } from "@/schema/FormSchema";
import { zodResolver } from "@hookform/resolvers/zod";
import { ColumnDef } from "@tanstack/react-table";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { GetServerSidePropsContext } from "next";
import api from "@/utils/api";
import { IAuth } from "@/types/IAuth";

type FormValues = z.infer<typeof FormSchema>;

const AdminVendorPage = () => {
  const [searchText, setSearchText] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      name: "",
      confirmPassword: "",
      email: "",
      password: "",
      role: "",
    },
  });

  const pageColumns: ColumnDef<any>[] = [
    {
      accessorKey: "firstName",
      header: "First Name",
    },
    {
      accessorKey: "lastName",
      header: "Last Name",
    },
    {
      accessorKey: "email",
      header: "Email Address",
    },
    {
      accessorKey: "role",
      header: "Role",
    },
    {
      id: "actions",
      header: "Actions",
    },
  ];

  const onSubmit = (values: any) => {
    console.log(values);
  };

  const onCancel = () => {
    setIsOpen(false);
    form.reset();
  };

  return (
    <>
      <h1 className="scroll-m-20 text-2xl font-medium tracking-tight mb-2">
        Admin / Vendor
      </h1>
      <div className="flex justify-between items-center mb-4">
        <DebouncedInput
          value={searchText ?? ""}
          onChange={(val) => setSearchText(String(val))}
          className="w-1/4"
        />
        <Button onClick={() => setIsOpen(true)} className="w-fit">
          Add New Users
        </Button>
      </div>
      <DataTable columns={pageColumns} data={[]} displayPagination total={0}  textAlign="text-center"/>
      <Dialog open={isOpen} onOpenChange={onCancel}>
        <DialogContent className="md:min-w-[40vw]">
          <DialogHeader>
            <DialogTitle>Add New Users</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4 items-center">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Role</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="vendor">Vendor</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input {...field} type="password" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirm Password</FormLabel>
                      <FormControl>
                        <Input {...field} type="password" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button type="submit" className="w-1/4">
                  Submit
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AdminVendorPage;

export async function getServerSideProps(context: GetServerSidePropsContext) {
  const cookie = context.req.cookies?.user;

  const response = await api.get("/api/auth/me", {
    headers: {
      Authorization: "Bearer " + cookie,
    },
  });
  const data: IAuth = await response.data;

  if (data.role === "vendor") {
    return {
      redirect: {
        destination: "/home",
        permanent: false,
      },
    };
  }
  return {
    props: {
      data,
    },
  };
}
