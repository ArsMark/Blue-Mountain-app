import React, { useState } from "react";
import waves from "../../public/images/waves.png";
import Image from "next/image";
import bmLogo from "../../public/images/bm_logo.png";
import brlLogo from "../../public/images/barrelman_logo.png";
import { Input } from "@/components/ui/input";
import { z } from "zod";
import { loginSchema } from "@/schema/loginSchema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { useAuthLogin } from "@/utils/hooks/useLogin";
import Spinner from "@/components/ui/spinner";
import { Eye, EyeOff } from "lucide-react";
import Link from "next/link";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { forgotPasswordSchema } from "@/schema/passwordSchema";
import { useResetPasswordLink } from "@/utils/hooks/usePassword";

type FormValues = z.infer<typeof loginSchema>;
type passwordValues = z.infer<typeof forgotPasswordSchema>;

const LoginPage = () => {
  const [toggle, setToggle] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const form = useForm<FormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const passwordForm = useForm<passwordValues>({
    defaultValues: {
      email: "",
    },
    resolver: zodResolver(forgotPasswordSchema),
  });
  const { mutate, isLoading } = useAuthLogin();
  const { mutate: forgotPassword, isLoading: isForgotLoading } =
    useResetPasswordLink();

  const onSubmit = (data: FormValues) => {
    mutate(data);
  };

  const toggleIcon = () => {
    setToggle((prev) => !prev);
  };

  const onSubmitPassword = (values: passwordValues) => {
    const data = {
      email: values.email,
      link: `${process.env.NEXT_PUBLIC_DOMAIN_URL}/reset-password`,
    };
    forgotPassword(data, {
      onSuccess: () => {
        setIsModalOpen(false);
      },
    });
  };

  return (
    <div className="bg-[#ECF3FE] min-h-screen relative">
      <div className="w-full p-4 mx-auto absolute top-[45%] left-1/2 transform -translate-x-1/2 -translate-y-1/2 md:w-[60vw] lg:w-[30vw]">
        <div className="flex justify-between items-center">
          <Image
            src={bmLogo}
            alt="Blue Mountain Logo"
            className="w-32 h-16 md:w-48 md:h-24"
            draggable={false}
          />
          <Image
            src={brlLogo}
            alt="Barrel Man Logo"
            className="w-32 h-16 md:w-48 md:h-24"
            draggable={false}
          />
        </div>
        <div>
          <h1 className="text-2xl font-medium text-center my-2">Sign In</h1>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
              <FormField
                control={form.control}
                name="email"
                rules={{
                  required: true,
                }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter your email address..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                rules={{
                  required: true,
                }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          placeholder="Enter your password..."
                          {...field}
                          type={toggle ? "text" : "password"}
                        />
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 cursor-pointer">
                          {toggle ? (
                            <EyeOff className="h-5 w-5" onClick={toggleIcon} />
                          ) : (
                            <Eye className="h-5 w-5" onClick={toggleIcon} />
                          )}
                        </div>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                type="button"
                className="p-0 flex justify-start w-fit"
                variant="link"
                onClick={() => setIsModalOpen(true)}
              >
                Forgot Password
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? <Spinner /> : "Sign In"}
              </Button>
            </form>
          </Form>
        </div>
      </div>
      <div className="absolute inset-x-0 bottom-0 z-0">
        <Image src={waves} alt="Waves images" draggable={false} />
      </div>
      <Dialog onOpenChange={(val) => setIsModalOpen(val)} open={isModalOpen}>
        <DialogContent className="w-3/4 md:min-w-1/4">
          <DialogHeader>
            <DialogTitle>Forgot Password</DialogTitle>
            <DialogDescription className="text-sm">
              Enter the email address associated with your account and {"we'll"}{" "}
              send you a link to reset your password.
            </DialogDescription>
          </DialogHeader>
          <Form {...passwordForm}>
            <form onSubmit={passwordForm.handleSubmit(onSubmitPassword)}>
              <FormField
                control={passwordForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end">
                <Button type="submit" className="mt-2 md:w-1/5">
                  {isForgotLoading ? <Spinner /> : "Continue"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

LoginPage.getLayout = function getLayout(page: React.ReactElement) {
  return <>{page}</>;
};

export default LoginPage;
