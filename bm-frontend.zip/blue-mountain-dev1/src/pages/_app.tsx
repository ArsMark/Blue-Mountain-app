import Layout from "@/components/ui/layout/Layout";
import "@/styles/globals.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import type { NextComponentType } from "next";
import { AppContext, AppInitialProps, AppLayoutProps } from "next/app";
import dynamic from "next/dynamic";
import Head from "next/head";
import NextNProgress from "nextjs-progressbar";
import { Mulish } from "next/font/google";
import { getCookie } from "cookies-next";

const mulish = Mulish({ subsets: ["latin"] });

const Toaster = dynamic(
  () => import("react-hot-toast").then((c) => c.Toaster),
  {
    ssr: false,
  }
);

const App: NextComponentType<AppContext, AppInitialProps, AppLayoutProps> = ({
  Component,
  pageProps,
}: AppLayoutProps) => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        refetchInterval: false,
        refetchOnWindowFocus: false,
      },
    },
  });

  if (Component.getLayout) {
    return Component.getLayout(
      <main className={mulish.className}>
        <QueryClientProvider client={queryClient}>
          <NextNProgress
            color="#2D459C"
            height={5}
            options={{
              easing: "ease",
              speed: 500,
              trickleSpeed: 500,
              showSpinner: false,
            }}
          />
          <Head>
            <title>Blue Mountain</title>
          </Head>

          <Component {...pageProps} />

          <Toaster />
        </QueryClientProvider>
      </main>
    );
  }
  const subsidiaryId = getCookie("subsidiaryId");

  return (
    <main className={mulish.className}>
      <QueryClientProvider client={queryClient}>
        <Layout>
          <NextNProgress
            color="#2D459C"
            height={5}
            options={{
              easing: "ease",
              speed: 500,
              trickleSpeed: 500,
              showSpinner: false,
            }}
          />
          <Head>
            <title>Blue Mountain</title>
            <link
              rel="icon"
              type="image/png"
              sizes="32x32"
              href={
                subsidiaryId === "1"
                  ? "/images/barrel-favicon-32x32.png"
                  : "/images/bm-favicon-32x32.png"
              }
            />
            <link
              rel="icon"
              type="image/png"
              sizes="16x16"
              href={
                subsidiaryId === "1"
                  ? "/images/barrel-favicon-16x16.png"
                  : "/images/bm-favicon-16x16.png"
              }
            />
          </Head>
          <Component {...pageProps} />
          <Toaster />
        </Layout>
      </QueryClientProvider>
    </main>
  );
};
export default App;
