import { useEffect, useMemo, useReducer, useRef, useState } from "react";
import { format } from "date-fns";
import { saveAs } from "file-saver";
import { CalendarIcon } from "lucide-react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { AiFillPrinter } from "react-icons/ai";
import { FaFileDownload } from "react-icons/fa";
import { HiEye } from "react-icons/hi";
import { useReactToPrint } from "react-to-print";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { pdf } from "@react-pdf/renderer";
import { ColumnDef, PaginationState } from "@tanstack/react-table";

import BillPaymentPDF from "@/components/PDF/BillPaymentPDF";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import Image from "next/image";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Spinner from "@/components/ui/spinner";
import { DataTable } from "@/components/ui/tables/DataTable";
import DebouncedInput from "@/components/ui/tables/DebounceInput";
import { cn } from "@/lib/utils";
import LoadingScreen from "@/components/ui/loading";
import { PaymentSchema } from "@/schema/PaymentSchema";
import {
  IPaymentDetails,
  DebitCreditBill,
  PaymentInvoices,
  Payment as PaymentTypes,
} from "@/types/IPayment";
import { useActionDownload } from "@/utils/hooks/useActionDownload";
import { useAuthMe } from "@/utils/hooks/useAuth";
import Unauthorized from "@/components/ui/unauthorized";
import { usePaymentDetails, usePaymentTable } from "@/utils/hooks/usePayment";
import axios from "axios";
import { getCookie } from "cookies-next";
import { useWorker } from "@/utils/hooks/useWorker";

export type FormValues = z.infer<typeof PaymentSchema>;

const Payment = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [isDownload, setIsDownload] = useState(false);
  const [isCsvDownload, setIsCsvDownload] = useState(false);
  const [userId, setUserId] = useState(0);
  const [isImporting, setIsImporting] = useState(false);


  const { data: workerData, refetch: refetch_worker } = useWorker();


  useEffect(() => {
    const interval = setInterval(() => {
      if (workerData?.data?.payment?.onQueue) {
        refetch_worker().then((updatedData) => {
          if (!updatedData.data.data.payment.onQueue && updatedData.data.data.payment.isFetching) {
            toast.success("Payment data is now fetching");
          }
        });
      }

      if (workerData?.data?.payment?.isFetching) {
        refetch_worker().then((updatedData) => {

          console.log(updatedData.data)
          if (!updatedData.data.data.payment.isFetching) {
            console.log("DONE")
            toast.success("Payment data has been fetched successfully");
          }
        });
      }
    }, 60000);

    return () => clearInterval(interval);
  }, [workerData, refetch_worker]);

  const [formValue, setFormValue] = useState<FormValues>({
    transaction_no: undefined,
    check_date_from: undefined,
    check_date_to: undefined,
    read_status: "all",
    releasing_date_from: undefined,
    releasing_date_to: undefined,
    results: "10",
    vendor_name: "",
    voucher_name: "",
  });
  const [page, setPage] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: Number(formValue.results),
  });

  const pagination = useMemo(() => {
    return {
      pageIndex: page.pageIndex,
      pageSize: Number(formValue.results),
    };
  }, [page, formValue]);

  const {
    data,
    isFetching: isFetchingPaymentTable,
  } = usePaymentTable(
    formValue,
    pagination,
    searchText,
    isCsvDownload,
    setIsCsvDownload
  );

  const {
    data: modalData,
    isSuccess,
    isLoading: isFetchingPaymentDetails,
  } = usePaymentDetails(userId);
  const { mutate } = useActionDownload();
  const { data: userData } = useAuthMe();
  const currentRole = userData?.role == 'vendor'
  const form = useForm<FormValues>({
    resolver: zodResolver(PaymentSchema),
    defaultValues: {
      transaction_no: undefined,
      check_date_from: undefined,
      check_date_to: undefined,
      read_status: "all",
      releasing_date_from: undefined,
      releasing_date_to: undefined,
      results: "10",
      vendor_name: "",
      voucher_name: "",
    },
  });

  const modalRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    content: () => modalRef.current,
  });

  useEffect(() => {
    if (formValue || searchText) {
      setPage({
        pageIndex: 0,
        pageSize: Number(formValue.results),
      });
    }
  }, [formValue, searchText]);

  useEffect(() => {
    if (modalData && isDownload && isSuccess) {
      downloadPDF(modalData);
    }
  }, [modalData, isDownload, isSuccess]);

  const downloadPDF = async (data: any) => {
    const blob = await pdf(<BillPaymentPDF data={data} />).toBlob();
    const url = URL.createObjectURL(blob);
    // PDF in a new tab pra di rekta dl
    window.open(url, "_blank");
    // saveAs(blob, `Bill Payment ${modalData?.cvNumber}.pdf`);
    // mutate({ action: "Downloaded a Bill Payment." });
    setIsDownload(false);
  };

  const onSubmit = (values: FormValues) => {
    setFormValue(values);
    toast.success("Filter has been applied");
  };

  const handleClearFilter = () => {
    const initialValues = {
      check_amount: undefined,
      read_status: "all",
      results: "10",
      vendor_name: "",
      voucher_name: "",
    };

    form.reset(initialValues);
    setFormValue(initialValues);
    toast.success("Filter has been cleared");
  };
  const columns: ColumnDef<PaymentTypes>[] = [
    {
      accessorKey: "transactionNo",
      header: "TRANSACTION #",
    },
    {
      id: "vendorName",
      accessorKey: "vendor.name",
      header: "VENDOR NAME",
      cell: ({ row }) => {
        return (
          <div className="truncate overflow-hidden w-[200px] mx-auto">
            {row.original.vendor.name}
          </div>
        );
      },
    },
    {
      accessorKey: "cvDate",
      header: "CHECK DATE",
      cell: ({ row }) => {
        return <div>{new Date(row.original.cvDate).toLocaleDateString()}</div>;
      },
    },
    {
      accessorKey: "amount",
      header: "AMOUNT",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.amount).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    {
      accessorKey: "releaseDate",
      header: "RELEASE DATE",
      cell: ({ row }) => {
        return (
          <div>{new Date(row.original.releaseDate).toLocaleDateString()}</div>
        );
      },
    },
    {
      accessorKey: "actions",
      header: "ACTIONS",
      //getting data every row
      cell: ({ row }) => {
        return (
          <div className="flex gap-1 justify-center">
            <Button
              variant="icon"
              onClick={() => {
                getRows(row.original.id);
              }}
              className="w-8 h-8"
              size="icon"
            >
              <HiEye size="20" />
            </Button>
            <Button
              className="w-8 h-8"
              variant="icon"
              onClick={() => {
                setIsOpen(true);
                setUserId(row.original.id);
                mutate({ action: "Printed a Bill Payment." });
                toast.loading("Printing...", { duration: 3000 });
                setTimeout(handlePrint, 3000);
              }}
              size="icon"
            >
              <AiFillPrinter size="20" />
            </Button>
            <Button
              className="w-8 h-8"
              size="icon"
              variant="icon"
              onClick={() => {
                setUserId(row.original.id);
                toast.loading("Downloading PDF...", { duration: 3000 });
                setIsDownload(true);
              }}
            >
              <FaFileDownload size="20" />
            </Button>
          </div>
        );
      },
    },
  ];
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("excelFile", file);

    try {
      setIsImporting(true);
      await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/api/billings/upload-billings`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          "Authorization": "Bearer " + getCookie("user")
        },
      });
      toast.success("File uploaded successfully!");
    } catch (error: any) {
      console.error("File upload error: ", error);
      toast.error("Failed to upload the file.");

      console.error("File upload failed:", error);

      // if (error.response) {
      //   console.error("Response data:", error.response.data);
      //   console.error("Response status:", error.response.status);
      //   console.error("Response headers:", error.response.headers);
      //   alert(`File upload failed: ${error.response.data.message || 'Server error'}`);
      // } else if (error.request) {
      //   console.error("Request made but no response:", error.request);
      //   alert("No response from the server.");
      // } else {
      //   console.error("Error during setup of request:", error.message);
      //   alert(`Error during file upload: ${error.message}`);
      // }
    } finally {
      setIsImporting(false)
    }
  }
  const modalTableCol: ColumnDef<PaymentInvoices>[] = [
    {
      accessorKey: "applyDate",
      header: "Date",
      cell: ({ row }) => {
        return (
          <div className="text-center">
            {row.original.applyDate
              ? new Date(row.original.applyDate).toLocaleDateString()
              : ""}
          </div>
        );
      },
    },
    {
      accessorKey: "type",
      header: "Type",
      cell: ({ row }) => {
        return <div className="text-center">{row.original.type}</div>;
      },
    },
    {
      accessorKey: "refNum",
      header: "Counter Receipt No.",
      cell: ({ row }) => {
        return <div className="text-center">{row.original.refNum}</div>;
      },
    },
    {
      accessorKey: "billing.supplierInvoiceReference",
      header: "Supplier Invoice Ref",
      cell: ({ row }) => {
        const supplierInvoice = row.original.billing?.supplierInvoiceReference;

        const splitInvoices = supplierInvoice?.split(",")?.join(", ");

        return <div className="text-center">{splitInvoices}</div>;
      },
    },
    {
      accessorKey: "billing.poNumber",
      header: "PO #",
      cell: ({ row }) => {
        return (
          <div className="text-center">{row.original.billing?.poNumber}</div>
        );
      },
    },
    {
      accessorKey: "paymentAmount",
      header: "Gross Amount",
      cell: ({ row }) => {
        return (
          <div className="text-center">
            {Number(row.original.type == 'Journal' ? row.original.paymentAmount :
              row.original.billing?.grossAmount ?? 0).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
          </div>
        );
      },
    },
    {
      accessorKey: "billing.withHoldingTax",
      header: "WHtax",
      cell: ({ row }) => {
        return (
          <div className="text-center">
            {Number(row.original.billing?.withHoldingTax ?? 0).toLocaleString(
              "en-US",
              {
                style: "currency",
                currency: "PHP",
              }
            )}
          </div>
        );
      },
    },
  ];

  const modaldeductionsTableCol: ColumnDef<DebitCreditBill>[] = [

    {
      accessorKey: "debitcreditmemo.documentDate",
      header: "Date",
      cell: ({ row }) => {
        return (
          <div className="text-center">
            {row.original?.debitcreditmemo?.documentDate
              ? new Date(row.original?.debitcreditmemo?.documentDate).toLocaleDateString()
              : ""}
          </div>
        );
      },
    },
    {
      accessorKey: "debitcreditmemo.type",
      header: "Type",
      cell: ({ row }) => {
        const type =
          row.original.debitcreditmemo?.documentNumber &&
            row.original.debitcreditmemo?.documentNumber.includes("JRNL")
            ? "Journal"
            : "Bill Credit";

        return <div className="text-center">{type}</div>;
      },
    },
    {
      accessorKey: "debitcreditmemo.debitCreditMemoNumber",
      header: "Ref No.",
      cell: ({ row }) => {
        return (
          <div className="text-center">
            {row.original?.debitcreditmemo?.debitCreditMemoNumber}
          </div>
        );
      },
    },
    {
      accessorKey: "debitcreditmemo.debitCreditMemoNumber",
      header: "Applied To.",
      cell: ({ row }) => {
        return (
          <div className="text-center">
            Bill #{row.original?.billing?.billingNumber}
          </div>
        );
      },
    },
    {
      accessorKey: "debitcreditmemo.checkAmount",
      header: "Payment",
      cell: ({ row }) => {
        return (
          <div className="text-center">
            {Number(row.original?.debitcreditmemo?.checkAmount ?? 0).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
  ];

  const getRows = (id: number) => {
    setUserId(id);
    setIsOpen(true);
  };

  const downloadCSV = () => {
    setIsCsvDownload(true);
  };
  const deductions_length = modalData?.deductions?.length ?? 0;

  const [isFetching, setIsFetching] = useState(false);
  const fetchPaymentData = async () => {
    setIsFetching(true)
    axios({
      url: `${process.env.NEXT_PUBLIC_API_URL}/api/netsuite/payment`,
    })
      .then((response) => {

        if(workerData.isFetching){
          toast.success("Fetching of payment data is on queue")
        }
        else{
          toast.success("Payment data is currently fetching")
        }

        refetch_worker()
        setIsFetching(false)
      })
  }

  if (userData?.role !== 'admin-accounting' && userData?.role !== 'vendor' && userData?.role !== 'accounting' && userData?.role !== 'admin') {
    return <Unauthorized />
  }

  const length = modalData?.paymentInvoices?.length ?? 0;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 scroll-m-20 text-2xl font-medium tracking-tight mb-2">
        <h1 className="">Payment</h1>
        {userData?.role !== 'vendor' && (
          <div className="flex flex-col md:flex-row md:justify-end">
            <Button
              className="md:w-1/2"
              onClick={fetchPaymentData}
              disabled={isFetching || workerData?.data?.payment?.isFetching || workerData?.data?.payment?.onQueue }
            >
            {workerData?.data?.payment?.isFetching
              ? "Fetching Payment Data..."
              : workerData?.data?.payment?.onQueue
              ? "Waiting in Queue..."
              : "Fetch Payment Data"
            }
            </Button>
          </div>
        )}
      </div>
      <div className="bg-white w-full p-8 rounded-md">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <p>Current View</p>
            <hr className="my-2" />
            <div className="grid grid-cols-1 gap-2 items-center md:grid-cols-2">
              {/* <FormField
                control={form.control}
                name="voucher_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Voucher Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              /> */}
              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="check_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Check Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="check_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Check Date To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              {userData?.role !== "vendor" && (
                <FormField
                  control={form.control}
                  name="vendor_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vendor Name</FormLabel>
                      <Input {...field} />

                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="releasing_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Releasing Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="releasing_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Releasing Date To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="transaction_no"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Transaction Number</FormLabel>
                    <FormControl>
                      <Input {...field}  />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="read_status"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Read Status</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="flex flex-row items-center space-x-4"
                      >
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="all" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            All
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="false" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Unread
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="true" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Read
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="results"
                defaultValue="10"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Results</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="10 per page" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {[10, 25, 50, 100].map((val, index) => (
                          <SelectItem key={index} value={val.toString()}>
                            {val}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="flex flex-col md:flex-row md:justify-end gap-2 mt-3">
              <Button
                className="w-full md:w-1/6"
                type="submit"
                disabled={isFetchingPaymentTable}
              >
                Search
              </Button>
              <Button
                className="w-full md:w-1/6"
                variant="outline"
                type="reset"
                onClick={handleClearFilter}
                disabled={isFetchingPaymentTable}
              >
                Clear
              </Button>
            </div>
          </form>
        </Form>
      </div>

      <div className="flex flex-col space-y-2">
        <div className="flex justify-between items-center flex-wrap gap-2 ">
          <DebouncedInput
            value={searchText ?? ""}
            onChange={(value) => setSearchText(String(value))}
          />
          {/* <Button
            className="md:w-1/5"
            onClick={downloadCSV}
            disabled={isCsvDownload}
          >
            {isCsvDownload ? <Spinner /> : "Export"}
          </Button> */}
          <div className="flex justify-end space-x-2 md:w-2/5">
            {(userData?.role === 'admin' || userData?.role === 'admin-accounting') && (
              <Button className="w-full relative">
                {isImporting ? <Spinner /> : "Import"}
                <input
                  type="file"
                  accept=".xlsx"
                  className="absolute top-0 left-0 w-full h-full opacity-0 z-10 cursor-pointer"
                  onChange={handleFileChange}
                  aria-label="Upload Excel file"
                />
              </Button>
            )}

            <Button className={userData?.role !== 'admin-accounting' ? 'md:w-2/5' : 'w-full'} onClick={downloadCSV} disabled={isCsvDownload}>
              {isCsvDownload ? <Spinner /> : "Export"}
            </Button>
          </div>
        </div>
        <DataTable
          columns={columns}
          data={data?.payments ?? []}
          page={page}
          loading={isFetchingPaymentTable}
          setPage={setPage}
          vendorVisibility={userData?.role !== "vendor" ? true : false}
          displayPagination
          total={data?.totalCount}
          textAlign="text-center"
        />
      </div>
      <Dialog open={isOpen} modal onOpenChange={(val) => setIsOpen(val)}>
        <DialogContent
          className={
            "lg:max-w-screen-lg font-mulish overflow-y-auto max-h-[90%] scrollbar"
          }
        >
          {isFetchingPaymentDetails && (
            <LoadingScreen details="Bill Payment" />
          )}

          <div ref={modalRef} className="flex flex-col space-y-2">
            {modalData?.subsidiary?.logo && (
              <div className="w-32 h-16 relative">
                <Image
                  src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${modalData?.subsidiary?.logo}`}
                  alt={"Logo"}
                  fill
                  objectFit="contain"
                  quality={100}
                  draggable={false}
                />
              </div>
            )}
            <div className="flex justify-between items-center">
              <p className="font-bold">Bill Payment</p>
            </div>

            <p>Primary Information</p>
            <div className="flex items-center">
              <div className="flex flex-col space-y-2 w-full">
                <p className="font-medium text-blue-700">CV Number</p>
                <p>{modalData?.cvNumber}</p>
              </div>
              <div className="flex flex-col space-y-2 w-full">
                <p className="font-medium text-blue-700">Vendor</p>
                <p>{modalData?.vendor?.name}</p>
              </div>
              <div className="flex flex-col space-y-2 w-full">
                <p className="font-medium text-blue-700">CV Date</p>
                <p>
                  {!!modalData?.cvDate &&
                    new Date(modalData?.cvDate).toLocaleDateString()}
                </p>
              </div>
            </div>

            <div className="flex items-center">
              <div className="flex flex-col space-y-2 w-full">
                <p className="font-medium text-blue-700">Payment Method</p>
                <p>{modalData?.paymentMethod}</p>
              </div>
              <div className="flex flex-col space-y-2 w-full">
                <p className="font-medium text-blue-700">Bank</p>
                <p>{modalData?.bank}</p>
              </div>
              <div className="flex flex-col space-y-2 w-full">
                <p className="font-medium text-blue-700">Check Number</p>
                <p>{modalData?.checkNumber}</p>
              </div>
            </div>
            <div className="flex flex-col space-y-2 w-full text-end">
              <p className="font-medium text-blue-700 text-lg">Amount</p>
              <p className="text-xl font-semibold">
                {Number(modalData?.amount).toLocaleString("en-US", {
                  style: "currency",
                  currency: "PHP",
                })}
              </p>
            </div>
            <hr className="border border-blue-700" />
            <DataTable
              columns={modalTableCol}
              data={modalData?.paymentInvoices ?? []}
              displayPagination={false}
              total={modalData?.paymentInvoices.length}
              rowClassName="bg-transparent hover:bg-transparent"
              wrapperClassName="-z-10"
              textAlign="text-center"
            />
            {/* <div className="grid grid-cols-7">
              <h1 className="text-sm font-medium text-blue-700">Date</h1>
              <h1 className="text-sm font-medium text-blue-700">Type</h1>
              <h1 className="text-sm font-medium text-blue-700">
                Counter Receipt No.
              </h1>
              <h1 className="text-sm font-medium text-blue-700">
                Supplier Invoice Ref
              </h1>
              <h1 className="text-sm font-medium text-blue-700">PO #</h1>
              <h1 className="text-sm text-right font-medium text-blue-700">
                Gross Amount
              </h1>
              <h1 className="text-right font-medium text-blue-700">WHtax</h1>
            </div>
            {modalData?.paymentInvoices?.map((item, index) => {
              return (
                <div
                  key={index}
                  className="grid grid-cols-7 gap-4 [&_p]:break-words"
                >
                  <p>
                    {item.applyDate &&
                      new Date(item.applyDate).toLocaleDateString()}
                  </p>
                  <p>{item?.type}</p>
                  <p>{item?.refNum}</p>
                  <p>{item?.billing?.supplierInvoiceReference}</p>
                  <p>{item?.billing?.poNumber}</p>
                  <p className="text-right">
                    {Number(item?.paymentAmount ?? 0).toLocaleString("en-US", {
                      style: "currency",
                      currency: "PHP",
                    })}
                  </p>
                  <p className="text-right">
                    {Number(item?.billing?.withHoldingTax ?? 0).toLocaleString(
                      "en-US",
                      {
                        style: "currency",
                        currency: "PHP",
                      }
                    )}
                  </p>
                </div>
              );
            })} */}
            <hr className="border border-gray-300" />
            <div className="flex gap-1 justify-end py-2">
              <h1 className="font-semibold">Total Orig Amount:</h1>
              <p>
                {Number(modalData?.totalOrigAmount).toLocaleString("en-US", {
                  style: "currency",
                  currency: "PHP",
                })}
              </p>
            </div>
            <div
            // className={`${
            //   length >= 3 ? "break-before-page" : "break-before-avoid-page"
            // } space-y-2`}
            >
              <hr className="border border-blue-700 mb-4" />
              {deductions_length > 0 && (
                <>
                  <h1 className="text-lg font-medium">Total Deductions:</h1>
                  <DataTable
                    columns={modaldeductionsTableCol}
                    data={modalData?.deductions ?? []}
                    displayPagination={false}
                    total={deductions_length}
                    rowClassName="bg-transparent hover:bg-transparent"
                    wrapperClassName="-z-10"
                    textAlign="text-center"
                  />
                </>
              )}

              <hr className="border border-gray-200 !my-4" />
              <div className="flex space-x-2 justify-end w-full">
                <div className="flex space-x-2 border border-blue-700 py-2 px-4">
                  <p className="font-medium text-blue-700">Net Amount:</p>
                  <p className="font-medium">
                    {Number(modalData?.amount).toLocaleString("en-US", {
                      style: "currency",
                      currency: "PHP",
                    })}
                  </p>
                </div>
              </div>
              <div className="flex justify-end w-full">
                <p className="text-sm font-medium py-2 px-4 w-fit tracking-wide">
                  Total Withholding Tax:
                  <span className="ml-1">
                    {Number(modalData?.totalWithHoldingTax).toLocaleString(
                      "en-US",
                      { style: "currency", currency: "PHP" }
                    )}
                  </span>
                </p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsOpen(false)} className="md:w-1/5">
              Ok
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Payment;
