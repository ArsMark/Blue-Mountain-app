import Image from "next/image";
import waves from "../../public/images/waves.png";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useRouter } from "next/router";
import { setCookie } from "cookies-next";
import { useSubsidiary } from "@/utils/hooks/useSubsidiary";
import Spinner from "@/components/ui/spinner";

const SelectVendor = () => {
  const router = useRouter();
  const { data, isLoading } = useSubsidiary();

  if (isLoading) {
    return (
      <div className="grid place-items-center h-screen">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="bg-[#ECF3FE] min-h-screen relative">
      <div className="w-full p-4 mx-auto absolute top-[40%] left-1/2 transform -translate-x-1/2 -translate-y-1/2 md:w-[60vw] lg:w-[45vw]">
        <h1 className="text-center scroll-m-20 pb-8 text-3xl font-medium tracking-tight transition-colors first:mt-0">
          Select Vendor
        </h1>
        <RadioGroup
          className="flex gap-2 justify-center w-full items-center flex-col md:flex-row"
          onValueChange={(value) => {
            setCookie("subsidiaryId", value);
          }}
          onClick={() => router.push("/home")}
        >
          {data?.subsidiaries?.map((item) => {
            return (
              <div key={item.id}>
                <RadioGroupItem
                  value={`${item.id}`}
                  className="peer sr-only"
                  id={`${item.id}`}
                />
                <Label
                  htmlFor={`${item.id}`}
                  className="flex flex-col w-80 text-center text-sm items-center justify-between cursor-pointer rounded-md border-2 hover:border-blue-500 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-blue-500 [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-1 w-36 h-16 md:w-52 md:h-24 relative">
                    <Image
                      src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${item.logo}`}
                      alt={item.name}
                      draggable={false}
                      fill
                      objectFit="contain"
                    />
                  </div>
                  {item.name}
                </Label>
              </div>
            );
          })}
        </RadioGroup>
      </div>
      <div className="absolute inset-x-0 bottom-0">
        <Image src={waves} alt="Waves images" />
      </div>
    </div>
  );
};

SelectVendor.getLayout = function getLayout(page: React.ReactElement) {
  return <>{page}</>;
};

export default SelectVendor;
