import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { ColumnDef, PaginationState, Row } from "@tanstack/react-table";
import { DataTable } from "@/components/ui/tables/DataTable";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import { HiEye } from "react-icons/hi";
import { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import bmLogo from "../../public/images/bm_logo.png";
import ItemFulfillmentPDF from "@/components/PDF/ItemFulfillmentPDF";
import { useReactToPrint } from "react-to-print";
import { AiFillPrinter } from "react-icons/ai";
import { FaFileDownload } from "react-icons/fa";
import {
  ItemFulfillment,
  ItemFulfillmentDetails,
  ItemFulfillmentItem,
} from "@/types/IIF";
import { z } from "zod";
import { ItemFulfillmentSchema } from "@/schema/ItemFulfillmentSchema";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useItemFulfillmentDetails,
  useItemFulfillmentStatus,
  useItemFulfillmentTable,
} from "@/utils/hooks/useItemFulfillment";
import toast from "react-hot-toast";
import Spinner from "@/components/ui/spinner";
import DebouncedInput from "@/components/ui/tables/DebounceInput";
import { saveAs } from "file-saver";
import { pdf } from "@react-pdf/renderer";
import { useActionDownload } from "@/utils/hooks/useActionDownload";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import LoadingScreen from "@/components/ui/loading";
import { useAuthMe } from "@/utils/hooks/useAuth";
import { useSubsidiaryDetails } from "@/utils/hooks/useSubsidiary";
import { getCookie } from "cookies-next";

export type FormValues = z.infer<typeof ItemFulfillmentSchema>;

const ItemFulfillments = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userId, setUserId] = useState(0);
  const [isDownload, setIsDownload] = useState(false);
  const [isCsvDownload, setIsCsvDownload] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [formValue, setFormValue] = useState<FormValues>({
    document_status: "", 
    fulfillment_date_from: undefined,
    fulfillment_date_to: undefined,
    if_number: "",
    pullout_date_from: undefined,
    pullout_date_to: undefined,
    read_status: "all",
    results: "10",
    vendor_name: "",
  });
  const form = useForm<FormValues>({
    resolver: zodResolver(ItemFulfillmentSchema),
    defaultValues: {
      document_status: "",
      fulfillment_date_from: undefined,
      fulfillment_date_to: undefined,
      if_number: "",
      pullout_date_from: undefined,
      pullout_date_to: undefined,
      read_status: "all",
      results: "10",
      vendor_name: "",
    },
  });
  const [page, setPage] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: Number(formValue.results),
  });

  useEffect(() => {
    if (formValue || searchText) {
      setPage({
        pageIndex: 0,
        pageSize: Number(formValue.results),
      });
    }
  }, [formValue, searchText]);

  const pagination = useMemo(() => {
    return {
      pageIndex: page.pageIndex,
      pageSize: Number(formValue.results),
    };
  }, [page, formValue]);

  const { data, isLoading } = useItemFulfillmentTable(
    pagination,
    formValue,
    searchText,
    isCsvDownload,
    setIsCsvDownload
  );
  const { data: modalData, isSuccess, isLoading: isFetchingIFDetails } = useItemFulfillmentDetails(userId);
  const { mutate } = useActionDownload();
  const { data: userData } = useAuthMe();
  const currentRole = userData?.role == 'vendor'
  const subsidiaryId = getCookie("subsidiaryId");
  const { data: subsidiary } = useSubsidiaryDetails(subsidiaryId);

  const modalRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    content: () => modalRef.current,
  });

  useEffect(() => {
    if (modalData && isDownload && isSuccess) {
      downloadPDF(modalData);
    }
  }, [modalData, isDownload, isSuccess]);
  const downloadPDF = async (data: ItemFulfillmentDetails | undefined) => {
    const blob = await pdf(<ItemFulfillmentPDF data={data} />).toBlob();
    saveAs(blob, "Item Fulfillment.pdf");
    mutate({ action: "Downloaded a Item Fulfillment." });
    setIsDownload(false);
  };

  const columns = useMemo<ColumnDef<ItemFulfillment>[]>(
    () => [
      {
        accessorKey: "vendorReturnAuthorization.vraNumber",
        header: "VRA NO.",
      },
      {
        id: "vendorName",
        accessorKey: "vendor.name",
        header: "VENDOR NAME",
        cell: ({ row }) => {
          return (
            <span className="truncate w-[200px] overflow-hidden">
              {row.original.vendor.name}
            </span>
          );
        },
      },
      {
        accessorKey: "fulfillmentDate",
        header: "FULFILLMENT DATE",
        cell: ({ row }) => {
          if (!row.original.fulfillmentDate) return;
          return (
            <span>
              {new Date(row.original.fulfillmentDate).toLocaleDateString()}
            </span>
          );
        },
      },
      {
        accessorKey: "pullOutDate",
        header: "DEADLINE FOR PULL OUT",
        cell: ({ row }) => {
          if (!row.original.pullOutDate) return;
          return (
            <span>
              {new Date(row.original.pullOutDate).toLocaleDateString()}
            </span>
          );
        },
      },
      {
        accessorKey: "totalQuantity",
        header: "TOTAL QUANTITY",
      },
      {
        accessorKey: "itemFulFillmentNumber",
        header: "IF NUMBER",
      },
      {
        accessorKey: "actions",
        header: "ACTIONS",
        //getting data every row
        cell: ({ row }) => {
          return (
            <div className="flex gap-1 justify-center">
              <Button
                onClick={() => {
                  getRows(row.original.id);
                }}
                className="w-8 h-8"
                size="icon"
                variant="icon"
              >
                <HiEye size="20" />
              </Button>
              <Button
                className="w-8 h-8"
                variant="icon"
                onClick={() => {
                  setIsOpen(true);
                  setUserId(row.original.id);
                  mutate({ action: "Printed a Item Fulfillment." });
                  toast.loading("Printing...", { duration: 3000 });
                  setTimeout(handlePrint, 3000);
                }}
                size="icon"
              >
                <AiFillPrinter size="20" />
              </Button>
              <Button
                className="w-8 h-8"
                variant="icon"
                onClick={() => {
                  setUserId(row.original.id);
                  toast.loading("Downloading PDF...", { duration: 3000 });
                  setIsDownload(true);
                }}
                size="icon"
              >
                <FaFileDownload size="20" />
              </Button>
            </div>
          );
        },
      },
    ],
    []
  );

  const getRows = (id: number) => {
    setUserId(id);
    setIsOpen(true);
  };

  const onSubmit = (values: FormValues) => {
    setFormValue(values);
    toast.success("Filter has been applied");
  };

  const handleClearFilter = () => {
    const initialFormValues = {
      document_status: "",
      if_number: "",
      read_status: "all",
      results: "10",
      vendor_name: "",
    };
    form.reset(initialFormValues);
    setFormValue(initialFormValues);
    toast.success("Filter has been cleared");
  };

  const downloadCSV = () => {
    setIsCsvDownload(true);
  };

  const length = modalData?.itemFulfillmentItems.length ?? 0;

  return (
    <div className="flex flex-col space-y-4">
      <h1 className="scroll-m-20 text-2xl font-medium tracking-tight mb-2">
        Item Fulfillment
      </h1>
      <div className="bg-white w-full p-8 rounded-md">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="flex flex-col md:flex-row md:justify-between">
              <p>Current View: Live</p>
            </div>
            <hr className="my-2" />
            <div className="grid grid-cols-1 gap-4 items-center md:grid-cols-2">
              <FormField
                control={form.control}
                name="if_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>IF Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>

                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="pullout_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Deadline for Pull Out From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pullout_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Deadline for Pull Out To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              {userData?.role !== "vendor" && (
                <FormField
                  control={form.control}
                  name="vendor_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vendor Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="fulfillment_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Fulfillment Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="fulfillment_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Fulfillment Date To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="results"
                defaultValue="10"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Results</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="10 per page" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {[10, 25, 50, 100].map((val, index) => (
                          <SelectItem key={index} value={val.toString()}>
                            {val}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="read_status"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Read Status</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="flex flex-row items-center space-x-4"
                      >
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="all" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            All
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="false" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Unread
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="true" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Read
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="flex flex-col md:flex-row md:justify-end gap-2">
              <Button
                className="w-full md:w-1/6"
                type="submit"
                disabled={isLoading}
              >
                Search
              </Button>
              <Button
                className="w-full md:w-1/6"
                variant="outline"
                type="reset"
                onClick={handleClearFilter}
                disabled={isLoading}
              >
                Clear
              </Button>
            </div>
          </form>
        </Form>
      </div>

      <div className="flex flex-col space-y-2">
        <div className="flex justify-between items-center flex-wrap gap-2 ">
          <DebouncedInput
            value={searchText ?? ""}
            onChange={(value) => setSearchText(String(value))}
          />
          <Button
            className="md:w-1/5"
            onClick={downloadCSV}
            disabled={isCsvDownload}
          >
            {isCsvDownload ? <Spinner /> : "Export"}
          </Button>
        </div>
        <DataTable
          columns={columns}
          data={data?.itemFulfillments ?? []}
          page={page}
          loading={isLoading}
          setPage={setPage}
          vendorVisibility={userData?.role !== "vendor" ? true : false}
          displayPagination
          total={data?.totalCount}
          textAlign="text-center"
        />

        <Dialog open={isOpen} modal onOpenChange={(val) => setIsOpen(val)}>
          <DialogContent
            className={
              "lg:max-w-screen-lg overflow-y-auto max-h-[90%] scrollbar"
            }
          >
            {isFetchingIFDetails && (
                <LoadingScreen details="Item Fulfillment"/>
              )}
            <div ref={modalRef} className="flex flex-col space-y-2 px-4">
              <div className="flex justify-between items-center">
                {subsidiary?.logo && (
                  <div className="w-32 h-16 relative">
                    <Image
                      src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${subsidiary?.logo}`}
                      alt={"Logo"}
                      fill
                      objectFit="contain"
                      quality={100}
                      draggable={false}
                    />
                  </div>
                )}
                <p>Item Fulfillment</p>
              </div>

              <div className="flex justify-between">
                <p>Primary Information</p>
                <p>NO: {modalData?.itemFulFillmentNumber}</p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">SRS Ref. No.</p>
                <p>{modalData?.srsNo}</p>
              </div>

              <div className="flex items-start">
                <div className="flex flex-col space-y-2 w-full">
                  <p className="font-medium text-blue-500">Vendor</p>
                  <p>{modalData?.vendor?.name}</p>
                </div>
                <div className="flex flex-col space-y-2 w-full">
                  <p className="font-medium text-blue-500">Location</p>
                  <p>{modalData?.location}</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex flex-col space-y-2 w-full">
                  <p className="font-medium text-blue-500">Site Address</p>
                  <p>{modalData?.siteAddress}</p>
                </div>
              </div>
              <hr className="border border-blue-500" />
              <p>Date Information</p>
              <div className="flex items-start">
                <div className="flex flex-col space-y-2 w-full">
                  <p className="font-medium text-blue-500">Date Created</p>
                  <p>
                    {!!modalData?.fulfillmentDate &&
                      new Date(modalData?.fulfillmentDate).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex flex-col space-y-2 w-full">
                  <p className="font-medium text-blue-500">Deadline for Pull Out</p>
                  <p>
                    {!!modalData?.pullOutDate &&
                      new Date(modalData?.pullOutDate).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div
              // className={`${
              //   length > 5 ? "break-after-page" : "break-before-avoid-page"
              // }`}
              >
                <hr className="border border-blue-500" />
                <p>Item Information</p>
                {/* <div className="grid grid-cols-5">
                  <h1 className="text-left font-medium text-blue-700">
                    Barcode
                  </h1>
                  <h1 className="text-left font-medium text-blue-700">
                    Item Description
                  </h1>
                  <h1 className="text-right font-medium text-blue-700">
                    Unit Price
                  </h1>
                  <h1 className="text-center font-medium text-blue-700">
                    Quantity
                  </h1>
                  {/* <h1 className="text-right font-medium text-blue-700">
                    Total Amount
                  </h1>
                </div> */}
                <div className="flex flex-row items-center pb-2">
                  <h1 className="w-1/6  font-medium text-blue-700">Barcode</h1>
                  <h1 className="w-3/6  font-medium text-blue-700">
                    Item Description
                  </h1>
                  <h1 className="w-[12%]  font-medium text-blue-700">Cost</h1>
                  <h1 className="w-[12%] font-medium text-blue-700">
                    Quantity
                  </h1>
                </div>
                {modalData?.itemFulfillmentItems.map((item, index) => {
                  return (
                    // <div
                    //   className="grid grid-cols-5 text-center my-2"
                    //   key={index}
                    // >
                    //   <p className="text-left">{item.item.barcode}</p>
                    //   <p className="text-left">{item.item.description}</p>
                    //   <p className="text-right">
                    //     {Number(item.grossNet).toLocaleString("en-US", {
                    //       style: "currency",
                    //       currency: "PHP",
                    //     })}
                    //   </p>
                    //   <p className="text-center">{item.quantity}</p>
                    //   <p className="text-right">
                    //     {Number(item.totalAmount).toLocaleString("en-US", {
                    //       style: "currency",
                    //       currency: "PHP",
                    //     })}
                    //   </p>
                    // </div>
                    <div
                      className="flex flex-row items-center text-[.80rem]  py-2"
                      key={index}
                    >
                      <p className="w-1/6">{item.item.barcode}</p>
                      <p className="w-3/6">{item.item.description}</p>
                      <p className="w-[12%]">
                        {Number(item.item.cost).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                      <p className="text-center pl-[1.5rem]">{item.quantity}</p>
                      {/* <p className="text-right">
                        {Number(item.totalAmount).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p> */}
                    </div>
                  );
                })}
                <hr className="border border-blue-500" />
              </div>
              <div className="grid grid-cols-2">
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-500">Prepared By:</p>
                  <p>{modalData?.preparedBy}</p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={() => setIsOpen(false)} className="md:w-1/5">
                Ok
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default ItemFulfillments;
