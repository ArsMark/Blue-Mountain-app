import PDFComponent from "@/components/PDFComponent";
import TermsAndCondition from "@/components/terms-condition";
import CDebouncedInput from "@/components/ui/CommandInput";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Spinner from "@/components/ui/spinner";
import { DataTable } from "@/components/ui/tables/DataTable";
import DebouncedInput from "@/components/ui/tables/DebounceInput";
import { cn } from "@/lib/utils";
import { purchaseSchema } from "@/schema/purchaseSchema";
import {
  IFormValues,
  IPurchaseOrderDetails,
  PurchaseOrder,
} from "@/types/IPurchase";
import { useActionDownload } from "@/utils/hooks/useActionDownload";
import { useAuthMe } from "@/utils/hooks/useAuth";
import {
  usePurchaseOrderDetails,
  usePurchaseOrderStatus,
  usePurchaseOrderTable,
} from "@/utils/hooks/usePurchaseOrder";
import { useSubsidiaryDetails } from "@/utils/hooks/useSubsidiary";
import { useWarehouseLocationData } from "@/utils/hooks/useWarehouseLocation";
import { zodResolver } from "@hookform/resolvers/zod";
import { pdf } from "@react-pdf/renderer";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { getCookie } from "cookies-next";
import { format } from "date-fns";
import { saveAs } from "file-saver";
import LoadingScreen from "@/components/ui/loading";
import { CalendarIcon, ChevronsUpDown } from "lucide-react";
import Image from "next/image";
import {
  Fragment,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { AiFillPrinter } from "react-icons/ai";
import { FaFileDownload } from "react-icons/fa";
import { HiCheck, HiEye } from "react-icons/hi";
import { useReactToPrint } from "react-to-print";
import { z } from "zod";
import Unauthorized from "@/components/ui/unauthorized";
export type formValue = z.infer<typeof purchaseSchema>;

const PurchaseOrders = () => {
  const form = useForm<formValue>({
    resolver: zodResolver(purchaseSchema),
    defaultValues: {
      receipt_date_from: undefined,
      receipt_date_to: undefined,
      results: "10",
      delivery_date_from: undefined,
      delivery_date_to: undefined,
      document_status: "",
      po_number: "",
      read_status: "all",
      vendor_name: "",
      warehouse_location: "",
      grandTotal: "",
    },
  });
  const [isSeeMore, setIsSeeMore] = useState(1);
  const [isOpen, setIsOpen] = useState(false);
  const [userId, setUserId] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [isCsvDownload, setIsCsvDownload] = useState(false);
  const [isDownload, setIsDownload] = useState(false);
  const [searchLocation, setSearchLocation] = useState<string | number>("");
  const [formValue, setFormValue] = useState<Partial<IFormValues>>({
    receipt_date_from: undefined,
    receipt_date_to: undefined,
    results: "10",
    delivery_date_from: undefined,
    delivery_date_to: undefined,
    document_status: "",
    po_number: "",
    read_status: "all",
    vendor_name: "",
    warehouse_location: "",
  });
  const [page, setPage] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: Number(formValue.results),
  });
  const modalRef = useRef(null);
  const divRef = useRef<HTMLDivElement>(null);

  const pagination = useMemo(() => {
    return {
      pageIndex: page.pageIndex,
      pageSize: Number(formValue.results),
    };
  }, [page, formValue]);

  const { data, isLoading } = usePurchaseOrderTable(
    formValue,
    pagination,
    searchText,
    isCsvDownload,
    setIsCsvDownload
  );
  const { data: modalData, isSuccess, isLoading: isFetchingPODetails } = usePurchaseOrderDetails(userId);
  const { mutate } = useActionDownload();
  const subsidiaryId = getCookie("subsidiaryId");
  
  const { data: subsidiary } = useSubsidiaryDetails(subsidiaryId);
  const {
    data: warehouseData,
    isFetching,
    fetchNextPage,
  } = useWarehouseLocationData(searchLocation, isSeeMore, subsidiaryId);
  const { data: userData } = useAuthMe();
  const currentRole = userData?.role == 'vendor'
  const { data: documentStatus } = usePurchaseOrderStatus();
  
  const handlePrint = useReactToPrint({
    content: () => modalRef.current,
  });

  useEffect(() => {
    if (isSeeMore) {
      fetchNextPage();
    }
  }, [isSeeMore]);

  // useEffect(() => {
  //   if (isSuccess) {
  //     refetch();
  //   }
  // }, [isSuccess]);

  useEffect(() => {
    if (formValue || searchText) {
      setPage({
        pageIndex: 0,
        pageSize: Number(formValue.results),
      });
    }
  }, [formValue, searchText]);

  useEffect(() => {
    if (modalData && isDownload && isSuccess) {
      downloadPDF(modalData);
    }
  }, [modalData, isDownload, isSuccess]);
  const downloadPDF = async (data: IPurchaseOrderDetails) => {
    const blob = await pdf(<PDFComponent data={data} />).toBlob();
    saveAs(blob, `Purchase Order ${modalData?.poNumber}.pdf`);
    mutate({ action: "Downloaded a Purchase Order." });
    setIsDownload(false);
  };

  const queryColumns = useMemo<ColumnDef<PurchaseOrder>[]>(
    () => [
      {
        accessorKey: "poNumber",
        header: "PO NUMBER",
      },
      {
        id: "vendorName",
        accessorKey: "vendor.name",
        header: "VENDOR NAME",
        cell: ({ row }) => {
          return (
            <div className="truncate overflow-hidden w-[200px] mx-auto">
              {row.original.vendor?.name || null}
            </div>
          );
        },
      },
      {
        accessorKey: "poDate",
        header: "DATE",
        cell: ({ row }) => {
          return (
            <div key={row.original.id}>
              {new Date(row.original.poDate).toLocaleDateString()}
            </div>
          );
        },
      },
      {
        accessorKey: "totalQuantity",
        header: "TOTAL QUANTITY",
      },
      {
        accessorKey: "documentStatus",
        header: "DOCUMENT STATUS",
      },
      {
        accessorKey: "location",
        header: "STORE / WAREHOUSE LOCATION",
        cell: ({ row }) => {
          return (
            <div className="truncate overflow-hidden w-[200px] mx-auto">
              {row.original.location}
            </div>
          );
        },
      },
      {
        accessorKey: "totalAmount",
        header: "AMOUNT",
        cell: ({ row }) => {
          return (
            <div>
              {Number(row.original.grandTotal).toLocaleString("en-US", {
                style: "currency",
                currency: "PHP",
              })}
            </div>
          );
        },
      },
      {
        accessorKey: "isRead",
        header: "READ STATUS",
        cell: ({ row }) => {
          return (
            <div>
              {row.original.isRead ? (
                <span className="text-green-500">Read</span>
              ) : (
                <span className="text-red-500">Unread</span>
              )}
            </div>
          );
        },
      },
      {
        header: "ACTIONS",
        id: "rows",

        //getting data every row
        cell: ({ row }) => {
          return (
            <div className="flex gap-1 justify-center">
              <Button
                onClick={() => {
                  getRows(row.original.id);
                }}
                className="w-8 h-8"
                size="icon"
                variant="icon"
              >
                <HiEye size="20" />
              </Button>
              <Button
                className="w-8 h-8"
                variant="icon"
                onClick={() => {
                  setIsOpen(true);
                  setUserId(row.original.id);
                  // mutate({ action: "Printed a Purchase Order." });
                  toast.loading("Printing...", { duration: 3000 });
                  setTimeout(handlePrint, 3000);
                }}
                size="icon"
              >
                <AiFillPrinter size="20" />
              </Button>
              <Button
                className="w-8 h-8"
                size="icon"
                variant="icon"
                onClick={() => {
                  setUserId(row.original.id);
                  toast.loading("Downloading PDF...", { duration: 3000 });
                  setIsDownload(true);
                }}
              >
                <FaFileDownload size="20" />
              </Button>
            </div>
          );
        },
      },
    ],
    []
  );

  const onSubmit = (values: formValue) => {
    setFormValue(values);
    toast.success("Filter has been applied");
  };

  const getRows = (id: number) => {
    setUserId(id);
    setIsOpen(true);
  };

  const handleClearFilter = () => {
    toast.success("Filter has been cleared");
    const defaultFormValues = {
      results: "10",
      document_status: "",
      po_number: "",
      read_status: "all",
      vendor_name: "",
      warehouse_location: "",
    };
    form.reset(defaultFormValues);
    setFormValue(defaultFormValues);
  };

  const downloadCSV = () => {
    setIsCsvDownload(true);
  };

  if (userData?.role !== 'admin-accounting' && userData?.role !== 'vendor' && userData?.role !== 'accounting' && userData?.role !== 'admin' && userData?.role !== 'purchasing') {
    return <Unauthorized />
  }

  const length = modalData?.purchaseOrderItems.length ?? 0;
  const osd = modalData?.totalOtherSpecialDiscount ?? 0;
  const tctd = modalData?.totalCentralTlcDiscount ?? 0;
  const tcdd = modalData?.totalCentralDropDiscrount ?? 0;
  const ttd = modalData?.totalTradeDiscount ?? 0;

  return (
    <div className="flex flex-col space-y-4">
      <h1 className="scroll-m-20 text-2xl font-medium tracking-tight mb-2">
        Purchase Order
      </h1>
      <div className="bg-white w-full p-8 rounded-md">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="flex flex-col items-center md:flex-row md:justify-between">
              <p>Current View: Live</p>
              <FormField
                control={form.control}
                name="document_status"
                render={({ field }) => (
                  <FormItem className="flex flex-col w-full md:w-1/4">
                    <FormLabel>Document Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {documentStatus?.map((status, index) => (
                          <SelectItem value={status} key={index}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <hr className="my-2" />
            <div className="grid grid-cols-1 gap-4 items-center md:grid-cols-2">
              <FormField
                control={form.control}
                name="po_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>P.O Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="receipt_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>P.O. Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar 
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="receipt_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>P.O. Date To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              {userData?.role !== "vendor" && (
                <FormField
                  control={form.control}
                  name="vendor_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vendor Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="delivery_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Delivery Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="delivery_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Delivery Date To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="warehouse_location"
                render={({ field }) => (
                  <FormItem className="w-full">
                    <FormLabel>Store Warehouse Location</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            className={cn(
                              "justify-between",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value
                              ? warehouseData?.pages
                                  .flatMap((value) => value.data)
                                  .find(
                                    (item) => String(item.id) === field.value
                                  )?.name
                              : "Select Warehouse"}

                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-[80vw] md:w-[37vw]">
                        <Command>
                          <CDebouncedInput
                            value={searchLocation ?? ""}
                            onChange={(val) => setSearchLocation(val)}
                          />
                          <CommandEmpty>No warehouse found.</CommandEmpty>
                          <CommandGroup className="max-h-[40vh] overflow-y-auto">
                            {warehouseData?.pages?.map((pages, index) => (
                              <Fragment key={index}>
                                {pages?.data?.map((val) => (
                                  <CommandItem
                                    value={`${val.name}`}
                                    key={val.id}
                                    onSelect={() => {
                                      form.setValue(
                                        "warehouse_location",
                                        `${val.id}`
                                      );
                                    }}
                                  >
                                    {val.name}
                                    <HiCheck
                                      className={cn(
                                        "ml-auto h-4 w-4",
                                        String(val.id) === field.value
                                          ? "opacity-100"
                                          : "opacity-0"
                                      )}
                                    />
                                  </CommandItem>
                                ))}
                              </Fragment>
                            ))}
                            <Button
                              type="button"
                              variant="icon"
                              disabled={isFetching}
                              onClick={() => setIsSeeMore((prev) => prev + 1)}
                            >
                              {isFetching ? <Spinner /> : "Load more"}
                            </Button>
                          </CommandGroup>
                        </Command>
                      </PopoverContent>
                    </Popover>

                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="read_status"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Read Status</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="flex flex-row items-center space-x-4"
                      >
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="all" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            All
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="false" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Unread
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="true" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Read
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="results"
                defaultValue="10"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Results</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="10 per page" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {[10, 25, 50, 100].map((val, index) => (
                          <SelectItem key={index} value={val.toString()}>
                            {val}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="flex flex-col md:flex-row md:justify-end gap-2 mt-3">
              <Button
                className="w-full md:w-1/6"
                type="submit"
                disabled={isLoading}
              >
                Search
              </Button>
              <Button
                className="w-full md:w-1/6"
                variant="outline"
                type="reset"
                onClick={handleClearFilter}
                disabled={isLoading}
              >
                Clear
              </Button>
            </div>
          </form>
        </Form>
      </div>

      <div className="flex flex-col space-y-2">
        <div className="flex justify-between items-center flex-wrap gap-2 ">
          <DebouncedInput
            value={searchText ?? ""}
            onChange={(value) => setSearchText(String(value))}
          />
          <Button
            className="md:w-1/5"
            onClick={downloadCSV}
            disabled={isCsvDownload}
          >
            {isCsvDownload ? <Spinner /> : "Export"}
          </Button>
        </div>
        <DataTable
          columns={queryColumns}
          data={data?.purchaseOrders ?? []}
          loading={isLoading}
          page={page}
          vendorVisibility={userData?.role !== "vendor" ? true : false}
          setPage={setPage}
          displayPagination
          total={data?.totalCount}
          textAlign="text-left"
        />

        <Dialog open={isOpen} modal onOpenChange={(val) => setIsOpen(val)}>
          <DialogContent
            className={
              "lg:max-w-screen-lg max-h-[90%] font-mulish overflow-y-auto scrollbar"
            }
          >
             {isFetchingPODetails && (
                <LoadingScreen details="Purchase Order"/>
              )}
            <div
              ref={modalRef}
              className="flex flex-col space-y-2 px-4 text-sm"
            >
              <div className="flex justify-between items-center">
                {subsidiary?.logo && (
                  <div className="w-32 h-16 relative">
                    <Image
                      src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${subsidiary?.logo}`}
                      alt={"Logo"}
                      fill
                      objectFit="contain"
                      quality={100}
                      draggable={false}
                    />
                  </div>
                )}
                <div className=" space-y-1">
                  <p className="text-lg font-bold">Purchase Order</p>
                  <p>Primary Information</p>
                  <div className="flex flex-wrap items-center space-x-6">
                    <div className="flex flex-col space-y-2">
                      <p className="font-medium text-blue-500">P.O No.</p>
                      <p>{modalData?.poNumber}</p>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <p className="font-medium text-blue-500">P.O Date</p>
                      <p>
                        {!!modalData?.poDate &&
                          new Date(modalData?.poDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <hr className="border border-blue-500" />
              <div className="space-y-4 pb-2">
                <div className="grid grid-cols-2">
                  <div className="flex flex-col space-y-2">
                    <p className="font-medium text-blue-500">Vendor</p>
                    <p>{modalData?.vendor?.name}</p>
                  </div>
                  <div className="flex flex-col space-y-2">
                    <p className="font-medium text-blue-500">
                      Shipping address
                    </p>
                    <p>{modalData?.shippingAddress}</p>
                  </div>
                </div>
              </div>

              <div className=" grid grid-cols-2 ">
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-500">Delivery Area</p>
                  <p>{modalData?.deliveryArea}</p>
                </div>
                <div className="flex flex-row space-x-16 ">
                  <div className="flex flex-col space-y-2">
                    <p className="font-medium text-blue-500">Terms</p>
                    <p>{modalData?.terms}</p>
                  </div>
                  <div className="flex flex-col space-y-2">
                    <p className="font-medium text-blue-500">Delivery Date</p>
                    <p>
                      {!!modalData?.deliveryDate &&
                        new Date(modalData?.deliveryDate).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex flex-col space-y-2">
                    <p className="font-medium text-blue-500">Total Cases</p>
                    <p>{modalData?.totalCases}</p>
                  </div>
                </div>
              </div>

              {/* <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Terms</p>
                <p>{modalData?.terms}</p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Vendor</p>
                <p>{modalData?.vendor?.name}</p>
              </div>

              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Shipping address</p>
                <p>{modalData?.shippingAddress}</p>
              </div> */}
              <hr className="border border-blue-500" />
              <div ref={divRef} className={`${"break-before-avoid-page"}`}>
                <div className="flex flex-row items-center justify-between pb-2">
                  <h1 className="w-1/6  font-medium text-blue-700">Barcode</h1>
                  <h1 className="w-3/6  font-medium text-blue-700">
                    Description
                  </h1>
                  <h1 className="w-[12%]  font-medium text-blue-700">
                    Quantity
                  </h1>
                  <h1 className="w-[12%] font-medium text-blue-700">Cost</h1>
                  <h1 className="w-1/6 pl-8  font-medium text-blue-700">
                    Amount
                  </h1>
                </div>
                {!modalData?.purchaseOrderItems?.length && (
                  <p className="text-center text-gray-700">No results</p>
                )}
                {modalData?.purchaseOrderItems?.map((item, index) => {
                  return (
                    <div
                      className="flex flex-row items-center justify-between text-[.80rem]  py-2"
                      key={index}
                    >
                      <p className="w-1/6">{item.barcode}</p>
                      <p className="w-3/6">{item.description}</p>
                      <p className="w-[12%]">{item.quantity}</p>
                      <p className="w-[12%]">
                        {Number(item.cost).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                      <p className="w-1/6 pl-8">
                        {Number(item.amount).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                    </div>
                  );
                })}
                {/* total */}
              </div>
              <div>
                <div
                // className={`${
                //   length > 1 ? "break-after-page" : "break-before-avoid-page"
                // }`}
                >
                  <hr className="border border-blue-500" />
                  <div className="flex justify-between items-center my-2 ">
                    <p className="font-semibold">Total Amount</p>
                    <p className="font-semibold">
                      {Number(modalData?.totalAmount).toLocaleString("en-US", {
                        style: "currency",
                        currency: "PHP",
                      })}
                    </p>
                  </div>
                  <hr className="border border-blue-500" />
                  {(ttd != 0 || tcdd != 0 || tctd != 0 || osd != 0) && (
                    <p className="font-medium text-blue-500">Discount</p>
                  )}
                  {ttd != 0 && (
                    <div className="flex justify-between my-1">
                      <p>Total Trade Discount</p>
                      <p className="font-medium">
                        {Number(ttd).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                    </div>
                  )}
                  {tcdd != 0 && (
                    <div className="flex justify-between my-1">
                      <p>Total Central Drop Discount</p>
                      <p className="font-medium">
                        {Number(tcdd).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                    </div>
                  )}
                  {tctd != 0 && (
                    <div className="flex justify-between my-1">
                      <p>Total Central TLC Discount</p>
                      <p className="font-medium">
                        {Number(tctd).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                    </div>
                  )}
                  {osd != 0 && (
                    <div className="flex justify-between my-1">
                      <p>Total Other Discount</p>
                      <p className="font-medium">
                        {Number(osd).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                    </div>
                  )}
                  {/* <div className="flex justify-between my-1">
                    <p>VAT</p>
                    <p className="font-medium">
                      {Number(modalData?.vat).toLocaleString("en-US", {
                        style: "currency",
                        currency: "PHP",
                      })}
                    </p>
                  </div> */}
                  {/* <hr className="border border-blue-500" /> */}
                  <div className="flex justify-between my-1">
                    <p className="font-semibold">Grand Total</p>
                    <p className="font-semibold">
                      {Number(modalData?.grandTotal).toLocaleString("en-US", {
                        style: "currency",
                        currency: "PHP",
                      })}
                    </p>
                  </div>
                  <hr className="border border-blue-500" />
                </div>
                <div
                  className={`p-4 ${
                    length > 15 || length == 12
                      ? "break-before-page"
                      : "break-before-avoid"
                  }`}
                >
                  <TermsAndCondition />
                </div>
                <hr className="border border-blue-500" />
                <div className="flex flex-col space-y-1">
                  <p className="font-medium text-blue-500">Remarks:</p>
                  <p className="whitespace-pre-line">{modalData?.remarks}</p>
                </div>
                <hr className="border border-blue-500" />
                <div className="grid grid-cols-3">
                  <div className="flex flex-col space-y-2">
                    <p className="font-medium text-blue-500">Prepared By:</p>
                    <p>{modalData?.preparedBy}</p>
                  </div>
                  <div className="flex flex-col space-y-2">
                    <p className="font-medium text-blue-500">Checked By:</p>
                    <p>{modalData?.checkedBy}</p>
                  </div>
                  <div className="flex flex-col space-y-2">
                    <p className="font-medium text-blue-500">Approved By:</p>
                    <p>{modalData?.approvedBy}</p>
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button onClick={() => setIsOpen(false)} className="md:w-1/5">
                Ok
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default PurchaseOrders;
