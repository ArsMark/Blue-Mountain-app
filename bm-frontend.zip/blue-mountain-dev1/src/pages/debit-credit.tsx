import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { ColumnDef, PaginationState, Row } from "@tanstack/react-table";
import { DataTable } from "@/components/ui/tables/DataTable";
import P from "@/components/ui/typography/P";
import H2 from "@/components/ui/typography/H2";
import { HiEye } from "react-icons/hi";
import { useEffect, useMemo, useRef, useState } from "react";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import DebitPDF from "@/components/PDF/DebitPDF";
import { AiFillPrinter } from "react-icons/ai";
import { useReactToPrint } from "react-to-print";
import { FaFileDownload } from "react-icons/fa";
import { z } from "zod";
import { DebitCreditSchema } from "@/schema/DebitCreditSchema";
import { zodResolver } from "@hookform/resolvers/zod";
import { DebitCreditMemo, IDebitCreditDetails } from "@/types/IDebitCredit";
import {
  useDebitCreditDetails,
  useDebitCreditStatus,
  useDebitCreditTable,
} from "@/utils/hooks/useDebitCredit";
import toast from "react-hot-toast";
import Spinner from "@/components/ui/spinner";
import DebouncedInput from "@/components/ui/tables/DebounceInput";
import { pdf } from "@react-pdf/renderer";
import { saveAs } from "file-saver";
import { useActionDownload } from "@/utils/hooks/useActionDownload";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import Image from "next/image";
import LoadingScreen from "@/components/ui/loading";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { useAuthMe } from "@/utils/hooks/useAuth";
import Unauthorized from "@/components/ui/unauthorized";
// import { usePostingType } from "@/utils/hooks/usePostingType";

export type FormValues = z.infer<typeof DebitCreditSchema>;

const DebitCredit = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [userId, setUserId] = useState(0);
  const [isDownload, setIsDownload] = useState(false);
  const [isCsvDownload, setIsCsvDownload] = useState(false);
  const [formValue, setFormValue] = useState<FormValues>({
    dm_number: "",
    dm_status: "",
    vendorName: "",
    document_date_from: undefined,
    document_date_to: undefined,
    posting_type: "",
    read_status: "all",
    results: "10",
  });
  const form = useForm<FormValues>({
    resolver: zodResolver(DebitCreditSchema),
    defaultValues: {
      dm_number: "",
      dm_status: "",
      vendorName: "",
      document_date_from: undefined,
      document_date_to: undefined,
      posting_type: "",
      read_status: "all",
      results: "10",
    },
  });

  const [page, setPage] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: Number(formValue.results),
  });

  useEffect(() => {
    if (formValue || searchText) {
      setPage({
        pageIndex: 0,
        pageSize: Number(formValue.results),
      });
    }
  }, [formValue, searchText]);

  const pagination = useMemo(() => {
    return {
      pageIndex: page.pageIndex,
      pageSize: Number(formValue.results),
    };
  }, [page, formValue]);

  const { data, isLoading, refetch } = useDebitCreditTable(
    formValue,
    pagination,
    searchText,
    isCsvDownload,
    setIsCsvDownload
  );
  const { data: modalData, isSuccess, isLoading: isFetchingDebitlDetails } = useDebitCreditDetails(userId);
  const { mutate } = useActionDownload();
  // const { data: documentStatus } = useDebitCreditStatus();
  // const { data: postingType } = usePostingType();
  const { data: userData } = useAuthMe();

  const modalRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    content: () => modalRef.current,
  });

  useEffect(() => {
    if (isSuccess) {
      refetch();
    }
  }, [isSuccess]);

  useEffect(() => {
    if (modalData && isDownload && isSuccess) {
      downloadPDF(modalData);
    }
  }, [modalData, isDownload, isSuccess]);
  const downloadPDF = async (data: IDebitCreditDetails | undefined) => {
    const blob = await pdf(<DebitPDF data={data} />).toBlob();
    saveAs(blob, "Debit.pdf");
    mutate({ action: "Downloaded a Debit." });
    setIsDownload(false);
  };

  const columns: ColumnDef<DebitCreditMemo>[] = [
    {
      accessorKey: "debitCreditMemoNumber",
      header: "DM/VRA #",
    },
    {
      accessorKey: "postingType",
      header: "POSTING TYPE",
    },
    {
      id: "vendorName",
      accessorKey: "vendor.name",
      header: "VENDOR NAME",
      cell: ({ row }) => {
        return (
          <div className="truncate overflow-hidden w-[200px] mx-auto">
            {row.original.vendor.name}
          </div>
        );
      },
    },
    {
      accessorKey: "documentDate",
      header: "DOCUMENT DATE",
      cell: ({ row }) => {
        return (
          <div>{new Date(row.original.documentDate).toLocaleDateString()}</div>
        );
      },
    },
    {
      accessorKey: "total",
      header: "TOTAL",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.total).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    // {
    //   accessorKey: "debitCreditMemoStatus",
    //   header: "DM/CM STATUS",
    // },
    {
      accessorKey: "isRead",
      header: "READ STATUS",
      cell: ({ row }) => {
        return (
          <div>
            {row.original.isRead ? (
              <span className="text-green-500">Read</span>
            ) : (
              <span className="text-red-500">Unread</span>
            )}
          </div>
        );
      },
    },
    {
      accessorKey: "actions",
      header: "ACTIONS",
      //getting data every row
      cell: ({ row }) => {
        return (
          <div className="flex gap-1 justify-center">
            <Button
              onClick={() => {
                getRows(row.original.id);
              }}
              className="w-8 h-8"
              size="icon"
              variant="icon"
            >
              <HiEye size="20" />
            </Button>
            <Button
              className="w-8 h-8"
              variant="icon"
              onClick={() => {
                setIsOpen(true);
                setUserId(row.original.id);
                mutate({ action: "Printed a Debit Credit Memo." });
                toast.loading("Printing...", { duration: 3000 });
                setTimeout(handlePrint, 3000);
              }}
              size="icon"
            >
              <AiFillPrinter size="20" />
            </Button>
            <Button
              className="w-8 h-8"
              size="icon"
              variant="icon"
              onClick={() => {
                setUserId(row.original.id);
                toast.loading("Downloading PDF...", { duration: 3000 });
                setIsDownload(true);
              }}
            >
              <FaFileDownload size="20" />
            </Button>
          </div>
        );
      },
    },
  ];

  const getRows = (id: number) => {
    setUserId(id);
    setIsOpen(true);
  };

  const onSubmit = (values: FormValues) => {
    setFormValue(values);
    toast.success("Filter has been applied");
  };

  const handleClearFilter = () => {
    form.reset({
      dm_number: "",
      dm_status: "",
      posting_type: "",
      read_status: "all",
      results: "10",
    });
    setFormValue({
      dm_number: "",
      dm_status: "",
      vendorName: "",
      posting_type: "",
      read_status: "all",
      results: "10",
    });
    toast.success("Filter has been cleared");
  };

  const downloadCSV = () => {
    setIsCsvDownload(true);
  };
  
  if (userData?.role !== 'admin-accounting' && userData?.role !== 'vendor' && userData?.role !== 'accounting' && userData?.role !== 'admin') {
    return <Unauthorized />
  }

  return (
    <div className="flex flex-col space-y-4">
      <h1 className="scroll-m-20 text-2xl font-medium tracking-tight mb-2">
        Debit Memo
      </h1>
      <div className="bg-white w-full p-8 rounded-md">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="flex flex-col md:flex-row md:justify-between">
              <P>Current View</P>
              {/* <FormField
                control={form.control}
                name="dm_status"
                render={({ field }) => (
                  <FormItem className="flex flex-col md:w-1/4">
                    <FormLabel>DM/CM Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {documentStatus?.map((status, index) => (
                          <SelectItem key={index} value={status}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              /> */}
            </div>
            <hr className="my-2" />
            <div className="flex flex-col gap-2 md:grid md:grid-cols-2">
              <FormField
                control={form.control}
                name="dm_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>DM/VRA Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="document_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Document Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="document_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Document Date To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="vendorName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vendor Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="results"
                defaultValue="10"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Results</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="10 per page" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {[10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map(
                          (val, index) => (
                            <SelectItem key={index} value={val.toString()}>
                              {val}
                            </SelectItem>
                          )
                        )}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="read_status"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Read Status</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="flex flex-row items-center space-x-4"
                      >
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="all" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            All
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="false" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Unread
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="true" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Read
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex flex-col md:flex-row md:justify-end gap-2 mt-2">
              <Button
                className="w-full md:w-1/6"
                type="submit"
                disabled={isLoading}
              >
                Search
              </Button>
              <Button
                className="w-full md:w-1/6"
                variant="outline"
                type="reset"
                onClick={handleClearFilter}
                disabled={isLoading}
              >
                Clear
              </Button>
            </div>
          </form>
        </Form>
      </div>

      <div className="flex flex-col space-y-2">
        <div className="flex justify-between items-center flex-wrap gap-2 ">
          <DebouncedInput
            value={searchText ?? ""}
            onChange={(value) => setSearchText(String(value))}
          />
          <Button
            className="md:w-1/5"
            onClick={downloadCSV}
            disabled={isCsvDownload}
          >
            {isCsvDownload ? <Spinner /> : "Export"}
          </Button>
        </div>
        <DataTable
          columns={columns}
          data={data?.debitCreditMemos ?? []}
          page={page}
          setPage={setPage}
          loading={isLoading}
          vendorVisibility={userData?.role !== "vendor" ? true : false}
          displayPagination
          total={data?.totalCount}
          textAlign="text-center"
        />
      </div>
      <Dialog open={isOpen} onOpenChange={(val) => setIsOpen(val)}>
        <DialogContent
          className={
            "lg:max-w-screen-lg flex flex-col space-y-4 overflow-y-auto max-h-[90%] scrollbar"
          }
        >
           {isFetchingDebitlDetails && (
              <LoadingScreen details="Debit"/>
          )}
          <div ref={modalRef} className="flex flex-col space-y-2">
            {modalData?.subsidiary?.logo && (
              <div className="w-32 h-16 relative">
                <Image
                  src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${modalData?.subsidiary?.logo}`}
                  alt={"Logo"}
                  fill
                  objectFit="contain"
                  quality={100}
                  draggable={false}
                />
              </div>
              )}

            <div className="flex justify-between items-center">
              <p className="font-medium">Debit Memo</p>
            </div>

            <p>Primary Information</p>
            <div className="flex flex-wrap items-center justify-between">
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Document #</p>
                <p>{modalData?.documentNumber}</p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Date</p>
                <p>
                  {!!modalData?.documentDate &&
                    new Date(modalData?.documentDate).toLocaleDateString()}
                </p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Reference #</p>
                <p>{modalData?.referenceNumber}</p>
              </div>
            </div>

            <div className="flex items-center">
              <div className="flex flex-col space-y-2 w-full">
                <p className="font-medium text-blue-500">Bill To</p>
                <p>{modalData?.billTo}</p>
              </div>
              <div className="flex flex-col space-y-2 w-full">
                <p className="font-medium text-blue-500">Bill Address</p>
                <p>{modalData?.billingAddress}</p>
              </div>
            </div>
            <hr className="border border-blue-500" />
            <p className="font-medium text-blue-500">Particular</p>
            <p>{modalData?.particular}</p>
            <div className="flex space-x-2 items-center justify-end">
              <p className="text-blue-700 font-medium">Total Amount:</p>
              <p className="font-medium">
                {Number(modalData?.total).toLocaleString("en-US", {
                  style: "currency",
                  currency: "PHP",
                })}
              </p>
            </div>
            <hr className="border border-blue-500" />
            <div className="grid grid-cols-4">
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Prepared By:</p>
                <p>{modalData?.preparedBy}</p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Checked By:</p>
                <p>{modalData?.checkedBy}</p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Approved By:</p>
                <p>{modalData?.approvedBy}</p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Received By:</p>
                <p>{modalData?.receivedBy}</p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsOpen(false)} className="md:w-1/5">
              Ok
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DebitCredit;
