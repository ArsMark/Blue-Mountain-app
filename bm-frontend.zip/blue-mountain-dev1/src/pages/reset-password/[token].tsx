import Image from "next/image";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react";
import waves from "../../../public/images/waves.png";
import { z } from "zod";
import { resetPasswordSchema } from "@/schema/resetPasswordSchema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Eye, EyeOff } from "lucide-react";
import { useResetPassword } from "@/utils/hooks/usePassword";
import Spinner from "@/components/ui/spinner";

type Reset = z.infer<typeof resetPasswordSchema>;

const ResetPasswordPage = () => {
  const router = useRouter();
  const { token } = router.query;
  const [toggleNewPassword, setToggleNewPassword] = useState(false);
  const [toggleConfirmPassword, setToggleConfimPassword] = useState(false);

  const { mutate, isLoading } = useResetPassword(token);

  const form = useForm<Reset>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      new_password: "",
      confirm_password: "",
    },
  });

  const onSubmit = (values: Reset) => {
    const data = {
      newPassword: values.new_password,
      confirmNewPassword: values.confirm_password,
    };
    mutate(data, {
      onSuccess: () => {
        router.push("/login");
      },
    });
  };
  const handleTogglePassword = (
    toggleFunction: React.Dispatch<React.SetStateAction<boolean>>
  ) => {
    toggleFunction((prev) => !prev);
  };

  const handleNewPassword = () => {
    handleTogglePassword(setToggleNewPassword);
  };
  const handleConfirmPassword = () => {
    handleTogglePassword(setToggleConfimPassword);
  };

  return (
    <div className="bg-[#ECF3FE] min-h-screen relative">
      <div className="w-full bg-white rounded-md p-4 mx-auto absolute top-[40%] left-1/2 transform -translate-x-1/2 -translate-y-1/2 md:w-[60vw] lg:w-[30vw]">
        <h1 className="font-semibold mb-4 text-lg">Reset your Password</h1>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="flex flex-col gap-4"
          >
            <FormField
              control={form.control}
              name="new_password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>New Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type={toggleNewPassword ? "text" : "password"}
                      />
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 cursor-pointer">
                        {toggleNewPassword ? (
                          <EyeOff
                            className="h-5 w-5"
                            onClick={handleNewPassword}
                          />
                        ) : (
                          <Eye
                            className="h-5 w-5"
                            onClick={handleNewPassword}
                          />
                        )}
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="confirm_password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type={toggleConfirmPassword ? "text" : "password"}
                      />
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 cursor-pointer">
                        {toggleConfirmPassword ? (
                          <EyeOff
                            className="h-5 w-5"
                            onClick={handleConfirmPassword}
                          />
                        ) : (
                          <Eye
                            className="h-5 w-5"
                            onClick={handleConfirmPassword}
                          />
                        )}
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit">
              {isLoading ? <Spinner /> : "Continue"}
            </Button>
          </form>
        </Form>
      </div>
      <div className="absolute inset-x-0 bottom-0">
        <Image src={waves} alt="Waves images" draggable={false} />
      </div>
    </div>
  );
};

ResetPasswordPage.getLayout = function getLayout(page: React.ReactElement) {
  return <>{page}</>;
};

export default ResetPasswordPage;
