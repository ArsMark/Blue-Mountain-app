import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/tables/DataTable";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import Link from "next/link";
import { HiEye, HiOutlineArrowNarrowLeft, HiPrinter } from "react-icons/hi";
import H2 from "@/components/ui/typography/H2";
import BillPDF from "@/components/PDF/BillPDF";
import { useReactToPrint } from "react-to-print";
import { AiFillPrinter } from "react-icons/ai";
import { useRouter } from "next/router";
import { useBillDetails, useBillModal } from "@/utils/hooks/useBill";
import { Billing } from "@/types/IBill";
import { useActionDownload } from "@/utils/hooks/useActionDownload";
import { useAuthMe } from "@/utils/hooks/useAuth";
import toast from "react-hot-toast";
import { BillingPO, IBillModal } from "@/types/IBillModal";
import { pdf } from "@react-pdf/renderer";
import { saveAs } from "file-saver";
import LoadingScreen from "@/components/ui/loading";
import { useVendorDetails } from "@/utils/hooks/useVendor";
import Image from "next/image";
import { getCookie } from "cookies-next";
import Unauthorized from "@/components/ui/unauthorized";

const BillInfo = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userId, setUserId] = useState(0);
  const [isDownload, setIsDownload] = useState(false);
  const [page, setPage] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });
  const router = useRouter();
  const { id } = router.query;

  const pagination = useMemo(() => {
    return {
      pageIndex: page.pageIndex,
      pageSize: page.pageSize,
    };
  }, [page]);
  const subsidiaryId = getCookie("subsidiaryId");
  
  const { data, isFetching } = useBillDetails(pagination, id, subsidiaryId);
  const { data: modalData, isSuccess, isLoading: isFetchingBillDetails } = useBillModal(userId);
  const { mutate } = useActionDownload();
  const { data: userData } = useAuthMe();
  const { data: vendorData } = useVendorDetails(id?.[1]);

  useEffect(() => {
    if (modalData && isDownload && isSuccess) {
      downloadPDF(modalData);
    }
  }, [modalData, isDownload, isSuccess]);

  const downloadPDF = async (data: IBillModal) => {
    const blob = await pdf(<BillPDF data={data} />).toBlob();
    mutate({ action: "Downloaded a Bill." });
    saveAs(blob, `Bill${modalData?.billingNumber}-${vendorData?.name}.pdf`);
    setIsDownload(false);
  };

  const modalRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    content: () => modalRef.current,
  });

  const columns: ColumnDef<Billing>[] = [
    {
      accessorKey: "transactionDate",
      header: "POSTING DATE",
      cell: ({ row }) => {
        return (
          <div>
            {new Date(row.original.transactionDate).toLocaleDateString()}
          </div>
        );
      },
    },
    {
      accessorKey: "transactionMonth",
      header: "POSTING MONTH",
      cell: ({ row }) => {
        return <div>{row.original.transactionMonth}</div>;
      },
    },
    {
      accessorKey: "docNumber",
      header: "DOC #",
    },
    {
      accessorKey: "supplierInvoiceReference",
      header: "SUPPLIERS INVOICE",
    },
    {
      accessorKey: "amount",
      header: "AMOUNT",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.grossAmount).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    {
      accessorKey: "vat",
      header: "VAT",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.vat).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    {
      accessorKey: "ewt",
      header: "EWT",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.withHoldingTax).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    {
      accessorKey: "netAmount",
      header: "NET AMOUNT",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.netAmount).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },

    {
      accessorKey: "actions",
      header: "ACTIONS",
      //getting data every row
      cell: ({ row }) => {
        return (
          <div className="flex gap-1 justify-center">
            {/* <Button
              onClick={() => {
                getRows(row.original.id);
              }}
              className="w-8 h-8"
              size="icon"
              variant="icon"
            >
              <HiEye size="20" />
            </Button> */}
            <Button
              className="w-8 h-8"
              variant="icon"
              onClick={() => {
                setIsOpen(true);
                setUserId(row.original.id);
                mutate({ action: "Printed a Bill." });
                toast.loading("Printing...", { duration: 3000 });
                setTimeout(handlePrint, 3000);
              }}
              size="icon"
            >
              <AiFillPrinter size="20" />
            </Button>
          </div>
        );
      },
    },
  ];
  const modalColumns: ColumnDef<BillingPO>[] = [
    {
      accessorKey: "item.name",
      header: "Item",
      id: "item_name",
    },
    {
      accessorKey: "quantity",
      header: "Quantity",
      id: "quantity",
    },
    {
      accessorKey: "netAmount",
      header: "Net of VAT",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.netAmount).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    {
      accessorKey: "taxAmount",
      header: "Tax Amount",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.taxAmount).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    {
      accessorKey: "grossAmount",
      header: "Gross Amount",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.grossAmount).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    {
      accessorKey: "discount",
      header: "Total Discount",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.discount).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    }
  ];
  const getRows = (id: number) => {
    setUserId(id);
    setIsOpen(true);
  };

  if (userData?.role !== 'admin-accounting' && userData?.role !== 'vendor' && userData?.role !== 'accounting' && userData?.role !== 'admin') {
    return <Unauthorized />
  }

  const length = modalData?.billingPOs.length ?? 0;
  const osd = modalData?.otherSpecialDiscount ?? 0;
  const tctd = modalData?.centralTlcDiscount ?? 0;
  const tcdd = modalData?.centralDropDiscount ?? 0;
  const ttd = modalData?.tradeDiscount ?? 0;
  
  return (
    <div className="flex flex-col space-y-4 h-[100vh]">
      <Link
        href="/bill"
        className="flex items-center gap-2 text-blue-800 font-medium w-fit"
      >
        <HiOutlineArrowNarrowLeft size="20" /> Go back
      </Link>
      <H2>
        Vendor: <span>{vendorData?.name}</span>
      </H2>
      <DataTable
        columns={columns}
        loading={isFetching}
        data={data?.billings ?? []}
        displayPagination
        page={page}
        setPage={setPage}
        displayFooter
        footerData={data?.totalBillings}
        total={data?.totalCount}
        rowClassName="bg-transparent hover:bg-transparent"
        textAlign="text-center"
      />

      <Dialog open={isOpen} modal onOpenChange={(val) => setIsOpen(val)}>
        <DialogContent
          className={
            "lg:max-w-screen-lg font-mulish overflow-y-auto max-h-[90%] scrollbar"
          }
        >
          {isFetchingBillDetails && (
            <LoadingScreen details="Bill"/>
          )}
          <div ref={modalRef} className="flex flex-col space-y-2">
            {modalData?.subsidiary?.logo && (
              <div className="w-32 h-16 relative">
                <Image
                  src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${modalData?.subsidiary?.logo}`}
                  alt={"Logo"}
                  fill
                  objectFit="contain"
                  quality={100}
                  draggable={false}
                />
              </div>
            )}
            <div className="flex justify-between items-center">
              <p>{modalData?.type}</p>
            </div>

            <p>Primary Information</p>
            <div className="flex items-center">
              <div className="flex flex-col space-y-1 w-full">
                <p className="font-medium text-blue-700">Transaction No.</p>
                <p>{modalData?.billingNumber}</p>
              </div>
              <div className="flex flex-col space-y-1 w-full">
                <p className="font-medium text-blue-700">Vendor</p>
                <p>{modalData?.vendor?.name}</p>
              </div>
              <div className="flex flex-col space-y-1 w-full">
                <p className="font-medium text-blue-700">Terms</p>
                <p>{modalData?.terms}</p>
              </div>
            </div>
            {/* <p className="text-blue-700 font-medium">Remarks:</p>
            <div
              dangerouslySetInnerHTML={{ __html: `${modalData?.remarks}` }}
            /> */}
            <hr className="border border-blue-700" />
            <p>Date Information</p>
            <div className="flex flex-wrap items-center justify-between">
              <div className="flex flex-col space-y-1">
                <p className="font-medium text-blue-700">Transaction Date</p>
                <p>
                  {!!modalData?.transactionDate &&
                    new Date(modalData?.transactionDate).toLocaleDateString()}
                </p>
              </div>
              <div className="flex flex-col space-y-1">
                <p className="font-medium text-blue-700">Due Date</p>
                <p>
                  {!!modalData?.dueDate &&
                    new Date(modalData?.dueDate).toLocaleDateString()}
                </p>
              </div>
              <div className="flex flex-col space-y-1">
                <p className="font-medium text-blue-700">P.O Number</p>
                <p>{modalData?.poNumber}</p>
              </div>
              <div className="flex flex-col space-y-1">
                <p className="font-medium text-blue-700">I.R Number</p>
                <p>{modalData?.irNumber}</p>
              </div>
              {/* <div className="flex flex-col space-y-1">
                <p className="font-medium text-blue-700">Status</p>
                {modalData?.isRead ? (
                  <p className="text-green-500">Read</p>
                ) : (
                  <p className="text-red-500">Unread</p>
                )}
              </div> */}
            </div>
            <div
            // className={`${
            //   length >= 3 ? "break-after-page" : "break-before-avoid-page"
            // }`}
            >
            <hr className="border border-blue-700" />
            {/* <p>Billing Information</p>
            <div className="flex flex-row items-center justify-between pb-2">
              <h1 className="w-3/6 font-medium text-blue-700">Item</h1>
              <h1 className="text-right font-medium text-blue-700 w-1/6">
                Tax Amount
              </h1>
              <h1 className="w-1/6 text-right font-medium text-blue-700">
                Net Amount
              </h1>
              <h1 className=" w-1/6 text-right font-medium text-blue-700">
                Discount
              </h1>
              <h1 className=" w-1/6 text-right font-medium text-blue-700">
                Gross Amount
              </h1>
            </div>
            {modalData?.billingPOs?.map((item, index) => {
              return (
                <div
                  key={index}
                  className="flex flex-row items-center text-[.80rem] pb-2"
                >
                  <p className="w-3/6">{item.item.name}</p>
                  <p className=" w-1/6 ">
                    {Number(item.netAmount).toLocaleString("en-US", {
                      currency: "PHP",
                      style: "currency",
                    })}
                  </p>
                  <p className=" w-1/6 ">
                    {Number(item.taxAmount).toLocaleString("en-US", {
                      currency: "PHP",
                      style: "currency",
                    })}
                  </p>
                  <p className="w-1/6">
                    {Number(item.discount).toLocaleString("en-US", {
                      currency: "PHP",
                      style: "currency",
                    })}
                  </p>
                  <p className=" w-1/6">
                    {Number(item.grossAmount).toLocaleString("en-US", {
                      currency: "PHP",
                      style: "currency",
                    })}
                  </p>
                </div>
              );
            })} */}
              <DataTable
                columns={modalColumns}
                loading={isFetching}
                data={modalData?.billingPOs ?? []}
                displayPagination={false}
                total={modalData?.billingPOs.length}
                rowClassName="bg-transparent hover:bg-transparent"
                textAlign="text-left "
              />
            </div>
            <hr className="border border-blue-700 mt-1" />
            <div className="grid grid-cols-6 my-1">
              <h1 className="text-left font-medium text-blue-700 col-span-1">Gross Amount</h1>
              <div className="col-span-5 flex flex-row justify-end text-right ">
                {/* <h1 className="font-semibold ">
                  {Number(modalData?.grossAmount).toLocaleString("en-US", {
                    currency: "PHP",
                    style: "currency",
                  })}
                </h1>
                <h1 className="font-semibold">
                  {Number(modalData?.vat).toLocaleString("en-US", {
                    currency: "PHP",
                    style: "currency",
                  })}
                </h1>
                <h1 className="font-semibold">
                  {Number(modalData?.netAmount).toLocaleString("en-US", {
                    currency: "PHP",
                    style: "currency",
                  })}
                </h1> */}
               
                <h1 className="font-semibold">
                  {Number(modalData?.totalgrossAmount).toLocaleString("en-US", {
                    currency: "PHP",
                    style: "currency",
                  })}
                </h1>
              </div>
            </div>

            <div className="flex flex-col space-y-1">
            {(ttd != 0 || tcdd != 0 || tctd != 0 || osd != 0) && (
              <>
                {/* <hr className="border border-blue-700" /> */}
                <h1 className="text-blue-700 font-medium">Discount:</h1>
              </>
             )}
             {ttd != 0 && (
              <div className="flex justify-between items-center">
                <p className="text-sm">Trade Discount</p>
                <p className="font-medium">
                  {Number(modalData?.tradeDiscount).toLocaleString("en-US", {
                    currency: "PHP",
                    style: "currency",
                  })}
                </p>
              </div>
             )}
            {tcdd != 0 && (
                <div className="flex justify-between items-center">
                  <p className="text-sm">Central Drop Discount</p>
                  <p className="font-medium">
                    {Number(modalData?.centralDropDiscount).toLocaleString(
                      "en-US",
                      {
                        currency: "PHP",
                        style: "currency",
                      }
                    )}
                  </p>
                </div>
              )}
              {tctd != 0 && (
                <div className="flex justify-between items-center">
                <p className="text-sm">Central TLC Discount</p>
                <p className="font-medium">
                  {Number(modalData?.centralTlcDiscount).toLocaleString(
                    "en-US",
                    {
                      currency: "PHP",
                      style: "currency",
                    }
                  )}
                </p>
              </div>
               )}
              {osd != 0 && (
                <div className="flex justify-between items-center">
                 <p className="text-sm">Other Special Discount</p>
                 <p className="font-medium">
                   {Number(modalData?.otherSpecialDiscount).toLocaleString(
                     "en-US",
                     {
                       currency: "PHP",
                       style: "currency",
                     }
                   )}
                 </p>
               </div>
              )}
            
              <div className="flex justify-between items-center">
                <p className="text-sm">EWT</p>
                <p className="font-medium">
                  {Number(modalData?.withHoldingTax).toLocaleString("en-US", {
                    currency: "PHP",
                    style: "currency",
                  })}
                </p>
              </div>
              <hr className="border border-blue-700" />
              <div className="flex justify-between items-center">
                <p className="text-sm font-semibold">Grand Total</p>
                <p className="font-semibold">
                  {Number(modalData?.amount).toLocaleString("en-US", {
                    currency: "PHP",
                    style: "currency",
                  })}
                </p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsOpen(false)} className="md:w-1/5">
              Ok
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BillInfo;
