import CustomButton from "@/components/custom-button";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Spinner from "@/components/ui/spinner";
import { Textarea } from "@/components/ui/textarea";
import H3 from "@/components/ui/typography/H3";
import { ContactSchema } from "@/schema/ContactSchema";
import { IActivityLog } from "@/types/IActivityLog";
import api from "@/utils/api";
import { useAuthMe } from "@/utils/hooks/useAuth";
import { useDepartmentEmail } from "@/utils/hooks/useDepartment";
import { useModule } from "@/utils/hooks/useModule";
import { useSendMessages } from "@/utils/hooks/useSendMessages";
import { modules } from "@/utils/modules";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { getCookie } from "cookies-next";
import { Download } from "lucide-react";
import dynamic from "next/dynamic";
import Image from "next/image";
import { useState, useEffect } from "react";
import { useForm, } from "react-hook-form";
import { z } from "zod";
import ContactSVG from "../../public/images/ContactSVG.png";
import { useLastLogin } from "@/utils/hooks/useLastLogin";
import { format } from "date-fns";
import { useWorker } from "@/utils/hooks/useWorker";

const DateTime = dynamic(() => import("../components/ui/Datetime"), {
  ssr: false,
});

type FormValues = z.infer<typeof ContactSchema>;

const fetchAuth = () => {
  return api
    .get("/api/auth/me", {
      headers: { Authorization: "Bearer " + getCookie("user") },
    })
    .then((res) => res.data);
};

const fetchActivity = () => {
  return api
    .get(`/api/activityLogs`, {
      params: {
        limit: 10,
      },
      headers: {
        Authorization: "Bearer " + getCookie("user"),
      },
    })
    .then((res) => res.data);
};

const fetchData = async () => {
  await fetchAuth();
  return await fetchActivity();
};

const Home = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [showLoading, setShowLoading] = useState(false);
  const form = useForm<FormValues>({ resolver: zodResolver(ContactSchema) });
  const { mutate, isLoading } = useSendMessages();
  const { data: moduleData, isLoading: moduleLoading } = useModule();
  const { data: emailData } = useDepartmentEmail();
  const { data: loginData } = useLastLogin();
  const { data: userData } = useAuthMe();
  const { data: workerData } = useWorker();
  const current_role = userData?.role
  // console.log(userData)
  const { data } = useQuery<IActivityLog>({
    queryKey: ["activityLogs"],
    queryFn: fetchData,
    refetchOnWindowFocus: false,
    refetchInterval: 0,
  });

  if (moduleLoading) {
    return (
      <div className="h-[50vh] grid place-items-center">
        <Spinner />
      </div>
    );
  }

  const onSubmit = (values: FormValues) => {
    mutate(values, {
      onSuccess: () => {
        setIsOpen(false);
        setIsContactOpen(false)
        form.reset();
      },
    });
  };

  const downloadCSV = () => {
    // Make a request to the backend to get the CSV data
    setShowLoading(true);
    axios({
      url: `${process.env.NEXT_PUBLIC_API_URL}/api/activityLogs`,
      headers: {
        Authorization: "Bearer " + getCookie("user"),
      },
      params: {
        csv: true,
      },
      method: "get",
      responseType: "blob",
    })
      .then((response) => {
        // console.log(response);
        const href = URL.createObjectURL(response.data);
        const link = document.createElement("a");
        link.href = href;
        link.setAttribute("download", `Activity Logs.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(href);
      })
      .catch((error) => {
        if (error.response) {
          if (error.response.status === 401) {
            console.error("Invalid access token");
            window.location.href = "/login";
          } else if (error.response.status === 403) {
            console.error("Invalid refreshed access token");
            window.location.href = "/login";
          } else {
            console.error("An error occurred:", error.response.data);
            // Handle other errors
          }
        } else {
          console.error("An error occurred:", error.message);
          // Handle errors that are not related to the response
        }
      })
      .finally(() => {
        setShowLoading(false);
      });

  };

  const currentDate = new Date();

  return (
    <div className="flex flex-col space-y-4">
      <h1 className="scroll-m-20 text-2xl font-medium tracking-tight mb-2">
        Home
      </h1>
      <div className="flex items-center justify-between">
        <p>
          Last Logged In:{" "}
          <span className="font-medium">
            {loginData?.activityLogs?.length
              ? format(
                new Date(loginData?.activityLogs?.[0]?.createdAt as string),
                "MMMM d, yyyy | h:mm a"
              )
              : format(currentDate, "MMMM d, yyyy | h:mm a")}
          </span>
        </p>
        <DateTime />
      </div>

      <Button onClick={() => setIsOpen(true)} className="md:w-1/5">
        View log
      </Button>
      <Dialog onOpenChange={(val) => setIsOpen(val)} open={isOpen}>
        <DialogContent className="md:min-w-[35vw]">
          <div className="flex flex-col space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <H3>Activity Log</H3>
              </div>
              <Button size="icon" onClick={downloadCSV} disabled={showLoading}>
                {showLoading ? <Spinner /> : <Download />}
              </Button>
            </div>
            <div className="grid grid-cols-3">
              <p className="font-medium">Date</p>
              <p className="font-medium">Time</p>
              <p className="font-medium">Activity</p>
            </div>
            <ScrollArea className="h-72 w-full">
              {data?.activityLogs.map((item, index) => {
                const createdAt = item.createdAt;
                const date = new Date(createdAt).toLocaleDateString();
                const time = new Date(createdAt).toLocaleTimeString();
                return (
                  <div
                    key={item.id}
                    className="grid grid-cols-3 text-gray-600 mb-3"
                  >
                    <p>{date}</p>
                    <p>{time}</p>
                    <p>{item.action}</p>
                  </div>
                );
              })}
            </ScrollArea>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsOpen(false)} className="md:w-1/5">
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <div className="flex gap-2 md:w-1/4">
      <a className="w-full" href="/manual.pdf" download>
        <Button  variant="link" >User Manual</Button>
      </a>
        <Button variant="link" onClick={() => setIsContactOpen(true)}>
          Contact Us
        </Button>
      </div>
      <Dialog
        onOpenChange={(val) => setIsContactOpen(val)}
        open={isContactOpen}
      >
        <DialogContent className="md:min-w-[45vw]">
          <div className="w-full flex md:justify-between md:relative">
            <div className="w-full flex flex-col space-y-4">
              <h1 className="text-4xl font-bold">Contact Us</h1>
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="flex flex-col space-y-2"
                >
                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input {...field} placeholder="Full Name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="senderEmail"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input {...field} placeholder="Email address" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="departmentId"
                    render={({ field }) => (
                      <FormItem>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select department" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {emailData?.departments?.map((item) => (
                              <SelectItem key={item.id} value={String(item.id)}>
                                {item.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input {...field} placeholder="Subject" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea {...field} placeholder="Message" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex justify-end w-full">
                    <Button
                      className="w-full md:w-1/2"
                      type="submit"
                      disabled={isLoading}
                    >
                      {isLoading && <Spinner />} Confirm
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
            <div className="w-full hidden md:relative md:block">
              <div className="w-full aspect-square hidden md:block md:absolute md:bottom-0 md:right-0">
                <Image src={ContactSVG} alt="Contact SVG" />
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      <div className="grid place-items-center grid-cols-2 md:grid-cols-4 md:place-items-center md:space-y-2">

        {current_role &&
          modules
            .filter((module) => module.role.includes(current_role))
            .map((module) => {
              let displayText = module.text;

             
              if (module.text === "Bill") {
                if (workerData?.data?.bill?.isFetching) {
                  displayText += " (Fetching)";
                } else if (workerData?.data?.bill?.onQueue) {
                  displayText += " (In Queue)";
                }
              }

              
              if (module.text === "Payment") {
                if (workerData?.data?.payment?.isFetching) {
                  displayText += " (Fetching)";
                } else if (workerData?.data?.payment?.onQueue) {
                  displayText += " (In Queue)";
                }
              }

              return (
                <CustomButton
                  key={module.key}
                  color={module.color}
                  text={displayText}
                  link={module.link}
                  role={module.role}
                  count={moduleData?.[module.key]}
                />
              );
            })}

      </div>
    </div>
  );
};

export default Home;
