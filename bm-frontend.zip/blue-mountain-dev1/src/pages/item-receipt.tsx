import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import { DataTable } from "@/components/ui/tables/DataTable";
import { HiCheck, HiEye } from "react-icons/hi";
import { Fragment, useEffect, useMemo, useRef, useState , useCallback} from "react";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import { useReactToPrint } from "react-to-print";
import { AiFillPrinter } from "react-icons/ai";
import { FaFileDownload } from "react-icons/fa";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { itemReceiptSchema } from "@/schema/itemReceiptSchema";
import { IItemReceiptDetails, ItemReceipt } from "@/types/ItemReceipt";
import DebouncedInput from "@/components/ui/tables/DebounceInput";
import {
  useItemReceiptDetails,
  useItemReceiptStatus,
  useItemReceiptTable,
} from "@/utils/hooks/useItemReceipt";
import { toast } from "react-hot-toast";
import { saveAs } from "file-saver";
import ItemReceiptPDF from "@/components/PDF/ItemReceiptPDF";
import { pdf } from "@react-pdf/renderer";
import { useActionDownload } from "@/utils/hooks/useActionDownload";
import { useWarehouseLocationData } from "@/utils/hooks/useWarehouseLocation";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command";
import CDebouncedInput from "@/components/ui/CommandInput";
import Spinner from "@/components/ui/spinner";
import { format } from "date-fns";
import { CalendarIcon, ChevronsUpDown } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { useAuthMe } from "@/utils/hooks/useAuth";
import LoadingScreen from "@/components/ui/loading";
import Image from "next/image";
import { useSubsidiaryDetails } from "@/utils/hooks/useSubsidiary";
import { getCookie } from "cookies-next";

export type FormValues = z.infer<typeof itemReceiptSchema>;

const TabItemReceipts = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userId, setUserId] = useState(0);
  const [isSeeMore, setIsSeeMore] = useState(1);
  const [isDownload, setIsDownload] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [isCsvDownload, setIsCsvDownload] = useState(false);
  const [searchLocation, setSearchLocation] = useState<string | number>("");
  const [formValue, setFormValue] = useState<FormValues>({
    delivery_date_from: undefined,
    delivery_date_to: undefined,
    document_status: "",
    ir_number: "",
    po_number: "",
    read_status: "all",
    receipt_date_from: undefined,
    receipt_date_to: undefined,
    results: "10",
    vendor_name: "",
    warehouse_location: "",
  });
  const form = useForm<FormValues>({
    resolver: zodResolver(itemReceiptSchema),
    defaultValues: {
      delivery_date_from: undefined,
      delivery_date_to: undefined,
      document_status: "",
      ir_number: "",
      po_number: "",
      read_status: "all",
      receipt_date_from: undefined,
      receipt_date_to: undefined,
      results: "10",
      vendor_name: "",
      warehouse_location: "",
    },
  });

  const [page, setPage] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: Number(formValue.results),
  });

  useEffect(() => {
    if (formValue || searchText) {
      setPage({
        pageIndex: 0,
        pageSize: Number(formValue.results),
      });
    }
  }, [formValue, searchText]);

  const pagination = useMemo(() => {
    return {
      pageIndex: page.pageIndex,
      pageSize: Number(formValue.results),
    };
  }, [page, formValue]);
  const modalRef = useRef<HTMLDivElement>(null);

  const { data, isLoading } = useItemReceiptTable(
    formValue,
    pagination,
    searchText,
    isCsvDownload,
    setIsCsvDownload
  );
  const { data: modalData, isSuccess, isLoading: isFetchingIRDetails } = useItemReceiptDetails(userId);
  const { mutate } = useActionDownload();
  const subsidiaryId = getCookie("subsidiaryId");
  const { data: subsidiary } = useSubsidiaryDetails(subsidiaryId);
  const {
    data: warehouseData,
    isFetching,
    fetchNextPage,
  } = useWarehouseLocationData(searchLocation, isSeeMore, subsidiaryId);
  const { data: documentStatus } = useItemReceiptStatus();
  const { data: userData } = useAuthMe();
  const currentRole = userData?.role == 'vendor'

  const handlePrint = useReactToPrint({
    content: () => modalRef.current,
  });

  useEffect(() => {
    if (isSeeMore) {
      fetchNextPage();
    }
  }, [isSeeMore]);


  useEffect(() => {
    if (modalData && isDownload && isSuccess) {
      downloadPDF(modalData);
    }
  }, [modalData, isDownload, isSuccess]);

  const downloadPDF = async (data: IItemReceiptDetails | undefined) => {
    const blob = await pdf(<ItemReceiptPDF data={data} />).toBlob();
    saveAs(blob, `${modalData?.irNumber}.pdf`);
    mutate({ action: "Downloaded a Item Receipt." });
    setIsDownload(false);
  };
  
  const handleSearchChange = useCallback((value: string | number) => {
    setSearchLocation(value);
  }, []);

  const columns = useMemo<ColumnDef<ItemReceipt>[]>(
    () => [
      {
        accessorKey: "poNumber",
        header: "P.O NO.",
      },
      {
        accessorKey: "vendorInvoiceNumber",
        header: "VENDOR INVOICE NO.",
      },

      {
        accessorKey: "irNumber",
        header: "IR NUMBER",
      },
      {
        id: "vendorName",
        accessorKey: "vendor.name",
        header: "VENDOR NAME",
        cell: ({ row }) => {
          return (
            <div className="truncate w-[200px] overflow-hidden mx-auto">
              {row.original.vendor.name}
            </div>
          );
        },
      },
      {
        accessorKey: "receivedDate",
        header: "RECEIVED DATE",
        cell: ({ row }) => {
          return (
            <div>
              {new Date(row.original.receivedDate).toLocaleDateString()}
            </div>
          );
        },
      },
      {
        accessorKey: "warehouseLocation.name",
        header: "STORE / WAREHOUSE LOCATION",
        cell: ({ row }) => {
          return (
            <div className="max-w-[200px] truncate overflow-hidden mx-auto">
              {row.original.warehouseLocation.name}
            </div>
          );
        },
      },
      {
        accessorKey: "status",
        header: "STATUS",
        cell: ({ row }) => {
          return (
            <div>
              {row.original.status === "approved" ? (
                <span className="text-green-500">{row.original.status}</span>
              ) : (
                <span className="text-red-500">{row.original.status}</span>
              )}
            </div>
          );
        },
      },
      {
        accessorKey: "actions",
        header: "ACTIONS",
        //getting data every row
        cell: ({ row }) => {
          return (
            <div className="flex gap-1">
              <Button
                onClick={() => {
                  getRows(row.original.id);
                }}
                className="w-8 h-8"
                size="icon"
                variant="icon"
              >
                <HiEye size="20" />
              </Button>
              <Button
                className="w-8 h-8"
                variant="icon"
                onClick={() => {
                  setIsOpen(true);
                  setUserId(row.original.id);
                  mutate({ action: "Printed a Item Receipt." });
                  toast.loading("Printing...", { duration: 3000 });
                  setTimeout(handlePrint, 3000);
                }}
                size="icon"
              >
                <AiFillPrinter size="20" />
              </Button>
              <Button
                className="w-8 h-8"
                size="icon"
                variant="icon"
                onClick={() => {
                  setUserId(row.original.id);
                  toast.loading("Downloading PDF...", { duration: 3000 });
                  setIsDownload(true);
                }}
              >
                <FaFileDownload size="20" />
              </Button>
            </div>
          );
        },
      },
    ],
    []
  );

  const getRows = async (id: number) => {
    setUserId(id);
    setIsOpen(true);
  };

  const onSubmit = (values: FormValues) => {
    setFormValue(values);
    toast.success("Filter has been applied");
  };

  const handleClearFilter = () => {
    const initialFormValues = {
      document_status: "",
      ir_number: "",
      po_number: "",
      read_status: "all",
      results: "10",
      vendor_name: "",
      warehouse_location: "",
    };
    form.reset(initialFormValues);
    setFormValue(initialFormValues);
    toast.success("Filter has been cleared");
  };

  const downloadCSV = () => {
    setIsCsvDownload(true);
  };
  const siteName = modalData?.warehouseLocation?.name ?? '';
  const siteAddress = modalData?.warehouseLocation?.address?? '';
  const gsubSiteName = siteName.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const gsubSiteAddress = siteAddress.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const isNameIncludedInAddress = gsubSiteAddress.includes(gsubSiteName);

  return (
    <div className="flex flex-col space-y-4">
      <h1 className="scroll-m-20 text-2xl font-medium tracking-tight mb-2">
        Item Receipt
      </h1>
      <div className="bg-white w-full p-8 rounded-md">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="flex flex-col items-center md:flex-row md:justify-between">
              <p>Current View: Live</p>
              <FormField
                control={form.control}
                name="document_status"
                render={({ field }) => (
                  <FormItem className="flex flex-col w-full md:w-1/4">
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a verified email to display" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {documentStatus?.map((status, index) => (
                          <SelectItem key={index} value={status}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <hr className="my-2" />
            <div className="grid grid-cols-1 gap-4 items-center md:grid-cols-2">
              <FormField
                control={form.control}
                name="ir_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>I.R Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>

                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="receipt_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Receipt Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="receipt_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Receipt Date To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="po_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>P.O Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>

                    <FormMessage />
                  </FormItem>
                )}
              />
              {userData?.role !== "vendor" && (
                <FormField
                  control={form.control}
                  name="vendor_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vendor Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              <FormField
                control={form.control}
                name="warehouse_location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Store Warehouse Location</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            className={cn(
                              "justify-between",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value
                              ? warehouseData?.pages
                                  .flatMap((value) => value.data)
                                  .find(
                                    (item) => String(item.id) === field.value
                                  )?.name
                              : "Select Warehouse"}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-[80vw] md:w-[37vw]">
                        <Command>
                          <CDebouncedInput
                            value={searchLocation ?? ""}
                            onChange={handleSearchChange}
                          />
                          <CommandEmpty>No warehouse found.</CommandEmpty>
                          <CommandGroup className="max-h-[40vh] overflow-y-auto">
                            {warehouseData?.pages.map((pages, index) => (
                              <Fragment key={index}>
                                {pages.data.map((val) => (
                                  <CommandItem
                                    value={`${val.name}`}
                                    key={val.id}
                                    onSelect={() => {
                                      form.setValue(
                                        "warehouse_location",
                                        `${val.id}`
                                      );
                                    }}
                                  >
                                    {val.name}
                                    <HiCheck
                                      className={cn(
                                        "ml-auto h-4 w-4",
                                        String(val.id) === field.value
                                          ? "opacity-100"
                                          : "opacity-0"
                                      )}
                                    />
                                  </CommandItem>
                                ))}
                              </Fragment>
                            ))}
                            <Button
                              variant="icon"
                              disabled={isFetching}
                              onClick={() => setIsSeeMore((prev) => prev + 1)}
                            >
                              {isFetching ? <Spinner /> : "Load more"}
                            </Button>
                          </CommandGroup>
                        </Command>
                      </PopoverContent>
                    </Popover>

                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="delivery_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Delivery Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="delivery_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Delivery Date From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="results"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Results</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="10 per page" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {[10, 25, 50, 100].map((val, index) => (
                          <SelectItem key={index} value={val.toString()}>
                            {val}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="read_status"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Read Status</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={String(field.value)}
                        className="flex flex-row items-center space-x-4"
                      >
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="all" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            All
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="false" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Unread
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="true" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Read
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="flex flex-col md:flex-row md:justify-end gap-2">
              <Button
                className="w-full md:w-1/6"
                type="submit"
                disabled={isLoading}
              >
                Search
              </Button>
              <Button
                className="w-full md:w-1/6"
                variant="outline"
                type="reset"
                disabled={isLoading}
                onClick={handleClearFilter}
              >
                Clear
              </Button>
            </div>
          </form>
        </Form>
      </div>

      <div className="flex flex-col space-y-2">
        <div className="flex justify-between items-center flex-wrap gap-2 ">
          <DebouncedInput
            value={searchText ?? ""}
            onChange={(value) => setSearchText(String(value))}
          />
          <Button
            className="md:w-1/5"
            onClick={downloadCSV}
            disabled={isCsvDownload}
          >
            {isCsvDownload ? <Spinner /> : "Export"}
          </Button>
        </div>
        <DataTable
          columns={columns}
          data={data?.itemReceipts ?? []}
          loading={isLoading}
          displayPagination
          page={page}
          vendorVisibility={userData?.role !== "vendor" ? true : false}
          setPage={setPage}
          total={data?.totalCount}
          textAlign="text-center"
        />

        <Dialog open={isOpen} modal onOpenChange={(val) => setIsOpen(val)}>
          <DialogContent
            className={
              "lg:max-w-screen-lg overflow-y-auto font-mulish max-h-[90%] scrollbar"
            }
          >
            {isFetchingIRDetails && (
                <LoadingScreen details="Item Receipt"/>
              )}
            <div ref={modalRef} className="flex flex-col space-y-2 px-4">
              {subsidiary?.logo && (
                <div className="w-32 h-16 relative">
                  <Image
                    src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${subsidiary?.logo}`}
                    alt={"Logo"}
                    fill
                    objectFit="contain"
                    quality={100}
                    draggable={false}
                  />
                </div>
              )}
              <div className="flex justify-between items-center">
                <p className="font-medium">Item Receipt</p>
                <p className="font-medium">NO: {modalData?.irNumber}</p>
              </div>

              <p>Primary Information</p>
              <div className="flex flex-wrap items-center justify-between">
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-700">P.O Number</p>
                  <p>{modalData?.poNumber}</p>
                </div>

                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-700">
                    Supplier Invoice Reference
                  </p>
                  <p>{modalData?.supplierInvoiceReference}</p>
                </div>
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-700">Received Date</p>
                  <p>
                    {!!modalData?.receivedDate &&
                      new Date(modalData?.receivedDate).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <hr className="border border-blue-700" />
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Site Address</p>
                <p>{isNameIncludedInAddress ? `${siteAddress}` : `${siteName} ${siteAddress}`  }</p>
              </div>
              <div className="flex justify-between items-start">
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-700">P.O Date</p>
                  <p>
                    {!!modalData?.poDate &&
                      new Date(modalData?.poDate).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-700">Vendor Name</p>
                  <p>{modalData?.vendor?.name}</p>
                </div>
              </div>
              <hr className="border border-blue-700" />
              <div className=" flex flex-row items-center pb-2">
                <h1 className=" w-3/6 font-medium text-blue-700">Items</h1>
                <h1 className=" w-1/6 text-center font-medium text-blue-700">
                  Expected Quantity
                </h1>
                <h1 className="w-1/6 text-center font-medium text-blue-700">
                  Delivered Quantity
                </h1>
              </div>
              {modalData?.itemReceiptItems.map((item, index) => (
                <div key={index} className="flex flex-row items-center text-[.80rem]  ">
                  <p className="w-3/6">{item?.item?.name}</p>
                  <p className="w-1/6 pl-[8%]">{item?.expectedQuantity}</p>
                  <p className=" w-1/6 pl-[8%]">{item?.deliveredQuantity}</p>
                </div>
              ))}
              {/* <div className="flex flex-row items-center  py-2 mt-2">
                <p className=" w-3/6 font-medium text-blue-700">TotalQty</p>
                <p className=" w-1/6 pl-[8%] font-medium">
                  {modalData?.totalExpectedQuantity}
                </p>
                <p className=" w-1/6 pl-[8%] font-medium">
                  {modalData?.totalQuantity}
                </p>
              </div> */}

              <hr className="border border-blue-700" />

              <div className="flex">
                <div className="w-full flex flex-col justify-between">
                  <div className="flex flex-col space-y-1">
                    <p className="font-medium text-blue-700">Prepared By:</p>
                    <p>{modalData?.preparedBy}</p>
                  </div>

                  <div className="flex flex-col space-y-1">
                    <p className="font-medium text-blue-700">Approved By:</p>
                    <p>{modalData?.approvedBy}</p>
                  </div>
                </div>
                <div className="w-full flex flex-col justify-between">
                  <div className="flex flex-col space-y-1">
                    <p className="font-medium text-blue-700">Checked By:</p>
                    <p>{modalData?.checkedBy}</p>
                  </div>
                  <div className="flex flex-col space-y-1">
                    <p className="font-medium text-blue-700">Received By:</p>
                    <p>{modalData?.receivedBy}</p>
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button onClick={() => setIsOpen(false)} className="md:w-1/5">
                Ok
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default TabItemReceipts;
