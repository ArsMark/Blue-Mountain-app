import { Button } from "@/components/ui/button";
import { ColumnDef, PaginationState } from "@tanstack/react-table";
import React, { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { DataTable } from "@/components/ui/tables/DataTable";
import { HiCheck, HiEye } from "react-icons/hi";
import bmLogo from "../../public/images/bm_logo.png";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import Image from "next/image";
import VRATermsAndCondition from "@/components/vra-terms-condition";
import VraPDF from "@/components/PDF/VraPDF";
import { useReactToPrint } from "react-to-print";
import { AiFillPrinter } from "react-icons/ai";
import { FaFileDownload } from "react-icons/fa";
import { number, z } from "zod";
import { VRASchema } from "@/schema/VRASchema";
import { zodResolver } from "@hookform/resolvers/zod";
import { IVRADetails, VendorReturnAuthorization } from "@/types/IVRA";
import { useVRADetails, useVRAStatus, useVRATable } from "@/utils/hooks/useVRA";
import toast from "react-hot-toast";
import Spinner from "@/components/ui/spinner";
import DebouncedInput from "@/components/ui/tables/DebounceInput";
import { pdf } from "@react-pdf/renderer";
import { saveAs } from "file-saver";
import { useActionDownload } from "@/utils/hooks/useActionDownload";
import { ScrollArea } from "@/components/ui/scroll-area";
import LoadingScreen from "@/components/ui/loading";
import { useWarehouseLocationData } from "@/utils/hooks/useWarehouseLocation";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@/components/ui/command";
import CDebouncedInput from "@/components/ui/CommandInput";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, ChevronsUpDown } from "lucide-react";
import { format } from "date-fns";
import { getCookie } from "cookies-next";
import { useSubsidiaryDetails } from "@/utils/hooks/useSubsidiary";
import { useAuthMe } from "@/utils/hooks/useAuth";
import Unauthorized from "@/components/ui/unauthorized";

export type FormValues = z.infer<typeof VRASchema>;

const VendorReturnAuthorizations = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userId, setUserId] = useState(0);
  const [isSeeMore, setIsSeeMore] = useState(1);
  const [searchText, setSearchText] = useState("");
  const [isDownload, setIsDownload] = useState(false);
  const [isCsvDownload, setIsCsvDownload] = useState(false);
  const [searchLocation, setSearchLocation] = useState<string | number>("");
  const [formValue, setFormValue] = useState<FormValues>({
    document_status: "",
    pullout_date_from: undefined,
    pullout_date_to: undefined,
    quantity: "",
    read_status: "all",
    results: "10",
    total_amount: "",
    vendor_name: "",
    vra_number: "",
    warehouse_location: "",
  });
  const [page, setPage] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: Number(formValue.results),
  });

  const subsidiaryId = getCookie("subsidiaryId");
  const { data: subsidiary } = useSubsidiaryDetails(subsidiaryId);

  useEffect(() => {
    if (formValue || searchText) {
      setPage({
        pageIndex: 0,
        pageSize: Number(formValue.results),
      });
    }
  }, [formValue, searchText]);

  const pagination = useMemo(() => {
    return {
      pageIndex: page.pageIndex,
      pageSize: Number(formValue.results),
    };
  }, [page, formValue]);
  const form = useForm<FormValues>({
    resolver: zodResolver(VRASchema),
    defaultValues: {
      document_status: "",
      pullout_date_from: undefined,
      pullout_date_to: undefined,
      quantity: "",
      read_status: "all",
      results: "10",
      total_amount: "",
      vendor_name: "",
      vra_number: "",
      warehouse_location: "",
    },
  });

  const modalRef = useRef<HTMLDivElement>(null);
  const divRef = useRef<HTMLDivElement>(null);
  const { data, isLoading, refetch } = useVRATable(
    formValue,
    pagination,
    searchText,
    isCsvDownload,
    setIsCsvDownload
  );
  const { data: vraData, isSuccess, isLoading: isFetchingVRADetails } = useVRADetails(userId);
  const { mutate } = useActionDownload();
  const {
    data: warehouseData,
    isFetching,
    fetchNextPage,
  } = useWarehouseLocationData(searchLocation, isSeeMore, subsidiaryId);
  const { data: documentStatus } = useVRAStatus();
  const { data: userData } = useAuthMe();
  const currentRole = userData?.role == 'vendor'
  const handlePrint = useReactToPrint({
    content: () => modalRef.current,
  });

  useEffect(() => {
    if (isSeeMore) {
      fetchNextPage();
    }
  }, [isSeeMore]);

  useEffect(() => {
    if (isSuccess) {
      refetch();
    }
  }, [isSuccess]);

  useEffect(() => {
    if (vraData && isDownload && isSuccess) {
      downloadPDF(vraData);
    }
  }, [vraData, isDownload, isSuccess]);

  const downloadPDF = async (data: IVRADetails) => {
    const blob = await pdf(<VraPDF data={data} />).toBlob();
    saveAs(blob, `${vraData?.vraNumber}.pdf`);
    mutate({ action: "Downloaded a VRA." });
    setIsDownload(false);
  };

  const columns: ColumnDef<VendorReturnAuthorization>[] = [
    {
      accessorKey: "vraNumber",
      header: "VRA #",
    },
    {
      id: "vendorName",
      accessorKey: "vendor.name",
      header: "VENDOR NAME",
      cell: ({ row }) => {
        return (
          <div className="max-w-[150px] truncate overflow-hidden">
            {row.original.vendor.name}
          </div>
        );
      },
    },
    {
      accessorKey: "warehouseLocation.name",
      header: "LOCATION / WAREHOUSE",
      cell: ({ row }) => {
        return (
          <div className="max-w-[200px] truncate overflow-hidden">
            {row.original.warehouseLocation.name}
          </div>
        );
      },
    },
    {
      accessorKey: "pullOutDate",
      header: "DEADLINE FOR PULL OUT",
      cell: ({ row }) => {
        if (!row.original.pullOutDate) return;
        return (
          <div>{new Date(row.original.pullOutDate).toLocaleDateString()}</div>
        );
      },
    },
    {
      accessorKey: "quantity",
      header: "QUANTITY",
    },
    {
      accessorKey: "totalAmount",
      header: "TOTAL AMOUNT",
      cell: ({ row }) => {
        return (
          <div>
            {Number(row.original.totalAmount).toLocaleString("en-US", {
              style: "currency",
              currency: "PHP",
            })}
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "READ STATUS",
      cell: ({ row }) => {
        return (
          <div>
            {row.original.isRead ? (
              <span className="text-green-500">Read</span>
            ) : (
              <span className="text-red-500">Unread</span>
            )}
          </div>
        );
      },
    },
    {
      accessorKey: "vraStatus",
      header: "VRA STATUS",
    },
    {
      accessorKey: "actions",
      header: "ACTIONS",
      //getting data every row
      cell: ({ row }) => {
        return (
          <div className="flex gap-1 justify-center">
            <Button
              onClick={() => {
                getRows(row.original.id);
              }}
              className="w-8 h-8"
              size="icon"
              variant="icon"
            >
              <HiEye size="20" />
            </Button>
            <Button
              className="w-8 h-8"
              variant="icon"
              onClick={() => {
                setIsOpen(true);
                setUserId(row.original.id);
                mutate({ action: "Printed a VRA." });
                toast.loading("Printing...", { duration: 3000 });
                setTimeout(handlePrint, 3000);
              }}
              size="icon"
            >
              <AiFillPrinter size="20" />
            </Button>

            <Button
              size="icon"
              className="w-8 h-8"
              variant="icon"
              onClick={() => {
                setUserId(row.original.id);
                toast.loading("Downloading PDF...", { duration: 3000 });
                setIsDownload(true);
              }}
            >
              <FaFileDownload size="20" />
            </Button>
          </div>
        );
      },
    },
  ];

  const getRows = async (id: number) => {
    setUserId(id);
    setIsOpen(true);
  };

  const onSubmit = (values: FormValues) => {
    setFormValue(values);
    toast.success("Filter has been applied");
  };

  const handleClearFilter = () => {
    const initialValues = {
      document_status: "",
      quantity: "",
      read_status: "all",
      results: "10",
      total_amount: "",
      vendor_name: "",
      vra_number: "",
      warehouse_location: "",
    };
    form.reset(initialValues);
    setFormValue(initialValues);
    toast.success("Filter has been cleared");
  };

  const downloadCSV = () => {
    setIsCsvDownload(true);
  };

  if (userData?.role !== 'admin-accounting' && userData?.role !== 'vendor' && userData?.role !== 'accounting' && userData?.role !== 'admin' && userData?.role !== 'purchasing') {
    return <Unauthorized />
  }

  const length = vraData?.vendorReturnAutorizationItems.length ?? 0;
  const siteName = vraData?.warehouseLocation?.name ?? '';
  const siteAddress = vraData?.warehouseLocation?.address?? '';
  const gsubSiteName = siteName.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const gsubSiteAddress = siteAddress.replace(/[^a-zA-Z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  const isNameIncludedInAddress = gsubSiteAddress.includes(gsubSiteName);
  const ttd = vraData?.totalTradeDiscount ?? 0;

  return (
    <div className="flex flex-col space-y-4">
      <h1 className="scroll-m-20 text-2xl font-medium tracking-tight mb-2">
        Vendor Return Authorization
      </h1>
      <div className="bg-white w-full p-8 rounded-md">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="flex flex-col md:flex-row md:justify-between">
              <p>Current View: Live</p>
              <FormField
                control={form.control}
                name="document_status"
                render={({ field }) => (
                  <FormItem className="flex flex-col md:w-1/4">
                    <FormLabel>VRA Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {documentStatus?.map((status, index) => (
                          <SelectItem value={status} key={index}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <hr className="my-2" />
            <div className="grid grid-cols-1 gap-4 items-center md:grid-cols-2">
              <FormField
                control={form.control}
                name="vra_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>VRA Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex flex-col gap-2 items-center w-full md:flex-row">
                <FormField
                  control={form.control}
                  name="pullout_date_from"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Deadline for Pull Out From</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pullout_date_to"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Deadline for Pull Out To</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            isVendor={currentRole}
                          />
                        </PopoverContent>
                      </Popover>

                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              {userData?.role !== "vendor" && (
                <FormField
                  control={form.control}
                  name="vendor_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vendor Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="warehouse_location"
                render={({ field }) => (
                  <FormItem className="w-full">
                    <FormLabel>Store Warehouse Location</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            role="combobox"
                            className={cn(
                              "justify-between",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value
                              ? warehouseData?.pages
                                  .flatMap((value) => value.data)
                                  .find(
                                    (item) => String(item.id) === field.value
                                  )?.name
                              : "Select Warehouse"}

                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-[80vw] md:w-[37vw]">
                        <Command>
                          <CDebouncedInput
                            value={searchLocation ?? ""}
                            onChange={(val) => setSearchLocation(val)}
                          />
                          <CommandEmpty>No warehouse found.</CommandEmpty>
                          <CommandGroup className="max-h-[40vh] overflow-y-auto">
                            {warehouseData?.pages.map((pages, index) => (
                              <Fragment key={index}>
                                {pages.data.map((val) => (
                                  <CommandItem
                                    value={`${val.name}`}
                                    key={val.id}
                                    onSelect={() => {
                                      form.setValue(
                                        "warehouse_location",
                                        `${val.id}`
                                      );
                                    }}
                                  >
                                    {val.name}
                                    <HiCheck
                                      className={cn(
                                        "ml-auto h-4 w-4",
                                        String(val.id) === field.value
                                          ? "opacity-100"
                                          : "opacity-0"
                                      )}
                                    />
                                  </CommandItem>
                                ))}
                              </Fragment>
                            ))}
                            <Button
                              type="button"
                              variant="icon"
                              disabled={isFetching}
                              onClick={() => setIsSeeMore((prev) => prev + 1)}
                            >
                              {isFetching ? <Spinner /> : "Load more"}
                            </Button>
                          </CommandGroup>
                        </Command>
                      </PopoverContent>
                    </Popover>

                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="total_amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Amount</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>

                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="results"
                defaultValue="10"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Results</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="10 per page" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {[10, 25, 50, 100].map((val, index) => (
                          <SelectItem key={index} value={val.toString()}>
                            {val}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="read_status"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Read Status</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="flex flex-row items-center space-x-4"
                      >
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="all" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            All
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="false" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Unread
                          </FormLabel>
                        </FormItem>
                        <FormItem className="space-x-2">
                          <FormControl>
                            <RadioGroupItem value="true" />
                          </FormControl>
                          <FormLabel className="font-normal text-black">
                            Read
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="flex flex-col md:flex-row md:justify-end gap-2">
              <Button
                className="w-full md:w-1/6"
                type="submit"
                disabled={isLoading}
              >
                Search
              </Button>
              <Button
                className="w-full md:w-1/6"
                variant="outline"
                type="reset"
                onClick={handleClearFilter}
                disabled={isLoading}
              >
                Clear
              </Button>
            </div>
          </form>
        </Form>
      </div>

      <div className="flex flex-col space-y-2">
        <div className="flex justify-between items-center flex-wrap gap-2 ">
          <DebouncedInput
            value={searchText ?? ""}
            onChange={(value) => setSearchText(String(value))}
          />
          <Button
            className="md:w-1/5"
            onClick={downloadCSV}
            disabled={isCsvDownload}
          >
            {isCsvDownload ? <Spinner /> : "Export"}
          </Button>
        </div>
        <DataTable
          columns={columns}
          data={data?.vendorReturnAuthorizations ?? []}
          setPage={setPage}
          page={page}
          loading={isLoading}
          vendorVisibility={userData?.role !== "vendor" ? true : false}
          displayPagination
          total={data?.totalCount}
          textAlign="text-center"
        />

        <Dialog open={isOpen} modal onOpenChange={(val) => setIsOpen(val)}>
          <DialogContent
            className={
              "lg:max-w-screen-lg overflow-y-auto font-mulish max-h-[90%] scrollbar"
            }
          >
          {isFetchingVRADetails && (
            <LoadingScreen details="Vendor Return Authorization"/>
          )}
            <div ref={modalRef} className="flex flex-col space-y-2 px-4">
              <div className="flex justify-between items-center">
                {subsidiary?.logo && (
                  <div className="w-32 h-16 relative">
                    <Image
                      src={`${process.env.NEXT_PUBLIC_API_URL}/api/images?image=${subsidiary?.logo}`}
                      alt={"Logo"}
                      fill
                      objectFit="contain"
                      quality={100}
                      draggable={false}
                    />
                  </div>
                )}
                <p>Vendor Return Authorization</p>
              </div>

              <div className="flex justify-between">
                <p>Primary Information</p>
                <p>NO: {vraData?.vraNumber}</p>
              </div>
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">SRS No.</p>
                <p>{vraData?.srsNumber}</p>
              </div>

              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Vendor</p>
                <p>{vraData?.vendor.name}</p>
              </div>
              <hr className="border border-blue-500" />
              <div className="flex flex-col space-y-2">
                <p className="font-medium text-blue-500">Site Address</p>
                <p>{isNameIncludedInAddress ? `${siteAddress}` : `${siteName} ${siteAddress}`  }</p>
              </div>
              <div className="flex w-1/2 justify-between">
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-500">Date Created</p>
                  <p>
                    {!!vraData?.fulfillmentDate &&
                      new Date(vraData?.fulfillmentDate).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-500">Deadline for Pull Out</p>
                  <p>
                    {!!vraData?.pullOutDate &&
                      new Date(vraData?.pullOutDate).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <hr className="border border-blue-500" />
              <div
                ref={divRef}
                className={`${
                  length > 5 ? "break-after-page" : "break-before-avoid-page"
                }`}
              >
                <div className="flex flex-row items-center justify-between pb-2">
                  <h1 className="w-1/6  font-medium text-blue-700">Barcode</h1>
                  <h1 className="w-3/6  font-medium text-blue-700">
                    Item Description
                  </h1>
                  <h1 className="w-[12%]  font-medium text-blue-700">
                    Unit Price
                  </h1>
                  <h1 className="w-[12%] font-medium text-blue-700">
                    Quantity
                  </h1>
                  <h1 className="w-1/6 pl-8  font-medium text-blue-700">
                    Gross Amount
                  </h1>
                </div>
                {vraData?.vendorReturnAutorizationItems.map((item, index) => {
                  return (
                    // <div key={index} className="grid grid-cols-5 my-2">
                    //   <p className="text-left">{item.item.barcode}</p>
                    //   <p className="text-left">{item.item.description}</p>
                    //   <p className="text-right">
                    //     {Number(item.grossNet).toLocaleString("en-US", {
                    //       style: "currency",
                    //       currency: "PHP",
                    //     })}
                    //   </p>
                    //   <p className="text-center">{item.quantity}</p>
                    //   <p className="text-right">
                    //     {Number(item.totalAmount).toLocaleString("en-US", {
                    //       style: "currency",
                    //       currency: "PHP",
                    //     })}
                    //   </p>
                    // </div>
                    <div
                      className="flex flex-row items-center justify-between text-[.80rem]  py-2"
                      key={index}
                    >
                      <p className="w-1/6">{item.item.barcode}</p>
                      <p className="w-3/6">{item.item.description}</p>
                      <p className="w-[12%] pl-2">
                        {Number(item?.grossPrice).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                      <p className="w-[12%] pl-6">{item.quantity}</p>
                      <p className="w-1/6 pl-8">
                        {Number(item.totalAmount).toLocaleString("en-US", {
                          style: "currency",
                          currency: "PHP",
                        })}
                      </p>
                    </div>
                  );
                })}
                <hr className="border border-blue-500" />
                <div className="flex justify-between items-center my-2 ">
                  <p>Total Gross Amount</p>
                  <p>
                    {Number(vraData?.grossAmount).toLocaleString("en-US", {
                      style: "currency",
                      currency: "PHP",
                    })}
                  </p>
                </div>
                  {ttd != 0 && (
                    <>
                      <div className="flex items-center justify-between my-2">
                        <p>Total Trade Discount</p>
                        <p className="font-medium">
                          {Number(-ttd).toLocaleString("en-US", {
                            style: "currency",
                            currency: "PHP",
                          })}
                        </p>
                      </div>
                      <hr className="border border-blue-500" />
                    </>
                  )}
                <div className="flex justify-between items-center my-2 ">
                  <p className="font-medium text-blue-500">Total Amount:</p>
                  <p>
                    {Number(vraData?.totalAmount).toLocaleString("en-US", {
                      style: "currency",
                      currency: "PHP",
                    })}
                  </p>
                </div>
              </div>

              <div>
                <VRATermsAndCondition />
              </div>
              <div className="flex justify-between items-center">
                <div className="flex flex-col space-y-2">
                  <p className="font-medium text-blue-500">Prepared By:</p>
                  <p>{vraData?.preparedBy}</p>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button onClick={() => setIsOpen(false)} className="md:w-1/5">
                Ok
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default VendorReturnAuthorizations;
