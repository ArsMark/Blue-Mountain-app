import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export default async function middleware(req: NextRequest) {
  const cookie = req.cookies.get("user");

  const urlLink = [
    "/select",
    "/home",
    "/purchase-order",
    "/item-receipt",
    "/vendor-return-authorization",
    "/item-fulfillment",
    "/bill",
    "payment",
    "debit-credit",
    "/users",
  ];

  for (const url of urlLink) {
    if (!cookie && req.nextUrl.pathname.startsWith(url)) {
      return NextResponse.redirect(new URL("/login", req.url));
    }
  }

  if (cookie && req.nextUrl.pathname.startsWith("/login")) {
    return NextResponse.redirect(new URL("/home", req.url));
  }
}
