User with "developer" role have additional features that can use like managing
the user (create, delete),use seeeders, and many more.

NOTE: DON'T USE THE SEEDERS IN PRODUCTION, OR IF POSSIBLE NOT IN STAGING TOO.
