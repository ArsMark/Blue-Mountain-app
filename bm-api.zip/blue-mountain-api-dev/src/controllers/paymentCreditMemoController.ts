import { PrismaClient } from "@prisma/client";
import logger from "../utils/logger";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const paymentCreditMemoController = {
  getPaymentMemos: async (filter: TFilter) => {
    try {
      const limit = filter.limit || 100;

      const paymentCreditMemos = await prisma.paymentCreditMemo.findMany({
        orderBy: [
          {
            lastModifiedDate: filter.sort || "desc",
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });
      const totalCount = await prisma.paymentCreditMemo.count();

      return { totalCount, paymentCreditMemos };
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getPaymentMemo: async (paymentCreditMemoId: number) => {
    try {
      return await prisma.paymentCreditMemo.findUnique({
        where: {
          id: paymentCreditMemoId,
        },
      });
    } catch (error) {
      throw error;
    }
  },
};

export default paymentCreditMemoController;
