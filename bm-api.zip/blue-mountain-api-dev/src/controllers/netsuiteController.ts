import { PrismaClient, Vendor } from "@prisma/client";
import config from "../utils/config";
import { getVendorData } from "../utils/service/fetchVendorData";
import { getItemData } from "../utils/service/fetchItemData";
import { getSubsidiaryData } from "../utils/service/fetchSubsidiaryData";
import { getPurchaseOrderData } from "../utils/service/fetchPurchaseOrderData";
import { getItemReceiptData } from "../utils/service/fetchItemReceiptData";
import { getLocationData } from "../utils/service/fetchLocationData";
import { getBillingData } from "../utils/service/fetchBillingData";
import { getPaymentData } from "../utils/service/fetchPaymentData";
import { getDebitCreditMemoData } from "../utils/service/fetchDebitCreditMemoData";
import { getJournalEntryData } from "../utils/service/fetchJournalEntry";
import { getVendorReturnAuthorizationData } from "../utils/service/fetchVendorReturnAuthorizationData";
import { getItemFulfillmentData } from "../utils/service/fetchItemFulfillmentData";
import { processData } from "../utils/service/processData";
import fetchData from "../utils/service/fetchData";
import { Request, Response } from "express";
import updateVRA from "../utils/service/netsuiteUpdates/updateVRA";
import updateItemReceipt from "../utils/service/netsuiteUpdates/updateItemReceipt";
import updateItemFulfillment from "../utils/service/netsuiteUpdates/updateItemFulfillment";
import updatePurchaseOrderItem from "../utils/service/netsuiteUpdates/updatePurchaseOrderItem";
import updateDebitCreditMemo from "../utils/service/netsuiteUpdates/updateDebitCreditMemo";
import updateJournalEntry from "../utils/service/netsuiteUpdates/updateJournalEntries";
import updatePayment from "../utils/service/netsuiteUpdates/updatePayment";
import updateBilling from "../utils/service/netsuiteUpdates/updateBilling";
import updateWarehouseLocation from "../utils/service/netsuiteUpdates/updateLocation";
import updateUserVendor from "../utils/service/netsuiteUpdates/updateUserVendor";

import {addJobToQueue} from "../helpers/queue/jobQueue"

const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const netsuiteController = {
  getSubsidiary: async (req: any, res: any) => {
    const response = await getSubsidiaryData();
    res.status(200).send(response);
  },
  getVendor: async (req: any, res: any) => {
    const response = await getVendorData();
    res.status(200).send(response);
  },
  getInventoryItem: async (req: any, res: any) => {
    const response = await getItemData();
    res.status(200).send(response);
  },
  getLocation: async (req: any, res: any) => {
    const response = await getLocationData();
    res.status(200).send(response);
  },
  getPurchaseOrder: async (req: any, res: any) => {
    // await addJobToQueue("pullPurchaseOrderData", {})
    const response = await getPurchaseOrderData();
    return res.status(200).send(response);
  },
  getItemReceiptData: async (req: any, res: any) => {
    const response = await getItemReceiptData();
    res.status(200).send(response);
  },
  getBillingData: async (req: any, res: any) => {
    await addJobToQueue("pullBillingData", {})
   return res.status(200).json({message:"Bill is now fetching"});
  },
  getPaymentData: async (req: any, res: any) => {
    await addJobToQueue("pullPaymentData", {})
    return res.status(200).json({message:"Payment is now fetching"});
    
  },
  getVendorReturnAuthorization: async (req: any, res: any) => {
    const response = await getVendorReturnAuthorizationData();
    res.status(200).send(response);
  },
  getCreditMemo: async (req: any, res: any) => {
    const response = await getDebitCreditMemoData();
    res.status(200).send(response);
  },
  getJournalEntry: async (req: any, res: any) => {
    const response = await getJournalEntryData();
    res.status(200).send(response);
  },
  getItemFulfillmentData: async (req: any, res: any) => {
    const response = await getItemFulfillmentData();
    res.status(200).send(response);
  },

  processAllTable: async (req: any, res: any) => {
    processData();
    res.status(200).send(true);
  },

  getUpdateVRA: updateVRA,
  getUpdateItemReceipt: updateItemReceipt,
  getUpdateItemFulfillment: updateItemFulfillment,
  getUpdatePurchaseOrderItem: updatePurchaseOrderItem,
  getUpdateDebitCredit: updateDebitCreditMemo,
  getupdateWarehouseLocation: updateWarehouseLocation,
  getUpdatePayment: updatePayment,
  getupdateBilling: updateBilling,
  getupdateUserVendor: updateUserVendor,
  getupdateJournalEntry: updateJournalEntry
  
  
};

export default netsuiteController;
