import { faker } from "@faker-js/faker";
import { PrismaClient, PurchaseOrderItem } from "@prisma/client";
import logger from "../utils/logger";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const purchaseOrderItemController = {
  getPurchaseOrderItems: async (
    filter: TFilter &
      Partial<
        PurchaseOrderItem & {
          deliveryDateRange: string;
          poDateRange: string;
          vendorName: string;
        }
      >
  ) => {
    try {
      const limit = filter.limit || 100;

      const purchaseOrderItems = await prisma.purchaseOrderItem.findMany({
        where: {
          barcode: filter.barcode,
          description: filter.description,
          quantity: filter.quantity ? +filter.quantity : undefined,
          cost: filter.cost ? +filter.cost : undefined,
          amount: filter.amount ? +filter.amount : undefined,
          subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        },
        include: {
          item: true,
          subsidiary: true,
        },
        orderBy: [
          {
            lastModifiedDate: filter.sort || "desc",
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });
      const totalCount = await prisma.purchaseOrderItem.count();

      return { totalCount, purchaseOrderItems };
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getPurchaseOrderItem: async (purchaseOrderItemId: number) => {
    return await prisma.purchaseOrderItem.findUnique({
      where: {
        id: purchaseOrderItemId,
      },
      include: {
        subsidiary: true,
        item: true,
      },
    });
  },
  seedPurchaseOrderItems: async () => {
    try {
      const purchaseOrderItems = [...Array(100)].map((_, index) => ({
        id: index + 1,
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        itemId: index + 1,
        barcode: faker.string.numeric({ length: 12 }),
        description: faker.commerce.productDescription(),
        quantity: Math.floor(Math.random() * 1000) + 101,
        cost: +faker.commerce.price(),
        amount: +faker.commerce.price() * 2,
        purchaseOrderId: Math.floor(Math.random() * 100) + 1,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.purchaseOrderItem.deleteMany();
      return await prisma.purchaseOrderItem.createMany({
        data: purchaseOrderItems,
      });
    } catch (error) {
      logger(error);
      return error;
    }
  },
};

export default purchaseOrderItemController;
