import { Notification, PrismaClient, User } from "@prisma/client";
import { TFilter } from "../utils/validations/filterValidation";
import { faker } from "@faker-js/faker";
import { notificationTypes } from "../data/notificationTypes";

const prisma = new PrismaClient();

const notificationController = {
  getNotifications: async (
    filter: TFilter &
      Partial<
        Notification & {
          user: User;
        }
      >
  ) => {
    try {
      const limit = filter.limit || 100;
      const isVendor = filter.user?.role === "vendor";

      const notifications = await prisma.notification.findMany({
        where: {
          vendorId: isVendor ? +`${filter.user?.vendorId}` : undefined,
          subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        },
        orderBy: [
          {
            createdAt: filter.sort || "desc",
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });
      const totalCount = await prisma.notification.count({
        where: {
          subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        },
      });

      return { totalCount, notifications };
    } catch (error) {
      throw error;
    }
  },

  addNotification: async (
    notification: Pick<
      Notification,
      "title" | "description" | "subsidiaryId"
    > & {
      type: notificationTypes;
    }
  ) => {
    try {
      return await prisma.notification.create({
        data: notification,
      });
    } catch (error) {
      throw error;
    }
  },
  seedNotifications: async () => {
    try {
      const notifications = [...Array(100)].map((_, index) => ({
        id: index + 1,
        title: faker.lorem.words({ min: 1, max: 5 }),
        description: faker.lorem.sentence(),
        type: Object.values(notificationTypes)[Math.floor(Math.random() * 7)],
        subsidiaryId: +(Math.floor(Math.random() * 5) % 2 === 0) + 1,
      }));

      await prisma.notification.deleteMany();
      return await prisma.notification.createMany({ data: notifications });
    } catch (error) {
      throw error;
    }
  },
};

export default notificationController;
