import { PrismaClient, VendorReturnAuthorizationItem } from "@prisma/client";
import logger from "../utils/logger";
import { TFilter } from "../utils/validations/filterValidation";
import { faker } from "@faker-js/faker";

const prisma = new PrismaClient();

const vendorReturnAuthorizationItemController = {
  getVendorReturnAuthorizationItems: async (
    filter: TFilter & Partial<Omit<VendorReturnAuthorizationItem, "isRead">>
  ) => {
    try {
      const limit = filter.limit || 100;

      const vendorReturnAuthorizationItems =
        await prisma.vendorReturnAuthorizationItem.findMany({
          where: {
            subsidiaryId: filter.subsidiaryId,
            grossNet: filter.grossNet ? +filter.grossNet : undefined,
            totalAmount: filter.totalAmount ? +filter.totalAmount : undefined,
            quantity: filter.quantity ? +filter.quantity : undefined,
          },
          include: {
            subsidiary: true,
            item: true,
          },
          orderBy: [
            {
              lastModifiedDate: filter.sort || "desc",
            },
          ],
          skip: filter.page ? limit * (filter.page - 1) : 0,
          take: +limit,
        });

      const totalCount = await prisma.vendorReturnAuthorizationItem.count();

      return { totalCount, vendorReturnAuthorizationItems };
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getVendorReturnAuthorizationItem: async (
    vendorReturnAuthorizationItemID: number
  ) => {
    return await prisma.vendorReturnAuthorizationItem.findUnique({
      where: {
        id: vendorReturnAuthorizationItemID,
      },
      include: {
        subsidiary: true,
        item: true,
      },
    });
  },

  seedVendorReturnAuthorizationItems: async () => {
    try {
      const vendorReturnAuthorizationItems = [...Array(100)].map(
        (_, index) => ({
          id: index + 1,
          grossNet: Math.floor(Math.random() * 100) + 1,
          totalAmount: Math.floor(Math.random() * 100) + 1,
          subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
          quantity: Math.floor(Math.random() * 5) * index + 1,
          itemId: Math.floor(Math.random() * 100) + 1,
          vendorReturnAuthorizationId: Math.floor(Math.random() * 100) + 1,
          lastModifiedDate: faker.date.between({
            from: new Date("2022-01-01"),
            to: new Date("2023-12-31"),
          }),
        })
      );

      await prisma.vendorReturnAuthorizationItem.deleteMany();
      return await prisma.vendorReturnAuthorizationItem.createMany({
        data: vendorReturnAuthorizationItems,
      });
    } catch (error) {
      logger(error);
      return error;
    }
  },
};

export default vendorReturnAuthorizationItemController;
