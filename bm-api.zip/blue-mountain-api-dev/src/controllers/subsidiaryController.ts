import { PrismaClient, Prisma, Subsidiary } from "@prisma/client";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const subsidiaryController = {
  getSubsidiaries: async (filter: TFilter) => {
    try {
      const q = filter.q;
      const limit = filter.limit || 100;

      const condition: Prisma.SubsidiaryWhereInput = {
        name: {
          contains: q,
        },
        netsuiteId: {
          not: 1,
        },
      };

      const subsidiaries = await prisma.subsidiary.findMany({
        where: condition,
        orderBy: [
          {
            id: filter.sort,
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });
      const totalCount = await prisma.subsidiary.count({ where: condition });

      return { totalCount, subsidiaries };
    } catch (error) {
      return error;
    }
  },
  getSubsidiary: async (subsidiaryId: number) => {
    return await prisma.subsidiary.findUnique({
      where: {
        id: subsidiaryId,
      },
    });
  },
  seedSubsidiaries: async () => {
    try {
      const subsidiaries: Omit<Subsidiary, "createdAt" | "updatedAt">[] = [
        {
          id: 1,
          name: "Blue Mountain",
          netsuiteId: 2,
          logo: "/subsidiaries/bluemountain-logo.png",
          lastModifiedDate: new Date(Date.now()),
        },
        {
          id: 2,
          name: "Barrelman",
          netsuiteId: 3,
          logo: "/subsidiaries/barrelman-logo.png",
          lastModifiedDate: new Date(Date.now()),
        },
      ];

      await prisma.subsidiary.deleteMany();
      return await prisma.subsidiary.createMany({ data: subsidiaries });
    } catch (error) {
      return error;
    }
  },
};

export default subsidiaryController;
