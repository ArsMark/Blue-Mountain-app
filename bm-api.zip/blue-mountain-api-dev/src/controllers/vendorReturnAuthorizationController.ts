import { faker } from "@faker-js/faker";
import {
  Prisma,
  PrismaClient,
  User,
  VendorReturnAuthorization,
} from "@prisma/client";
import config from "../utils/config";
import { pastDate } from "../utils/date";
import logger from "../utils/logger";
import { pushReadBy, readByCondition, checkIsRead, getVendorIDs, IsdRead, appendReadBy } from "../utils/prismaCondition";
import {
  TFilter,
  amountFormat,
  numberFormat,
} from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const vendorReturnAuthorizationController = {
  getVendorReturnAuthorizations: async (
    filter: TFilter &
      Partial<
        Omit<VendorReturnAuthorization, "isRead"> & {
          fulfillmentDate: string;
          pullOutDate: string;
          vendorName: string;
          isRead: "true" | "false";
          user: User;
        }
      >
  ) => {
    try {
      const q = filter.q;
      const qNum = numberFormat.test(`${q}`) ? +`${q}` : undefined;
      const qAmount = amountFormat.test(`${q}`)
        ? +`${q?.replace(",", "")}`
        : undefined;
      const isVendor = filter.user?.role === "vendor";

      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });

      const userId = filter.user?.id;
      const parsedId = userId !== undefined ? parseInt(userId.toString()) : undefined;
      var vendorIds = undefined
      
      if (isVendor) {
        vendorIds = await getVendorIDs(parsedId) 
      }
     
      const fulfillmentDateFilter: Prisma.DateTimeFilter = {};

      if (filter.fulfillmentDate) {
        fulfillmentDateFilter.gte = new Date(`${filter.fulfillmentDate.split(",")[0]}T00:00:00Z`);
        fulfillmentDateFilter.lte = new Date(`${filter.fulfillmentDate.split(",")[1]}T23:59:59Z`);
      }
      if (filter.fulfillmentDate && isVendor) {
        fulfillmentDateFilter.gte = pastDate(+config.VENDOR.RESULTS_DAYS_AGO)
        fulfillmentDateFilter.lte = new Date(`${filter.fulfillmentDate.split(",")[1]}T23:59:59Z`);
      }

      if (isVendor) {
        fulfillmentDateFilter.gte = pastDate(+config.VENDOR.RESULTS_DAYS_AGO);
      }

      const condition: Prisma.VendorReturnAuthorizationWhereInput = {
        vendorId: isVendor ? { in: vendorIds } : undefined,
        totalAmount: filter.totalAmount,
        itemFulFillmentNumber: {
          contains: filter.itemFulFillmentNumber,
        },
        documetStatus: {
          contains: filter.documetStatus,
        },
        preparedBy: {
          contains: filter.preparedBy,
        },
        quantity: filter.quantity ? +filter.quantity : undefined,
        vraStatus: {
          contains: filter.vraStatus,
        },
        vraNumber: {
          contains: filter.vraNumber,
        },
        warehouseLocationId: filter.warehouseLocationId ? +filter.warehouseLocationId : undefined,
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        pullOutDate: filter.pullOutDate && {
          gte: new Date(`${filter.pullOutDate.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.pullOutDate.split(",")[1]}T23:59:59Z`),
        },
        fulfillmentDate: Object.keys(fulfillmentDateFilter).length ? fulfillmentDateFilter : undefined,
        vendor: {
          name: {
            contains: filter.vendorName,
          },
        },
        OR: [
          {
            vraNumber: {
              contains: q,
            },
          },
          {
            vendor: {
              name: {
                contains: q,
              },
            },
          },
          {
            warehouseLocation: {
              address: {
                contains: q,
              },
            },
          },
          { quantity: qNum },
          {
            itemFulFillmentNumber: {
              contains: q,
            },
          },
          {
            vraStatus: {
              contains: q,
            },
          },
        ],
        ...readBy,
      };


      const vendorReturnAuthorizations =
        await prisma.vendorReturnAuthorization.findMany({
          where: condition,
          include: {
            vendor: true,
            subsidiary: true,
            warehouseLocation: true,
            vendorReturnAutorizationItems: true,
          },
          orderBy: [
            {
              pullOutDate: filter.sort || "desc",
            },
          ],
          skip:
            filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0,
          take: filter.limit ? +filter.limit : undefined,
        });

      const totalCount = await prisma.vendorReturnAuthorization.count({
        where: condition,
      });

      const data = {
        totalCount,
        vendorReturnAuthorizations: vendorReturnAuthorizations.map(
          ({ readBy, vendorReturnAutorizationItems, ...rest }) => ({
            ...rest,
            isRead: IsdRead(readBy || "", filter.user?.id || 0)
          })
        ),
      };
      return data;
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getVendorReturnAuthorization: async (args: {
    vendorReturnAuthorizationId: number;
    userId: number;
    role: string
  }) => {
    try {
      const vendorReturnAuthorization =
        await prisma.vendorReturnAuthorization.findUnique({
          where: {
            id: args.vendorReturnAuthorizationId,
          },
          select: {
            readBy: true,
          },
        });

      const { readBy, vendorReturnAutorizationItems, ...rest } =
        await prisma.vendorReturnAuthorization.update({
          where: {
            id: args.vendorReturnAuthorizationId,
          },
          data: {
            readBy: appendReadBy({
              readBy: vendorReturnAuthorization?.readBy,
              userId: args.userId,
            }),
          },
          include: {
            subsidiary: true,
            vendor: true,
            warehouseLocation: true,
            vendorReturnAutorizationItems: {
              include: {
                item: true,
              },
            },
          },
        });
        const totalOrigAmount = vendorReturnAutorizationItems.reduce((sum, item) => {
          return sum + +item.totalAmount;
        }, 0).toFixed(2);

        console.log(totalOrigAmount)
        const vendorReturnAuthorizationItemsWithGrossPrice = vendorReturnAutorizationItems.map(item => ({
        ...item,
        grossPrice: item.quantity > 0 ? +item.totalAmount / item.quantity : 0
    }))
      .sort((a, b) => a.item.name.localeCompare(b.item.name));

      const data = {
        ...rest,
        isRead: checkIsRead(readBy),
        totalOrigAmount,
        vendorReturnAutorizationItems: vendorReturnAuthorizationItemsWithGrossPrice,
      };

      return data;
    } catch (error) {
      throw error;
    }
  },
  getVraStatuses: async () => {
    try {
      const vraStatus = await prisma.vendorReturnAuthorization.findMany({
        select: {
          vraStatus: true,
        },
        distinct: ["vraStatus"],
      });

      return vraStatus.map((_) => _.vraStatus);
    } catch (error) {
      throw error;
    }
  },
  seedVendorReturnAuthorizations: async () => {
    try {
      const vendorReturnAuthorizations = [...Array(100)].map((_, index) => ({
        id: index + 1,
        itemFulFillmentNumber: `${faker.date.anytime().getTime()}`,
        totalAmount: faker.commerce.price(),
        preparedBy: faker.person.fullName(),
        srsNumber: `${faker.date.anytime().getTime()}`,
        vraNumber: `${faker.date.anytime().getTime()}`,
        siteLocation: `${faker.location.street()},${faker.location.city()},${faker.location.country()}`,
        documetStatus:
          Math.floor(Math.random() * 5) % 2 === 0 ? "active" : "pending",
        warehouseLocationId: Math.floor(Math.random() * 100) + 1,
        readBy: "",
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        pullOutDate: faker.date.between({
          from: "2023-01-01",
          to: Date.now(),
        }),
        fulfillmentDate: faker.date.between({
          from: Date.now(),
          to: "2024-01-01",
        }),
        vendorId: Math.floor(Math.random() * 100) + 1,
        quantity: Math.floor(Math.random() * 5) * index + 1,
        vraStatus:
          Math.floor(Math.random() * 5) % 2 === 0 ? "approved" : "rejected",
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.vendorReturnAuthorization.deleteMany();
      return await prisma.vendorReturnAuthorization.createMany({
        data: vendorReturnAuthorizations,
      });
    } catch (error) {
      logger(error);
      return error;
    }
  },
};

export default vendorReturnAuthorizationController;
