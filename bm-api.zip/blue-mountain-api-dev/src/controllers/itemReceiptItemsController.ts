import { PrismaClient } from "@prisma/client";
import logger from "../utils/logger";
import { TFilter } from "../utils/validations/filterValidation";
import { faker } from "@faker-js/faker";

const prisma = new PrismaClient();

const itemReceiptItemsController = {
  getItemReceiptItems: async (filter: TFilter) => {
    try {
      const limit = filter.limit || 100;

      const itemReceiptItems = await prisma.itemReceiptItems.findMany({
        orderBy: [
          {
            lastModifiedDate: filter.sort || "desc",
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });
      const totalCount = await prisma.itemReceiptItems.count();

      return { totalCount, itemReceiptItems };
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getItemReceiptItem: async (itemReceiptItemId: number) => {
    const receipt =  await prisma.itemReceiptItems.findUnique({
      where: {
        id: itemReceiptItemId,
      },
      include: {
        item: true,
        itemReceipt: true,

      },
    });

    console.log(receipt)

    
    return receipt
  },
  seedItemReceiptItems: async () => {
    try {
      const itemReceiptItems = [...Array(100)].map((_, index) => ({
        id: index + 1,
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        expectedQuantity: (Math.floor(Math.random() * 5) + 1) * index + 1,
        deliveredQuantity: (Math.floor(Math.random() * 5) + 1) * index + 1,
        itemId: Math.floor(Math.random() * 100) + 1,
        itemReceiptId: Math.floor(Math.random() * 100) + 1,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.itemReceiptItems.deleteMany();
      return await prisma.itemReceiptItems.createMany({
        data: itemReceiptItems,
      });
    } catch (error) {
      logger(error);
      return error;
    }
  },
};

export default itemReceiptItemsController;
