import { PrismaClient, User } from "@prisma/client";
import config from "../utils/config";
import { pastDate } from "../utils/date";
import { readByCondition, getVendorIDs } from "../utils/prismaCondition";
import { equal } from "joi";

const prisma = new PrismaClient();

const moduleController = {
  getModuleCounts: async (filter: {
    isRead?: "true" | "false";
    subsidiaryId: number;
    user?: User;
  }) => {
    try {
      const isVendor = filter.user?.role === "vendor";
      const userId = filter.user?.id;
      const parsedId = userId !== undefined ? parseInt(userId.toString()) : undefined;
      let invalid_entity = undefined
      var vendorIds = undefined
      if (isVendor) {
        vendorIds = await getVendorIDs(parsedId)
        const entities = await prisma.warehouseLocation.findMany({
          where: {
            name: {
              contains: 'hilltop',
            },
          },
          select: {
            id: true,
          },
          distinct: ['id'],
          
        });
        invalid_entity = entities.map(entity => entity.id) 
      }

      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });

      const debitCreditCondition = (postingType: string) => {
        const  subsidiaryId  =  +filter.subsidiaryId
        const vendorId = isVendor ? +`${filter.user?.vendorId}` : undefined
        const lastModifiedDate = isVendor ? { gte: pastDate(+config.VENDOR.RESULTS_DAYS_AGO) } : undefined;
      
        return {
          vendorId,
          subsidiaryId: +subsidiaryId,
          postingType,
          lastModifiedDate,
          ...readBy,
        };
      };
      const vendorStatus = ['Approved']
      
      const billing_condition = {
          vendorId: isVendor ? { in: vendorIds } : undefined,
          cbrStatus: isVendor ? { in: vendorStatus } : undefined,
          subsidiaryId: +filter.subsidiaryId,
          lastModifiedDate: {
            gte: isVendor ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO) : undefined,
          },
          warehouseLocationId: {notIn: invalid_entity},
          readBy: null
          // ...readBy,
      };

      // console.log(billing_condition)
      const whereCondition = {
        vendorId: isVendor ? { in: vendorIds } : undefined,
        subsidiaryId: +filter.subsidiaryId,
        lastModifiedDate: {
          gte: isVendor ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO) : undefined,
        },
        ...readBy
      };

      const moduleCounts = await prisma.$transaction(async () => {
        const purchaseOrders = await prisma.purchaseOrder.count({
          where: whereCondition,
        });
        const itemReceipts = await prisma.itemReceipt.count({
          where: whereCondition,
        });
        const vendorReturnAuthorizations =
          await prisma.vendorReturnAuthorization.count({
            where: whereCondition,
         });
        const itemFulfillments = await prisma.itemFulfillment.count({
          where: whereCondition,
        });
        const billings = await prisma.billing.count({
          where: billing_condition,
        });
       
        const payments = await prisma.payment.count({
          where: whereCondition,
        });
        const debitCreditMemos = await prisma.debitCreditMemo.count({
          where: debitCreditCondition('Debit Memo'),
        });
        const creditMemos = await prisma.debitCreditMemo.count({
          where: debitCreditCondition('Credit Memo'),
        });

        return {
          purchaseOrders,
          itemReceipts,
          vendorReturnAuthorizations,
          itemFulfillments,
          billings,
          payments,
          debitCreditMemos,
          creditMemos
        };
      });

      return moduleCounts;
    } catch (error) {
      throw error;
    }
  },
};

export default moduleController;
