import { Department, PrismaClient } from "@prisma/client";
import departments from "../data/departments";

const prisma = new PrismaClient();

const departmentController = {
  getDepartments: async () => {
    try {
      const departments = await prisma.department.findMany();
      const totalCount = await prisma.department.count();

      return { totalCount, departments };
    } catch (error) {
      throw error;
    }
  },
  getDepartment: async (departmentId: number) => {
    return await prisma.department.findUnique({
      where: {
        id: +departmentId,
      },
    });
  },
  addDepartment: async (department: Pick<Department, "email" | "name">) => {
    return await prisma.department.create({ data: department });
  },
  seedDepartments: async () => {
    try {
      await prisma.department.deleteMany();
      return await prisma.department.createMany({ data: departments });
    } catch (error) {
      throw error;
    }
  },
};

export default departmentController;
