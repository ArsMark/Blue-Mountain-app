import { faker } from "@faker-js/faker";
import { ItemFulfillmentItem, PrismaClient } from "@prisma/client";
import logger from "../utils/logger";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const itemFulfillmentItemController = {
  getItemFulfillmentItems: async (
    filter: TFilter & Partial<ItemFulfillmentItem>
  ) => {
    try {
      const limit = filter.limit || 100;

      const itemFulfillmentItems = await prisma.itemFulfillmentItem.findMany({
        where: {
          subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        },
        include: {
          subsidiary: true,
          itemFulfillment: true,
          item: true,
        },
        orderBy: [
          {
            lastModifiedDate: filter.sort || "desc",
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });

      const totalCount = await prisma.itemFulfillmentItem.count();

      return { totalCount, itemFulfillmentItems };
    } catch (error) {
      logger(error);
      return error;
    }
  },
  seedItemFulfillmentItems: async () => {
    try {
      const itemFulfillmentItems = [...Array(100)].map((_, index) => ({
        id: index + 1,
        grossNet: faker.commerce.price(),
        quantity: Math.floor(Math.random() * 10) * index + 1,
        totalAmount: +faker.commerce.price() * 2,
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        itemId: Math.floor(Math.random() * 100) + 1,
        itemFulfillmentId: Math.floor(Math.random() * 100) + 1,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.itemFulfillmentItem.deleteMany();
      return await prisma.itemFulfillmentItem.createMany({
        data: itemFulfillmentItems,
      });
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getItemFulfillmentItem: async (itemFulfillmentItemId: number) => {
    return await prisma.itemFulfillmentItem.findUnique({
      where: {
        id: itemFulfillmentItemId,
      },
      include: {
        subsidiary: true,
        item: true,
        itemFulfillment: true,
      },
    });
  },
};

export default itemFulfillmentItemController;
