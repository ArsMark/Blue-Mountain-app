import { faker } from "@faker-js/faker";
import { Payment, Prisma, PrismaClient, User } from "@prisma/client";

import config from "../utils/config";
import { pastDate } from "../utils/date";
import logger from "../utils/logger";
import { pushReadBy, readByCondition, checkIsRead, getVendorIDs, IsdRead, appendReadBy } from "../utils/prismaCondition";
import {
  TFilter,
  amountFormat,
  numberFormat,
} from "../utils/validations/filterValidation";
import { Decimal } from "@prisma/client/runtime/library";

const prisma = new PrismaClient();
const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const paymentController = {
  getTotalResult: async () => {
    const allResult = await NsApi.request({
      path: "record/v1/vendorPayment",
    });

    return allResult.data.totalResults;
  },
  // getPayments: async (
  //   filter: TFilter &
  //     Partial<
  //       Omit<Payment, "isRead"> & {
  //         dateRange: string;
  //         releaseDateRange: string;
  //         cvDateRange: string;
  //         vendorName: string;
  //         isRead: "true" | "false";
  //         user: User;
  //       }
  //     >
  // ) => {
  //   try {
  //     const offset =
  //       filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0;
  //     const limit = filter?.limit;

  //     const vendorPayments = await NsApi.request({
  //       path: `record/v1/vendorPayment?limit=${limit}&offset=${offset}&q=createdDate after "01/01/2024" AND tranid CONTAIN_NOT "-"`,
  //     })
  //       .then(({ data }: any) => {
  //         return data;
  //       })
  //       .catch(() => {
  //         throw "Something went wrong with Vendor Payments";
  //       });

  //     const vendorPaymentItems = await Promise.all(
  //       await vendorPayments?.items.map(
  //         async ({ id, ...rest }: { id: string }) => {
  //           const resp = await NsApi.request({
  //             path: `record/v1/vendorPayment/${id}`,
  //           })
  //             .then(({ data }: any) => {
  //               return data;
  //             })
  //             .catch(() => {
  //               throw "Something went wrong with Vendor Payment Items";
  //             });

  //           return resp;
  //         }
  //       )
  //     );

  //     const modifiedVendorPaymentItems = vendorPaymentItems.map(
  //       ({ entity, tranDate, tranId, total, id, ...rest }) => {
  //         return {
  //           id,
  //           transactionNo: tranId,
  //           cvNumber: tranId,
  //           cvDate: tranDate ? new Date(tranDate) : "",
  //           amount: total,
  //           releaseDate: tranDate ? new Date(tranDate) : "",
  //           vendor: {
  //             name: entity.refName,
  //             netSuiteId: entity.id,
  //           },
  //         };
  //       }
  //     );

  //     return {
  //       payments: modifiedVendorPaymentItems,
  //       totalCount: vendorPayments.totalResults,
  //     };
  //   } catch (error) {
  //     logger(error);
  //     return error;
  //   }
  // },
  getPayments: async (
    filter: TFilter &
      Partial<
        Omit<Payment, "isRead"> & {
          dateRange: string;
          releaseDateRange: string;
          cvDateRange: string;
          vendorName: string;
          isRead: "true" | "false";
          user: User;
        }
      >
  ) => {
    try {
      const q = filter.q;
      const qNum = numberFormat.test(`${q}`) ? +`${q}` : undefined;
      const qAmount = amountFormat.test(`${q}`)
        ? +`${q?.replace(",", "")}`
        : undefined;
      const isVendor = filter.user?.role === "vendor";
    
      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });

      const userId = filter.user?.id;
      const parsedId = userId !== undefined ? parseInt(userId.toString()) : undefined;
      var vendorIds = undefined
      
      if (isVendor) {
        vendorIds = await getVendorIDs(parsedId) 
      }
      const releaseDateFilter: Prisma.DateTimeFilter = {};

      if (filter.releaseDateRange) {
        releaseDateFilter.gte = new Date(`${filter.releaseDateRange.split(",")[0]}T00:00:00Z`);
        releaseDateFilter.lte = new Date(`${filter.releaseDateRange.split(",")[1]}T23:59:59Z`);
      }

      if (isVendor) {
        releaseDateFilter.lte = new Date();
      }
      const condition: Prisma.PaymentWhereInput = {
        vendorId: isVendor ? { in: vendorIds } : undefined,
        cvNumber: { contains: filter.cvNumber },
        debitMemo: filter.debitMemo ? +filter.debitMemo : undefined,
        creditMemo: filter.creditMemo ? +filter.creditMemo : undefined,
        journal: filter.journal ? +filter.journal : undefined,
        netAmount: filter.netAmount ? +filter.netAmount : undefined,
        totalWithHoldingTax: filter.totalWithHoldingTax
          ? +filter.totalWithHoldingTax
          : undefined,
        transactionNo: { contains: filter.transactionNo },
        amount: filter.amount ? +filter.amount : undefined,
        currency: { contains: filter.currency },
        paymentMethod: { contains: filter.paymentMethod },
        bank: { contains: filter.bank },
        checkNumber: { contains: filter.checkNumber },
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        cvDate: filter.cvDateRange && {
          gte: new Date(`${filter.cvDateRange.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.cvDateRange.split(",")[1]}T23:59:59Z`),
        },
        releaseDate: Object.keys(releaseDateFilter).length ? releaseDateFilter : undefined,
        vendor: {
          name: {
            contains: filter.vendorName,
          },
        },
        date: {
          gte: isVendor ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO) : undefined,
        },
        OR: [
          {
            transactionNo: {
              contains: q,
            },
          },
          {
            vendor: {
              name: {
                contains: q,
              },
            },
          },
          { amount: qAmount },
        ],
        ...readBy,
      };
      const payments = await prisma.payment.findMany({
        where: {
          ...condition,
          paymentInvoices: {
            some: {
              type: {
                not: isVendor ? "journal" : undefined,
              },
            },
          },
        },
        include: {
          vendor: true,
          subsidiary: true,
          paymentInvoices: true, // Include paymentInvoices in the result
        },
        orderBy: [
          {
            date: filter.sort || "desc",
          },
        ],
        skip:
          filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0,
        take: filter.limit ? +filter.limit : undefined,
      });
      

      const totalCount = await prisma.payment.count({ where: condition });

      const data = {
        totalCount,
        payments: payments.map(({ readBy, ...rest }) => ({
          ...rest,
          isRead: IsdRead(readBy || "", filter.user?.id || 0),
        })),
      };

      return data;
    } catch (error) {
      logger(error);
      return error;
    }
  },
  seedPayments: async () => {
    try {
      const payments = [...Array(100)].map((_, index) => ({
        id: index + 1,
        transactionNo: `${faker.date.past().getTime()}`,
        date: faker.date.between({
          from: new Date("2022-01-01"),
          to: "2023-12-31",
        }),
        amount: faker.commerce.price(),
        releaseDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: "2023-12-31",
        }),
        currency: faker.finance.currencyCode(),
        readBy: "",
        paymentMethod:
          Math.floor(Math.random() * 10) % 2 === 0 ? "DEBIT" : "CREDIT",
        bank: Math.floor(Math.random() * 10) % 2 === 0 ? "BPI" : "BDO",
        checkNumber: `${faker.date.past().getTime()}`,
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        vendorId: +Math.floor(Math.random() * 100) + 1,
        cvDate: faker.date.past(),
        cvNumber: `${faker.date.past().getTime()}`.slice(0, 3),
        debitMemo: faker.commerce.price(),
        creditMemo: faker.commerce.price(),
        journal: faker.commerce.price(),
        netAmount: faker.commerce.price(),
        totalWithHoldingTax: faker.commerce.price(),
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.payment.deleteMany();
      return await prisma.payment.createMany({ data: payments });
    } catch (error) {
      throw error;
    }
  },
  // getPayment: async (args: { paymentId: number; userId: number }) => {
  //   type OrderDoc = { id: string; refName: string };
  //   try {
  //     const vendorPaymentItem = await NsApi.request({
  //       path: `record/v1/vendorPayment/${args.paymentId}?expandSubResources=true&expand=account`,
  //     }).then(({ data }: any) => {
  //       return data;
  //     });

  //     const {
  //       entity,
  //       tranDate,
  //       tranId,
  //       total,
  //       createdDate,
  //       currency,
  //       id,
  //       custbody_check_checknumber,
  //       lastModifiedDate,
  //       account,
  //       apply: { items: paymentInvoices },
  //     } = vendorPaymentItem;

  //     const vendorBills = await Promise.all(
  //       paymentInvoices.map(
  //         async ({
  //           doc,
  //           links,
  //           ...rest
  //         }: {
  //           doc: {
  //             id: string;
  //             refName: string;
  //           };
  //           type: string;
  //           links: { rel: string; href: string }[];
  //           total: string;
  //         }) => {
  //           let journalEntry;

  //           if (rest.type.toLowerCase() === "journal") {
  //             journalEntry = await NsApi.request({
  //               path: `record/v1/journalEntry/${doc.id}?expandSubResources=true`,
  //             })
  //               .then(({ data }: any) => {
  //                 const summedValues = data.line.items.reduce(
  //                   (acc: any, transaction: any) => {
  //                     if (transaction.debit) {
  //                       acc.debit += transaction.debit;
  //                     }
  //                     if (transaction.credit) {
  //                       acc.credit += transaction.credit;
  //                     }
  //                     return acc;
  //                   },
  //                   { debit: 0, credit: 0 }
  //                 );

  //                 return { ...summedValues };
  //               })
  //               .catch((err: Error) => {
  //                 return null;
  //               });
  //           }

  //           const vendorBill = await NsApi.request({
  //             path: `record/v1/vendorBill/${doc.id}?expandSubResources=true`,
  //           })
  //             .then(async ({ data }: any) => {
  //               return data;
  //             })
  //             .catch((err: Error) => {
  //               return null;
  //             });

  //           return { ...rest, ...vendorBill, memos: journalEntry };
  //         }
  //       )
  //     );

  //     const modifiedVendorBills = await Promise.all(
  //       vendorBills.map(
  //         async ({
  //           type,
  //           custbody_itemreceipt_supplierinvoicer,
  //           total,
  //           refNum,
  //           createdDate,
  //           item,
  //         }) => {
  //           let filteredVendorExpenses;
  //           let totalExpenseWtHoldingTax = 0;
  //           let poNumber;

  //           const availableDocs = item.items
  //             .filter(({ orderDoc }: { orderDoc: OrderDoc }) => orderDoc)
  //             .reduce(
  //               (acc: OrderDoc[], { orderDoc }: { orderDoc: OrderDoc }) => {
  //                 if (!acc.some((doc) => doc.id === orderDoc.id)) {
  //                   acc.push(orderDoc);
  //                 }
  //                 return acc;
  //               },
  //               []
  //             );

  //           if (availableDocs) {
  //             poNumber = await Promise.all(
  //               availableDocs.map(async (doc: OrderDoc) => {
  //                 return await NsApi.request({
  //                   path: `record/v1/purchaseOrder/${doc.id}?fields=tranid`,
  //                 })
  //                   .then(({ data }: any) => {
  //                     return data.tranId;
  //                   })
  //                   .catch((err: Error) => {
  //                     return null;
  //                   });
  //               })
  //             );
  //           }

  //           if (item?.items) {
  //             filteredVendorExpenses = item.items?.filter(
  //               ({ itemType }: any) => {
  //                 if (itemType.id.toLowerCase() === "discount") {
  //                   return true;
  //                 }
  //               }
  //             );

  //             totalExpenseWtHoldingTax = filteredVendorExpenses?.reduce(
  //               (sum: any, expense: any) => sum + expense?.amount,
  //               0
  //             );
  //           }

  //           return {
  //             billing: {
  //               billingNumber: tranId,
  //               supplierInvoiceReference: custbody_itemreceipt_supplierinvoicer,
  //               poNumber,
  //               withHoldingTax: totalExpenseWtHoldingTax,
  //             },
  //             item,
  //             type,
  //             refNum,
  //             applyDate: createdDate,
  //             paymentAmount: total,
  //           };
  //         }
  //       )
  //     );

  //     const journalEntry = vendorBills.find(({ memos }) => memos);

  //     const totalWithHoldingTax = modifiedVendorBills?.reduce(
  //       (sum, bill) => sum + bill.billing.withHoldingTax,
  //       0
  //     );

  //     const totalOrigAmount = modifiedVendorBills?.reduce(
  //       (sum, bill) => sum + bill.paymentAmount,
  //       0
  //     );

  //     const modifiedVendorPaymentItem = {
  //       transactionNo: tranId,
  //       cvNumber: tranId,
  //       cvDate: tranDate ? new Date(tranDate) : "",
  //       debitMemo: journalEntry ? journalEntry.memos.debit : 0,
  //       creditMemo: journalEntry ? journalEntry.memos.debit : 0,
  //       journal: journalEntry ? journalEntry.amount : 0,
  //       netAmount: journalEntry ? journalEntry.amount : 0,
  //       date: tranDate ? new Date(tranDate) : "",
  //       createdAt: createdDate ? new Date(createdDate) : "",
  //       releaseDate: tranDate ? new Date(tranDate) : "",
  //       currency: currency?.refName,
  //       netsuiteId: parseInt(id),
  //       amount: total,
  //       checkNumber: custbody_check_checknumber,
  //       lastModifiedDate: lastModifiedDate ? new Date(lastModifiedDate) : "",
  //       totalWithHoldingTax,
  //       totalOrigAmount,
  //       paymentMethod: account?.acctType?.refName,
  //       bank: account?.acctName,
  //       vendor: {
  //         name: entity.refName,
  //         netSuiteId: entity.id,
  //       },
  //       paymentInvoices: modifiedVendorBills,
  //     };

  //     return modifiedVendorPaymentItem;
  //   } catch (error) {
  //     throw error;
  //   }
  // },
  getPayment: async (args: { paymentId: number; userId: number, role: string }) => {
    try {
      const payment = await prisma.payment.findUnique({
        where: {
          id: args.paymentId,
        },
        select: {
          readBy: true,
        },
      });


      console.log("CHECKKKK")
      const { readBy, ...rest } = await prisma.payment.update({
        where: {
          id: args.paymentId,
        },
        data: {
          readBy: appendReadBy({
            readBy: payment?.readBy,
            userId: args.userId,
          }),
        },
        include: {
          vendor: true,
          subsidiary: true,
          paymentInvoices: {
            where: {
              NOT: {
                OR: [
                  { apply: false },
                  { apply: null }
                ]
              },
            },
            include: {
              billing: true,
            },
          },
        },
      });

      console.log(readBy)
      
      const toNumber = (value: any) => {
        if (value instanceof Decimal) {
          return Math.abs(value.toNumber());
        }
        return Math.abs(value);
      };
      
      const totalOrigAmount = rest.paymentInvoices.reduce((sum, invoice) => {
        const amount = invoice.type == 'Journal' ? invoice.paymentAmount : invoice.billing?.grossAmount
        const billingTotal = toNumber(amount);
        return sum + billingTotal;
      }, 0);
      
      const totalwithHoldingTax = rest.paymentInvoices
        .map(invoice => Math.abs(invoice.billing?.withHoldingTax?.toNumber() ?? 0))
        .reduce((sum, value) => sum + value, 0)
        .toFixed(2);

      const billingIDs = rest.paymentInvoices.map(invoice => invoice.billing?.id).filter((id): id is number => id !== null);
      var totalDeductions = null
      if ( billingIDs.length > 0) {
        totalDeductions = await prisma.debitCreditBill.findMany({
          where: {
            billingId: { in: billingIDs },
          }, include: {
            billing: true,
            debitcreditmemo: true
          },
        });
      }

      const data = {
        ...rest,
        isRead: checkIsRead(readBy),
        totalOrigAmount: totalOrigAmount,
        deductions: totalDeductions,
        totalWithHoldingTax: totalwithHoldingTax
      };
     
      return data;
    } catch (error) {
      throw error;
    }
  },
};

export default paymentController;
