import { faker } from "@faker-js/faker";
import { Item, PrismaClient, User } from "@prisma/client";
import logger from "../utils/logger";
import { pushReadBy, readByCondition } from "../utils/prismaCondition";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const itemController = {
  getItems: async (
    filter: TFilter &
      Partial<Omit<Item, "isRead"> & { isRead: "true" | "false"; user: User }>
  ) => {
    try {
      const limit = filter.limit || 100;

      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });

      const items = await prisma.item.findMany({
        where: {
          name: filter.name,
          barcode: filter.barcode,
          description: filter.description,
          cost: filter.cost ? +filter.cost : undefined,
          subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
          ...readBy,
        },
        include: {
          subsidiary: true,
        },
        orderBy: [
          {
            id: filter.sort,
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });
      const totalCount = await prisma.item.count();

      const data = {
        totalCount,
        items: items.map(({ readBy, ...rest }) => ({
          ...rest,
          isRead: readBy?.includes(`"${filter.user?.id}"`),
        })),
      };

      return data;
    } catch (error) {
      logger(error);
      return error;
    }
  },
  seedItems: async () => {
    try {
      const items = [...Array(100)].map((_, index) => ({
        id: index + 1,
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        barcode: `${faker.date.recent().getTime()}`,
        name: faker.commerce.productName(),
        description: faker.commerce.productDescription(),
        cost: faker.commerce.price(),
        readBy: "",
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.item.deleteMany();
      return await prisma.item.createMany({ data: items });
    } catch (error) {
      throw error;
    }
  },
  getItem: async (args: { itemId: number; userId: number, role: string }) => {
    try {
      const item = await prisma.item.findUnique({
        where: {
          id: args.itemId,
        },
        select: {
          readBy: true,
        },
      });

      const { readBy, ...rest } = await prisma.item.update({
        where: {
          id: args.itemId,
        },
        data: {
          readBy: pushReadBy({
            readBy: item?.readBy,
            userId: args.userId,
            role: args.role
          }),
        },
        include: {
          subsidiary: true,
          itemFulfillmentItems: true,
          vendorReturnAuthorizationItems: true,
          purchaseOrderItems: true,
        },
      });

      const data = {
        ...rest,
        isRead: readBy?.includes(`"${args.userId}"`),
      };

      return data;
    } catch (error) {
      throw error;
    }
  },
};

export default itemController;
