import { faker } from "@faker-js/faker";
import { Billing, Prisma, PrismaClient, User } from "@prisma/client";
import config from "../utils/config";
import { pastDate } from "../utils/date";
import logger from "../utils/logger";
import { pushReadBy, readByCondition, getVendorIDs } from "../utils/prismaCondition";
import { TFilter } from "../utils/validations/filterValidation";
import { Request, Response } from "express";
import { omit } from "lodash";
import vendorController from "./vendorController";
import multer from 'multer';
import xlsx from 'xlsx';
import { Decimal } from 'decimal.js';


const prisma = new PrismaClient();
const vendorStatus = ['Approved']
declare module 'fast-levenshtein' {
  export function get(a: string, b: string): number;
}

import { get as levenshteinDistance } from 'fast-levenshtein';
import { number } from "joi";

// async function createPaymentAndInvoice(billing: { id: number; billingNumber: string; subsidiaryId: number | null }, 
//   vendorId: number, 
//   amount: string,   
//   ewt: string  ) {
//   try {
//     const newPayment = await prisma.payment.create({
//       data: {
//         transactionNo: '',  
//         cvNumber: '',       
//         cvDate: new Date(),
//         debitMemo: 0,
//         creditMemo: 0,
//         journal: 0,
//         netAmount: 0,
//         totalWithHoldingTax: ewt.toString(), 
//         date: new Date(),
//         amount: amount.toString(), 
//         releaseDate: new Date(),
//         currency: '1',
//         paymentMethod: 'Check', 
//         bank: '', 
//         checkNumber: '',
//         vendorId,
//         createdAt: new Date(),
//         updatedAt: new Date(),
//         lastModifiedDate: new Date(), 
//       },
//     });

//     console.log(`Payment record created for billing number ${billing.billingNumber}`);

//     await prisma.paymentInvoice.create({
//       data: {
//         paymentAmount: amount,
//         apply: true,
//         applyDate: new Date(),
//         paymentId: newPayment.id,
//         invoiceId: billing.id,  
//         subsidiaryId: billing.subsidiaryId, 
//         createdAt: new Date(),
//         lastModifiedDate: new Date(),
//       },
//     });

//     console.log(`Payment invoice created for billing number ${billing.billingNumber}`);

//   } catch (error) {
//     console.error('Error creating payment and payment invoice:', error);
//   }
// }
async function createPaymentAndInvoice(
  billings: Array<{ id: number; billingNumber: string; subsidiaryId: number | null; amount: Prisma.Decimal; ewt: Prisma.Decimal; vendorId: number }>,
  totalBillCredit: number // The total amount from all newly created debit credit memos
) {
  try {
    console.log("Starting createPaymentAndInvoice...");

    // Group billings by vendorId
    const billingsByVendor = billings.reduce((acc, billing) => {
      if (!acc[billing.vendorId]) acc[billing.vendorId] = [];
      acc[billing.vendorId].push(billing);
      return acc;
    }, {} as { [vendorId: number]: typeof billings });

    for (const vendorId in billingsByVendor) {
      const vendorBillings = billingsByVendor[vendorId];

      const totalWithHoldingTax = vendorBillings.reduce((sum, billing) => sum + parseFloat(billing.ewt.toString()), 0);
      const totalAmount = vendorBillings.reduce((sum, billing) => sum + parseFloat(billing.amount.toString()), 0);

      // Apply the total bill credit to calculate the adjusted payment amount for each vendor
      const adjustedTotalAmount = new Decimal(totalAmount - totalBillCredit);
      console.log(`Adjusted payment amount for vendorId ${vendorId}:`, adjustedTotalAmount.toString());

      const newPayment = await prisma.payment.create({
        data: {
          transactionNo: '',
          cvNumber: '',
          cvDate: new Date(),
          debitMemo: totalBillCredit,  // Total bill credits applied as debit memo
          creditMemo: 0,
          journal: 0,
          netAmount: adjustedTotalAmount,  // Adjusted amount after total bill credits
          totalWithHoldingTax: new Decimal(totalWithHoldingTax),
          date: new Date(),
          amount: adjustedTotalAmount,
          releaseDate: new Date(),
          currency: '1',
          paymentMethod: 'Check',
          bank: '',
          subsidiaryId: 2,
          checkNumber: '',
          vendorId: parseInt(vendorId),
          createdAt: new Date(),
          updatedAt: new Date(),
          lastModifiedDate: new Date(),
        },
      });
      console.log(`Created Payment for vendorId ${vendorId} with adjusted amount:`, adjustedTotalAmount);

      // Create PaymentInvoice records for each billing entry linked to the payment
      for (const billing of vendorBillings) {
        await prisma.paymentInvoice.create({
          data: {
            paymentAmount: billing.amount,
            apply: true,
            applyDate: new Date(),
            type: "Bill",
            refNum: billing.billingNumber,
            paymentId: newPayment.id,
            invoiceId: billing.id,
            subsidiaryId: billing.subsidiaryId ?? undefined,
            createdAt: new Date(),
            lastModifiedDate: new Date(),
          },
        });
        console.log(`Created PaymentInvoice for billing number ${billing.billingNumber}`);
      }
    }

    console.log("All Payments and associated PaymentInvoices created successfully.");

  } catch (error) {
    console.error("Error in createPaymentAndInvoice:", error);
  }
}





async function updatePaymentAndInvoice(
  billings: Array<{ id: number; billingNumber: string; subsidiaryId: number | null; newAmount: string; newEWT: string }>,
  vendorId: number
) {
  try {
    for (const { id, billingNumber, newAmount, newEWT } of billings) {
      // Step 1: Find the existing billing record by billing number
      const existingBilling = await prisma.billing.findFirst({
        where: { billingNumber },
      });

      if (existingBilling) {
        // Step 2: Update the billing record with new values
        await prisma.billing.update({
          where: { id: existingBilling.id },
          data: {
            total: newAmount,
            ewt: newEWT,
            amount: newAmount,
            grossAmount: new Decimal(newAmount).plus(new Decimal(newEWT)),
            withHoldingTax: newEWT,
          },
        });
        console.log(`Billing updated for billing number ${billingNumber}`);

        // Step 3: Update associated PaymentInvoice
        const existingPaymentInvoice = await prisma.paymentInvoice.findFirst({
          where: { invoiceId: existingBilling.id },
        });

        if (existingPaymentInvoice) {
          await prisma.paymentInvoice.update({
            where: { id: existingPaymentInvoice.id },
            data: {
              paymentAmount: newAmount,
              applyDate: new Date(),
              lastModifiedDate: new Date(),
            },
          });
          console.log(`PaymentInvoice updated for billing number ${billingNumber}`);
        }
      }
    }

    // Step 4: Update the Payment record associated with all the given billings
    const connectedBillingIds = billings.map(billing => billing.id);

    const relatedBillings = await prisma.billing.findMany({
      where: { id: { in: connectedBillingIds } },
      select: {
        amount: true,
        withHoldingTax: true,
        grossAmount: true,
      },
    });

    // Calculate totals
    const totalAmount = relatedBillings.reduce((sum, billing) => sum + parseFloat(billing.amount.toString()), 0);
    const totalWithHoldingTax = relatedBillings.reduce((sum, billing) => sum + parseFloat(billing.withHoldingTax.toString()), 0);
    const totalGrossAmount = relatedBillings.reduce((sum, billing) => sum + parseFloat(billing.grossAmount.toString()), 0);

    // Step 5: Find and update the payment linked to these billings
    const existingPayment = await prisma.payment.findFirst({
      where: {
        vendorId,
        paymentInvoices: { some: { invoiceId: { in: connectedBillingIds } } },
      },
    });

    if (existingPayment) {
      await prisma.payment.update({
        where: { id: existingPayment.id },
        data: {
          totalWithHoldingTax: new Decimal(totalWithHoldingTax),
          amount: new Decimal(totalAmount),
          totalOrigAmount: new Decimal(totalGrossAmount),
          updatedAt: new Date(),
        },
      });
      console.log(`Payment updated with adjusted totals for vendor ${vendorId}`);
    }
  } catch (error) {
    console.error('Error updating payments and invoices:', error);
  }
}







// async function updatePaymentAndInvoice(
//   billings: Array<{ billingNumber: string; newAmount: number; newEWT: number }>
// ) {
//   try {
//     console.log(`Updating multiple billings, invoices, and payments for billingNumbers: ${billings.map(b => b.billingNumber).join(', ')}`);

//     // Step 1: Update each billing record in the array
//     const updatedBillings = [];

//     for (const { billingNumber, newAmount, newEWT } of billings) {
//       const existingBilling = await prisma.billing.findUnique({
//         where: { billingNumber }
//       });

//       if (!existingBilling) {
//         console.warn(`No billing record found for billingNumber: ${billingNumber}`);
//         continue; // Skip to the next billing if not found
//       }

//       // Calculate new values for the billing
//       const newGrossAmount = newAmount + newEWT;

//       // Update the billing record with new values
//       const updatedBilling = await prisma.billing.update({
//         where: { id: existingBilling.id },
//         data: {
//           amount: newAmount,
//           ewt: newEWT,
//           grossAmount: newGrossAmount,
//           total: newAmount,
//         },
//       });

//       console.log(`Updated billing record for billingNumber: ${billingNumber} with amount = ${newAmount}, ewt = ${newEWT}, grossAmount = ${newGrossAmount}`);
//       updatedBillings.push(updatedBilling);
//     }

//     if (updatedBillings.length === 0) {
//       console.log("No billing records were updated.");
//       return;
//     }

//     // Step 2: Update connected PaymentInvoice records for each updated billing
//     for (const billing of updatedBillings) {
//       const paymentInvoices = await prisma.paymentInvoice.findMany({
//         where: { invoiceId: billing.id },
//       });

//       for (const paymentInvoice of paymentInvoices) {
//         await prisma.paymentInvoice.update({
//           where: { id: paymentInvoice.id },
//           data: {
//             paymentAmount: billing.amount,
//             lastModifiedDate: new Date(),
//           },
//         });
//         console.log(`Updated PaymentInvoice ID: ${paymentInvoice.id} for billing number ${billing.billingNumber} with paymentAmount = ${billing.amount}`);
//       }
//     }

//     // Step 3: Update related Payment records
//     const vendorPaymentsMap: { [vendorId: number]: Set<number> } = {};

//     // Group all updated billing IDs by vendor
//     for (const billing of updatedBillings) {
//       if (!vendorPaymentsMap[billing.vendorId]) {
//         vendorPaymentsMap[billing.vendorId] = new Set();
//       }

//       const paymentInvoices = await prisma.paymentInvoice.findMany({
//         where: { invoiceId: billing.id },
//         select: { paymentId: true },
//       });

//       for (const invoice of paymentInvoices) {
//         vendorPaymentsMap[billing.vendorId].add(invoice.paymentId);
//       }
//     }

//     // Update each payment record based on recalculated totals from connected billings
//     for (const [vendorId, paymentIds] of Object.entries(vendorPaymentsMap)) {
//       for (const paymentId of paymentIds) {
//         const connectedInvoices = await prisma.paymentInvoice.findMany({
//           where: { paymentId },
//           select: { invoiceId: true },
//         });

//         const connectedBillingIds = connectedInvoices.map(inv => inv.invoiceId);

//         // Retrieve all connected billing records for recalculation
//         const relatedBillings = await prisma.billing.findMany({
//           where: { id: { in: connectedBillingIds } },
//         });

//         // Recalculate totals for the payment
//         const totalOrigAmount = relatedBillings.reduce((sum, bill) => sum + bill.grossAmount.toNumber(), 0);
//         const totalWithHoldingTax = relatedBillings.reduce((sum, bill) => sum + bill.ewt.toNumber(), 0);
//         const totalAmount = relatedBillings.reduce((sum, bill) => sum + bill.amount.toNumber(), 0);

//         // Sum of all "bill credits" for adjustment
//         const totalBillCredits = relatedBillings
//           .filter(bill => bill.type === 'bill credit')
//           .reduce((sum, bill) => sum + bill.amount.toNumber(), 0);

//         const adjustedPaymentAmount = totalAmount - totalBillCredits;

//         // Update the payment record
//         await prisma.payment.update({
//           where: { id: paymentId },
//           data: {
//             totalWithHoldingTax: new Decimal(totalWithHoldingTax),
//             totalOrigAmount: new Decimal(totalOrigAmount),
//             amount: new Decimal(adjustedPaymentAmount),
//             updatedAt: new Date(),
//           },
//         });

//         console.log(`Updated Payment ID: ${paymentId} with totalOrigAmount = ${totalOrigAmount}, totalWithHoldingTax = ${totalWithHoldingTax}, adjusted amount = ${adjustedPaymentAmount}`);
//       }
//     }

//     console.log("All billing, PaymentInvoices, and Payment records have been updated successfully.");
//   } catch (error) {
//     console.error("Error updating multiple billings, payment invoices, and payment records:", error);
//   }
// }



async function createDebitCreditMemos(
  billCredits: Array<{ billingNumber: string; amount: number; vendorId: number; vendorName: string }>
): Promise<{
  createdDebitCreditMemos: Array<{ id: number; vendorId: number; checkAmount: Prisma.Decimal }>;
  totalCheckAmount: number;
}> {
  const createdDebitCreditMemos: Array<{ id: number; vendorId: number; checkAmount: Prisma.Decimal }> = [];

  try {
    const now = new Date();

    for (const billCredit of billCredits) {
      const positiveAmount = Math.abs(billCredit.amount);
      const debitCreditMemo = await prisma.debitCreditMemo.create({
        data: {
          netsuiteId: null,
          documentDate: now,
          total: positiveAmount,
          documentNumber: '',
          status: '',
          checkAmount: positiveAmount,
          creditAmount: 0,
          postingType: 'Debit Memo',
          lastModifiedDate: now,
          createdAt: now,
          updatedAt: now,
          subsidiaryId: 2,
          debitCreditMemoNumber: billCredit.billingNumber,
          particular: '',
          referenceNumber: billCredit.billingNumber,
          debitCreditMemoStatus: '',
          preparedBy: '',
          approvedBy: '',
          checkedBy: '',
          receivedBy: '',
          billTo: billCredit.vendorName,
          billingAddress: '',
          vendorId: billCredit.vendorId,
          readBy: null,
          warehouseLocationId: null,
        },
      });

      console.log(`Created DebitCreditMemo for billing number ${billCredit.billingNumber}`);
      createdDebitCreditMemos.push({
        id: debitCreditMemo.id,
        vendorId: debitCreditMemo.vendorId ?? 0,
        checkAmount: debitCreditMemo.checkAmount,
      });
    }

    console.log(`All associated DebitCreditMemos created for the provided bill credits`);

    // Calculate the total check amount only after all DebitCreditMemos have been added to createdDebitCreditMemos
    const totalCheckAmount = createdDebitCreditMemos.reduce((sum, memo) => sum + memo.checkAmount.toNumber(), 0);
    console.log("Total Debit Credit Memo Amount (calculated within createDebitCreditMemos):", totalCheckAmount);

    return { createdDebitCreditMemos, totalCheckAmount };

  } catch (error) {
    console.error('Error creating DebitCreditMemos:', error);
    return { createdDebitCreditMemos: [], totalCheckAmount: 0 };
  }
}




async function createDebitCreditBills(
  debitCreditMemos: Array<{ id: number; vendorId: number; checkAmount: Prisma.Decimal }>,
  billingId: number // Single billing ID
) {
  try {
    console.log("Starting creation of DebitCreditBill entries for Billing ID:", billingId);

    for (const memo of debitCreditMemos) {
      console.log(`Processing DebitCreditBill for DebitCreditMemo ID: ${memo.id} with Billing ID: ${billingId}`);

      const existingDebitCreditBill = await prisma.debitCreditBill.findFirst({
        where: {
          dcmId: memo.id,
          billingId: billingId,
        },
      });

      if (!existingDebitCreditBill) {
        const newDebitCreditBill = await prisma.debitCreditBill.create({
          data: {
            billingId: billingId,
            dcmId: memo.id,
            updatedAt: new Date(),
          },
        });
        console.log(`Created new DebitCreditBill with ID: ${newDebitCreditBill.id}`);
      } else {
        console.log(`DebitCreditBill entry already exists for Memo ID: ${memo.id} and Billing ID: ${billingId}`);
      }
    }

    console.log("All DebitCreditBill entries created or verified successfully.");

  } catch (error) {
    console.error('Error creating DebitCreditBill entries:', error);
  }
}










const billingController = {
  getBilligs: async (
    filter: TFilter &
      Partial<
        Omit<Billing, "isRead"> & {
          dueDateRange: string;
          transactionDateRange: string;
          vendorName: string;
          isRead: "true" | "false";
          dateModifiedRange: string;
          docStartDateRange: string;
          docEndDateRange: string;
          user: User;
        }
      >
  ) => {
    try {
      const isVendor = filter.user?.role === "vendor";
      const startDate = filter.docStartDateRange ? new Date(filter.docStartDateRange) : {}

      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });

      const userId = filter.user?.id;
      const parsedId = userId !== undefined ? parseInt(userId.toString()) : undefined;

      var vendorIds = undefined
      let invalid_entity = undefined
      if (isVendor) {
        vendorIds = await getVendorIDs(parsedId)
        const entities = await prisma.warehouseLocation.findMany({
          where: {
            name: {
              contains: 'hilltop',
            },
          },
          select: {
            name: true,
          },
          distinct: ['name'],

        });
        invalid_entity = entities.map(entity => entity.name)
      }

      const condition: Prisma.BillingWhereInput = {
        vendorId: isVendor ? { in: vendorIds } : undefined,
        cbrStatus: {
          contains: filter.cbrStatus,
          ...(isVendor && { in: vendorStatus })
        },
        counterReceiptNumber: filter.counterReceiptNumber,
        supplierInvoiceReference: filter.supplierInvoiceReference,
        grossAmount: filter.grossAmount,
        withHoldingTax: filter.withHoldingTax,
        currency: filter.currency,
        terms: filter.terms,
        poNumber: filter.poNumber,
        warehouseLocationId: filter.warehouseLocationId
          ? +filter.warehouseLocationId
          : undefined,
        billingNumber: filter.billingNumber,
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        dueDate: filter.dueDateRange && {
          gte: new Date(`${filter.dueDateRange.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.dueDateRange.split(",")[1]}T23:59:59Z`),
        },
        docStartDate: filter.docStartDateRange && {
          gte: new Date(`${filter.docStartDateRange.split(",")[0]}T00:00:00Z`),
          // lte: new Date(`${filter.docStartDateRange.split(",")[1]}T23:59:59Z`),
        },
        docEndDate: filter.docEndDateRange && {
          // gte: new Date(`${filter.docEndDateRange.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.docEndDateRange.split(",")[1]}T23:59:59Z`),
        },
        dateModified: filter.dateModifiedRange && {
          gte: new Date(`${filter.dateModifiedRange.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.dateModifiedRange.split(",")[1]}T23:59:59Z`),
        },
        transactionDate: filter.transactionDateRange && {
          gte: isVendor ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO) : new Date(`${filter.transactionDateRange.split(",")[0]}T00:00:00Z`),
          lte: new Date(
            `${filter.transactionDateRange.split(",")[1]}T23:59:59Z`
          ),
        },
        vendor: {
          name: { contains: filter.vendorName },
        },
        // lastModifiedDate: {
        //   gte: isVendor ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO) : undefined,
        // },

        ...readBy,
      };


      const billings = await prisma.billing.findMany({
        where: condition,
        include: {
          vendor: true,
          subsidiary: true,
          warehouseLocation: true,
        },
        orderBy: [
          {
            lastModifiedDate: filter.sort || "desc",
          },
        ],
        skip:
          filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0,
        take: filter.limit ? +filter.limit : undefined,
      });

      const totalCount = await prisma.billing.count({ where: condition });

      
      const data = {
        totalCount,
        billings: billings.map(({ readBy, ...rest }) => ({
          ...rest,
          isRead: readBy?.includes(`"${filter.user?.id}"`),
        })),
      };

     



      return data;
    } catch (error) {
      return error;
    }
  },
  getMonthlyBillings: async (
    filter: TFilter &
      Partial<
        Omit<Billing, "isRead"> & {
          vendorName: string;
          docDateRange: string;
          postDateRange: string;
          subsidiaryId: number;
          isRead: "true" | "false";
          user: User;
        }
      >
  ): Promise<any> => {
    try {

      const docDateRanges = filter.docDateRange?.split(",");
      const postDateRanges = filter.postDateRange?.split(",");

      const q = filter.q;
      const isVendor = filter.user?.role === "vendor";
      const subsidiarySql = filter.subsidiaryId
        ? Prisma.sql`AND subsidiaryId=${filter.subsidiaryId}`
        : Prisma.empty;
      const docDateRangeSql = filter.docDateRange
        ? Prisma.sql`AND DATE(transactionDate) >= DATE(${docDateRanges?.[0]}) AND DATE(transactionDate) <= DATE(${docDateRanges?.[1]})`
        : Prisma.empty;
      const postDateRangeSql = filter.postDateRange
        ? Prisma.sql`AND DATE(Billing.createdAt) >= DATE(${postDateRanges?.[0]}) AND DATE(Billing.createdAt) <= DATE(${postDateRanges?.[1]})`
        : Prisma.empty;
      const transactionDate = isVendor
        ? Prisma.sql`AND DATE(Billing.transactionDate) > DATE(${pastDate(
          +config.VENDOR.RESULTS_DAYS_AGO
        )})`
        : Prisma.empty;

      const searchIsReadSql =
        q === "read"
          ? Prisma.sql`OR isRead=${true}`
          : q === "unread"
            ? Prisma.sql`OR isRead=${false}`
            : Prisma.empty;
      const vendorStatus = ['Approved']
      let cbrStatusSql;

      if (isVendor) {
        cbrStatusSql = Prisma.sql`AND cbrStatus=${'Approved'}`;
      } else {
        cbrStatusSql = filter.cbrStatus
          ? Prisma.sql`AND cbrStatus=${filter.cbrStatus}`
          : Prisma.empty;
      }

      const warehouseLocationIdSql = filter.warehouseLocationId
        ? Prisma.sql`AND warehouseLocationId=${filter.warehouseLocationId}`
        : Prisma.empty;
      const limitSql = filter.limit
        ? Prisma.sql`LIMIT ${+filter.limit}`
        : Prisma.empty;
      const offSetSql =
        filter.page && filter.limit
          ? Prisma.sql` OFFSET ${filter.limit * (filter.page - 1)}`
          : Prisma.empty;
      const vendorSql = isVendor
        ? Prisma.sql`AND vendorId=${filter.user?.vendorId}`
        : Prisma.empty;
        const readBySql =
  filter.isRead === "true"
    ? Prisma.sql`AND FIND_IN_SET(${filter.user?.id}, REPLACE(readBy, ' ', '')) > 0`
    : filter.isRead === "false"
      ? Prisma.sql`AND NOT FIND_IN_SET(${filter.user?.id}, REPLACE(readBy, ' ', '')) > 0`
      : Prisma.empty;

      

      const condition = Prisma.sql`
      (Vendor.name LIKE ${filter.vendorName ? `%${filter.vendorName}%` : "%"})
      ${vendorSql}
      ${subsidiarySql}
      ${docDateRangeSql}
      ${postDateRangeSql}
      ${cbrStatusSql}
      ${readBySql}
      ${warehouseLocationIdSql}
      ${transactionDate}
      AND (cbrStatus LIKE ${q ? `%${q}%` : "%"} ${searchIsReadSql})`;

      const billings = await prisma.$queryRaw`
        SELECT
        DATE_FORMAT(transactionDate, '%Y-%m') AS transactionMonth,
        MIN(transactionDate) AS startDate,
        MAX(transactionDate) AS endDate,
        MAX(dateModified) AS dateModified,
        MAX(cbrStatus) AS cbrStatus,
        Vendor.name AS vendorName,
        vendorId,
        GROUP_CONCAT(Billing.readBy SEPARATOR ',') as readBy_list,
        GROUP_CONCAT(Billing.id SEPARATOR ',') AS ids,
        REPLACE(readBy, ' ', '') AS cleaned_readBy,  
        (CASE 
            WHEN FIND_IN_SET(${filter.user?.id}, REPLACE(readBy, ' ', '')) > 0 
            THEN "true" ELSE "false" 
        END) AS isRead
        FROM
          Billing
          LEFT JOIN 
          Vendor ON Vendor.id = vendorId
        WHERE ${condition}
        GROUP BY
          transactionMonth, vendorId
        ORDER BY transactionMonth DESC
        ${limitSql}
        ${offSetSql}
      `;

      const totalCount = await prisma.$queryRaw`
        SELECT COUNT(*) as count
        FROM (
          SELECT
          DATE_FORMAT(transactionDate, '%Y-%m') AS transactionMonth,
          vendorId
          FROM
            Billing
            LEFT JOIN
            Vendor ON Vendor.id = vendorId
          WHERE ${condition}
          GROUP BY
            transactionMonth, vendorId
        ) AS countQuery;
      `;

      (billings as any[]).forEach((bill: any) => {
        console.log(bill);
      });


      const data = {
        totalCount: parseInt((totalCount as any)?.[0].count),
        billings: (billings as any).map((billing: any) => ({
          ...billing,
          isRead: billing.isRead === "true",
        })),
      };

      return data;
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getBillingsByYearMonth: async (
    filter: TFilter & {
      yearMonth: string;
      subsidiaryId?: number;
      vendorId: number;
      user?: User;
    }
  ) => {
    try {
      const isVendor = filter.user?.role === "vendor";
      let invalid_entity = undefined
      if (isVendor) {
        const entities = await prisma.warehouseLocation.findMany({
          where: {
            name: {
              contains: 'hilltop',
            },
          },
          select: {
            id: true,
          },
          distinct: ['id'],

        });
        invalid_entity = entities.map(entity => entity.id)
      }

      const condition: Prisma.BillingWhereInput = {
        vendorId: isVendor ? +`${filter.user?.vendorId}` : +filter.vendorId,
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        OR: [
          { warehouseLocationId: null },
          { warehouseLocationId: { notIn: invalid_entity ?? [] } },
        ], cbrStatus: isVendor ? { in: vendorStatus } : undefined,
        transactionDate: {
          gte: isVendor ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO) : new Date(`${filter.yearMonth}-01T00:00:00`),
          lte: new Date(`${filter.yearMonth}-31T23:59:59`),
        },
      };
      const skip: number =
        filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0;
      const take: number | undefined = filter.limit ? +filter.limit : undefined;
      // console.log(condition, 'monthly')
      const billings = await prisma.billing.findMany({
        where: condition,
        include: {
          vendor: true,
        },
        orderBy: [
          {
            transactionDate: filter.sort || "desc",
          },
        ],
        skip,
        take
      });

      const totalBillings = await prisma.billing.aggregate({
        where: condition,
        _sum: {
          grossAmount: true,
          vat: true,
          withHoldingTax: true,
          netAmount: true,
        },
        // skip,
        // take
      });


      const totalCount = await prisma.billing.count({ where: condition });



      billings.forEach(async (bill) => {

        let readBy = bill.readBy?.split(",") || []

        if (!filter.user) {
          return
        }

        if (!readBy.includes(filter.user?.id.toString())) {

          readBy.push(filter.user?.id.toString())
          const stringReadBy = readBy.join(", ")
          await prisma.billing.update({
            where: {
              id: bill.id
            },
            data: {
              readBy: stringReadBy
            }
          })
        }

      })
      const data = {
        totalCount,
        totalBillings: totalBillings._sum,
        billings: billings.map(({ readBy, ...rest }) => ({
          ...rest,
          isRead: readBy && filter.user ? readBy.split(",").includes(filter.user?.id.toString()) : false,
        })),
      };

      return data;
    } catch (error) {
      throw error;
    }
  },
  seedBiillings: async () => {
    try {
      const billings = [...Array(100)].map((_, index) => ({
        id: index + 1,
        billingNumber: `${faker.date.anytime().getTime()}`,
        terms: faker.lorem.sentence(),
        transactionDate: faker.date.between({
          from: "2023-01-01",
          to: Date.now(),
        }),
        docStartDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2022-12-31"),
        }),
        docEndDate: faker.date.between({
          from: new Date("2023-01-01"),
          to: new Date("2023-12-31"),
        }),
        dateModified: faker.date.anytime(),
        cbrStatus: +(Math.floor(Math.random() * 5) % 2 === 0)
          ? "pending"
          : "approved",
        readBy: "",
        dueDate: faker.date.between({ from: Date.now(), to: "2024-12-31" }),
        currency: faker.finance.currencyCode(),
        poNumber: `${faker.date.anytime().getTime()}`,
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        vendorId: Math.floor(Math.random() * 100) + 1,
        counterReceiptNumber: `${faker.date.anytime().getTime()}`,
        supplierInvoiceReference: `${faker.date.anytime().getTime()}`,
        grossAmount: faker.commerce.price(),
        withHoldingTax: faker.commerce.price(),
        type:
          (Math.floor(Math.random() * 5) + 1) % 2 === 0
            ? "bill"
            : "debit/credit",
        docNumber: `${faker.date.anytime().getTime()}`.slice(0, 9),
        vat: faker.commerce.price(),
        amount: +faker.commerce.price() * 3,
        ewt: faker.commerce.price(),
        netAmount: +faker.commerce.price() * 2,
        tradeDiscount: faker.commerce.price(),
        centralDropDiscount: faker.commerce.price(),
        centralTlcDiscount: faker.commerce.price(),
        otherSpecialDiscount: faker.commerce.price(),
        irNumber: `${faker.date.anytime().getTime()}`,
        warehouseLocationId: Math.floor(Math.random() * 100) + 1,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
        total: +faker.commerce.price() * 5,
      }));

      await prisma.billing.deleteMany();
      return await prisma.billing.createMany({ data: billings });
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getBilling: async (args: { billingId: number; userId: number, role: string }) => {
    try {

      
      const billing = await prisma.billing.findUnique({
        where: {
          id: args.billingId,
        },
        select: {
          readBy: true,
        },
      });

      const { readBy, ...rest } = await prisma.billing.update({
        where: {
          id: args.billingId,
        },
        data: {
          readBy: pushReadBy({
            readBy: billing?.readBy,
            userId: args.userId,
            role: args.role
          }),
        },
        include: {
          vendor: true,
          subsidiary: true,
          billingPOs: {
            include: {
              debitCreditMemo: true,
              item: true,
            },
          },
        },
      });

      const totalgrossAmount = rest.billingPOs.reduce((sum, item) => {
        return sum + +item.grossAmount;
      }, 0).toFixed(2);
      console.log(totalgrossAmount)
      const data = {
        ...rest,
        isRead: readBy?.includes(`"${args.userId}"`),
        totalgrossAmount
      };

      return data;
    } catch (error) {
      throw error;
    }
  },
  getCbrStatuses: async () => {
    try {
      const cbrStatuses = await prisma.billing.findMany({
        select: {
          cbrStatus: true,
        },
        distinct: ["cbrStatus"],
      });

      return cbrStatuses.map((_) => _.cbrStatus);
    } catch (error) {
      throw error;
    }
  },



  upsertBillingByNumber: async (req: Request, res: Response) => {
    try {
      console.log('Starting upsertBillingByNumber...');
      const totalCheckAmount = res.locals.totalCheckAmount; // Access totalCheckAmount from res.locals

      const userRole = req.user?.role;
      const userVendorId = req.body.vendorId;

      // console.log('User Role:', userRole);
      // console.log('Request User Vendor ID:', userVendorId);
      // console.log('Request Body:', req.body);

      const { id, firstName, lastName, email, role, vendorId, createdAt, updatedAt, iat, exp, ...potentialBillingData } = req.body;

      const billingData = Object.keys(potentialBillingData)
        .filter(key => !isNaN(Number(key)))
        .map(key => potentialBillingData[key]);

      // console.log('Filtered Billing Data:', billingData);

      if (billingData.length === 0) {
        // console.log('No billing records provided or invalid format.');
        res.locals.error = "No billing records provided or invalid format.";
      }

      const results = [];
      const newBillings = [];
      const updatedBillings = [];
      const upd: Array<{ id: number; billingNumber: string; subsidiaryId: number | null; newAmount: string; newEWT: string }> = [];
      // Define the type of each item in billCredits
      const billCredits: Array<{ billingNumber: string; amount: number; vendorId: number; vendorName: string }> = [];
      for (const billing of billingData) {

        const vendorId = billing.vendorId;

        if (!vendorId) {
          // console.log('Vendor ID missing for billing:', billing.billingNumber);
          results.push({ billingNumber: billing.billingNumber, error: "Vendor ID is required but missing." });
          continue;
        }

        // console.log('Using Vendor ID:', vendorId);

        // Billing data extraction and logic
        const {
          billingNumber,
          amount,
          ewt,
          subsidiaryId = 2,
          warehouseLocationId = 0,
          tradeDiscount = "0.00",
          centralDropDiscount = "0.00",
          centralTlcDiscount = "0.00",
          otherSpecialDiscount = "0.00",
          irNumber = " ",
          vat = "0.00",
          netAmount = "0.00",
          terms = " ",
          cbrStatus = "Approved",
          currency = "1",
          remarks = "<font face=\"georgia\" color=\"#ff0000\" size=\"2\"><b>Please take note of the following:</b></font><BR><blockquote style=\"margin: 0 0 0 40px; border: none; padding: 0px;\"><font face=\"georgia\" size=\"2\"><b>Rate</b> = Unit price EX-VAT, and EX-discounts</font><BR><font face=\"georgia\" size=\"2\"><b>Amount </b>= Rate*Quantity</font><BR><font face=\"georgia\" size=\"2\"><b>Tax Amt </b>= Amount*Tax rate</font><BR><font face=\"georgia\" size=\"2\"><b>Gross Amount </b>= Amount + Tax amt</font><BR><font face=\"georgia\" size=\"2\"><b>Trade discount amt </b>= Gross amount*Trade discount %</font><BR><font face=\"georgia\" size=\"2\"><b>Central drop amt</b> = (Gross amount -trade discount amt)*Central drop%</font><BR><font face=\"georgia\" size=\"2\"><b>TLC amt</b> = Gross amount*TLC %</font><BR><font face=\"georgia\" size=\"2\"><b>Other discount amt</b> = Gross amount*Other discount %</font><BR></blockquote>",
          counterReceiptNumber = "",
          transactionMonth,
          ...incomingBilling
        } = billing;

        if (!billingNumber) {
          console.log('Billing number missing for billing:', billing);
          results.push({ billingNumber, error: "Billing number is required." });
          continue;
        }

        const docNumber = billingNumber;
        const withHoldingTax = ewt;
        const total = amount;
        const grossAmount = parseFloat(amount) + Math.abs(parseFloat(ewt));

        const existingVendor = await vendorController.getVendor(vendorId);
        if (!existingVendor) {
          console.log(`Vendor with id ${vendorId} not found.`);
          results.push({ billingNumber, error: `Vendor with id ${vendorId} not found.` });
          continue;
        }

        const parsedSubsidiaryId = subsidiaryId ? parseInt(subsidiaryId, 10) : null;
        const parsedWarehouseLocationId = warehouseLocationId ? parseInt(warehouseLocationId, 10) : null;

        const existingBilling = await prisma.billing.findFirst({
          where: { billingNumber },
        });

        if (existingBilling) {
          // console.log('Existing billing found:', existingBilling);

          const isDataChanged = (
            existingBilling.type !== incomingBilling.type ||
            existingBilling.grossAmount.toNumber() !== grossAmount ||
            existingBilling.netAmount !== netAmount ||
            existingBilling.cbrStatus !== cbrStatus ||
            new Date(existingBilling.transactionDate).getTime() !== new Date(incomingBilling.transactionDate).getTime() ||
            new Date(existingBilling.dueDate).getTime() !== new Date(incomingBilling.dueDate).getTime() ||
            new Date(existingBilling.docStartDate).getTime() !== new Date(incomingBilling.docStartDate).getTime() ||
            new Date(existingBilling.docEndDate).getTime() !== new Date(incomingBilling.docEndDate).getTime() ||
            existingBilling.transactionMonth !== transactionMonth ||
            existingBilling.docNumber !== docNumber ||
            existingBilling.currency !== currency ||
            existingBilling.remarks !== incomingBilling.remarks ||
            existingBilling.terms !== terms ||
            existingBilling.poNumber !== incomingBilling.poNumber ||
            existingBilling.irNumber !== irNumber ||
            existingBilling.supplierInvoiceReference !== incomingBilling.supplierInvoiceReference ||
            existingBilling.centralDropDiscount !== centralDropDiscount ||
            existingBilling.centralTlcDiscount !== centralTlcDiscount ||
            existingBilling.otherSpecialDiscount !== otherSpecialDiscount ||
            existingBilling.tradeDiscount !== tradeDiscount ||
            existingBilling.vat !== vat ||
            existingBilling.withHoldingTax !== withHoldingTax ||
            existingBilling.total !== total ||
            existingBilling.amount !== total ||
            existingBilling.ewt !== withHoldingTax ||
            existingBilling.counterReceiptNumber !== incomingBilling.counterReceiptNumber ||
            existingBilling.vendorId !== vendorId ||
            existingBilling.subsidiaryId !== parsedSubsidiaryId ||
            existingBilling.warehouseLocationId !== parsedWarehouseLocationId
          );

          if (isDataChanged) {
            const editedBilling = await prisma.billing.update({
              where: { id: existingBilling.id },
              data: {
                type: incomingBilling.type,
                billingNumber: billingNumber,
                docNumber: docNumber,
                terms: terms,
                remarks: remarks,
                transactionDate: existingBilling.transactionDate,
                transactionMonth,
                dueDate: existingBilling.dueDate,
                docStartDate: existingBilling.docStartDate,
                docEndDate: existingBilling.docEndDate,
                tradeDiscount: tradeDiscount,
                centralDropDiscount: centralDropDiscount,
                centralTlcDiscount: centralTlcDiscount,
                otherSpecialDiscount: otherSpecialDiscount,
                irNumber: irNumber,
                vat: vat,
                amount: total,
                ewt: withHoldingTax,
                netAmount: netAmount,
                grossAmount: grossAmount,
                withHoldingTax: withHoldingTax,
                total: total,
                cbrStatus: cbrStatus,
                currency: currency,
                poNumber: incomingBilling.poNumber,
                netsuiteId: incomingBilling.netsuiteId,
                lastModifiedDate: new Date(),
                counterReceiptNumber: incomingBilling.counterReceiptNumber,
                supplierInvoiceReference: incomingBilling.supplierInvoiceReference,
                vendor: vendorId ? { connect: { id: vendorId } } : undefined,
                subsidiary: parsedSubsidiaryId ? { connect: { id: parsedSubsidiaryId } } : undefined,
                warehouseLocation: parsedWarehouseLocationId ? { connect: { id: parsedWarehouseLocationId } } : undefined,
              },
            });

            // console.log(`Billing record updated for billing number ${billingNumber}`);
            results.push({ billingNumber, message: `Billing record updated successfully.`, data: editedBilling });
            if (isDataChanged) {

              const relatedPaymentInvoices = await prisma.paymentInvoice.findMany({
                where: { invoiceId: existingBilling.id }
              });

              for (const paymentInvoice of relatedPaymentInvoices) {
                await prisma.paymentInvoice.update({
                  where: { id: paymentInvoice.id },
                  data: {
                    paymentAmount: total, // Set to the new billing amount
                    lastModifiedDate: new Date()
                  }
                });
                console.log(`Updated PaymentInvoice ID: ${paymentInvoice.id} for billing number ${billingNumber}`);

                // Recalculate and update the related Payment for each updated PaymentInvoice
                const paymentId = paymentInvoice.paymentId;
                if (paymentId) {
                  const relatedInvoices = await prisma.paymentInvoice.findMany({
                    where: { paymentId: paymentId }
                  });

                  const totalPaymentAmount = relatedInvoices.reduce((sum, invoice) => sum + parseFloat(invoice.paymentAmount.toString()), 0);
                  const totalEWT = relatedInvoices.reduce((sum, invoice) => sum + parseFloat(invoice.paymentAmount.toString()), 0);
                  const debitCreditBills = await prisma.debitCreditBill.findMany({
                    where: { billingId: existingBilling.id }
                  });
                  const debitCreditMemoIds = debitCreditBills.map(dcb => dcb.dcmId);

                  // Update the `DebitCreditMemos` with new checkAmount values
                  let totalCheckAmount = 0;
                  for (const billCredit of billCredits) {
                    const existingMemo = await prisma.debitCreditMemo.findFirst({


                      where: { debitCreditMemoNumber: billCredit.billingNumber }
                    });

                    if (existingMemo) {
                      // Update `checkAmount` in DebitCreditMemo
                      console.log(`Found DebitCreditMemo with ID: ${existingMemo.id} for bill credit ${billCredit.billingNumber}`);
                      const updatedMemo = await prisma.debitCreditMemo.update({
                        where: { id: existingMemo.id },
                        data: {
                          checkAmount: new Prisma.Decimal(billCredit.amount),
                          updatedAt: new Date()
                        }
                      });
                      totalCheckAmount += parseFloat(updatedMemo.checkAmount.toString());

                      console.log(`Updated DebitCreditMemo ID: ${existingMemo.id} for bill credit ${billCredit.billingNumber} with new check amount: ${billCredit.amount}`);
                    }
                  }
                  await prisma.payment.update({
                    where: { id: paymentId },
                    data: {
                      amount: totalPaymentAmount - totalCheckAmount,
                      totalWithHoldingTax: totalEWT,
                      netAmount: totalPaymentAmount - totalCheckAmount,
                      updatedAt: new Date()
                    }
                  });
                  console.log(`Updated Payment ID: ${paymentId} totals for vendor ID: ${vendorId}`);
                }
              }


            }
          } else {
            // console.log(`No changes detected for billing number ${billingNumber}`);
            results.push({ billingNumber, message: `No changes detected.` });
            updatedBillings.push(existingBilling);
          }
        } else {
          const createdBilling = await prisma.billing.create({
            data: {
              billingNumber: billingNumber,
              docNumber: docNumber,
              terms: terms,
              remarks: remarks,
              transactionDate: new Date(),
              transactionMonth,
              dueDate: new Date(),
              docStartDate: new Date(),
              docEndDate: new Date(),
              tradeDiscount: tradeDiscount,
              centralDropDiscount: centralDropDiscount,
              centralTlcDiscount: centralTlcDiscount,
              otherSpecialDiscount: otherSpecialDiscount,
              irNumber: irNumber,
              vat: vat,
              amount: amount,
              ewt: ewt,
              netAmount: netAmount,
              grossAmount: grossAmount,
              withHoldingTax: withHoldingTax,
              total: total,
              cbrStatus: cbrStatus,
              currency: currency,
              poNumber: incomingBilling.poNumber,
              netsuiteId: incomingBilling.netsuiteId,
              lastModifiedDate: new Date(),
              type: incomingBilling.type,
              dateModified: new Date(),
              counterReceiptNumber: counterReceiptNumber,
              supplierInvoiceReference: incomingBilling.supplierInvoiceReference,
              vendor: vendorId ? { connect: { id: vendorId } } : undefined,
              subsidiary: parsedSubsidiaryId ? { connect: { id: parsedSubsidiaryId } } : undefined,
              warehouseLocation: parsedWarehouseLocationId ? { connect: { id: parsedWarehouseLocationId } } : undefined,
            },
          });

          // console.log(`Billing record created for billing number ${billingNumber}`);
          results.push({ billingNumber, message: `Billing record created successfully.`, data: createdBilling });

          newBillings.push({
            id: createdBilling.id,
            billingNumber: createdBilling.billingNumber,
            subsidiaryId: createdBilling.subsidiaryId,
            amount: createdBilling.amount,  // Use Prisma.Decimal directly
            ewt: createdBilling.ewt,
            vendorId: vendorId  // Use Prisma.Decimal directly
          });

        }
      }


      if (newBillings.length > 0) {
        await createPaymentAndInvoice(newBillings, totalCheckAmount);
      }
      console.log(`total check ${totalCheckAmount}`)
      res.locals.newBillings = newBillings;
      res.locals.updatedBillings = updatedBillings;

      res.locals.billingResults = results;
    } catch (error: any) {
      // console.error("Error in processing billing:", error);
      res.locals.error = error.message;
    }
  },



  processExcelFile: async (req: Request, res: Response) => {
    try {
      // Check if a file was uploaded
      if (!req.file) {
        console.log('No file uploaded');
        res.status(400).json({ message: 'No file uploaded.' });
        return;
      }
      console.log('File uploaded successfully');

      // Read the uploaded Excel file as a workbook
      const workbook = xlsx.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData: any[][] = xlsx.utils.sheet_to_json(worksheet, { header: 1 });

      let userVendorId = req.user?.vendorId;
      let vendorNameFromExcel: string | null = null;
      let bestMatch: { id: number; name: string } | null = null;

      if (req.user.role === 'admin-accounting') {
        vendorNameFromExcel = jsonData[8] && jsonData[8][0];
        if (vendorNameFromExcel) {
          const vendors = await prisma.vendor.findMany();
          let bestScore = Infinity;

          for (const vendor of vendors) {
            const similarityScore = levenshteinDistance(vendorNameFromExcel.toLowerCase(), vendor.name.toLowerCase());
            if (similarityScore < bestScore) {
              bestScore = similarityScore;
              bestMatch = vendor;
            }
          }

          if (bestMatch && bestScore <= 5) {
            userVendorId = bestMatch.id;
          } else {
            console.log("No sufficiently similar vendor found.");
            res.status(400).json({ message: 'No sufficiently similar vendor found.' });
            return;
          }
        } else {
          console.log("No vendor name found in the Excel file.");
          res.status(400).json({ message: 'No vendor name found in the Excel file.' });
          return;
        }
      }

      const billingData = jsonData.slice(7).map((row: any) => {
        if (!row || row.length === 0 || row.every((cell: any) => !cell)) {
          return null;
        }

        const type = row[1] ? row[1].toString().toLowerCase() : '';
        const billingNumber = row[3] ? String(row[3]) : null;
        const amount = row[6] ? parseFloat(row[6].toString().replace('PHP', '').replace(',', '')) : null;
        const poNumber = row[5] || '';
        const supplierInvoiceReference = row[4] ? String(row[4]) : '';
        const transactionMonth = row[12] ? String(row[12]) : '';

        // Only process rows with a billing number
        if (!billingNumber || billingNumber === 'undefined') {
          return null;
        }

        return {
          billingNumber,
          type: type === 'bill' ? 'bill' : 'bill credit', // Determine if it's a bill or bill credit
          ewt: row[10] ? parseFloat(row[10]) : 0.00,
          amount,
          poNumber,
          supplierInvoiceReference,
          vendorId: userVendorId,
          transactionMonth
        };
      }).filter((row): row is NonNullable<typeof row> => row !== null);

      // If no billing records were found, respond with an error
      if (billingData.length === 0) {
        console.log("No valid billing records found.");
        res.status(400).json({ message: 'No valid billing records found.' });
        return; // Stop further processing
      }

      console.log('Using Vendor ID:', userVendorId);

      // Separate bills and bill credits from the parsed data
      const bills = billingData.filter(billing => billing.type === 'bill');
      const billCredits = billingData.filter(billing => billing.type === 'bill credit');

      // Map valid bill credits for memo creation
      const validBillCredits = billCredits.map(billCredit => ({
        billingNumber: billCredit.billingNumber,
        amount: billCredit.amount as number,
        vendorId: billCredit.vendorId as number,
        vendorName: bestMatch ? bestMatch.name : '',
      }));

      // Step 1: Create DebitCreditMemos based on valid bill credits
      const { createdDebitCreditMemos, totalCheckAmount } = await createDebitCreditMemos(validBillCredits);
      res.locals.totalCheckAmount = totalCheckAmount; // Store the total check amount for further use

      // Step 2: Upsert the bill data only (excludes bill credits) by passing bills to upsertBillingByNumber
      req.body = bills;
      await billingController.upsertBillingByNumber(req, res);

      // Retrieve the newly created and updated billing records from upsertBillingByNumber
      const newBillings = res.locals.newBillings || [];
      const updatedBillings = res.locals.updatedBillings || [];
      const allBillings = [...newBillings, ...updatedBillings];

      // If no billings were created or updated, skip DebitCreditBill creation
      if (allBillings.length === 0) {
        console.log("No billing records created or updated. Skipping DebitCreditBill creation.");
        res.status(200).json({ message: "No billing records created or updated. Skipping DebitCreditBill creation." });
        return; // Stop further processing
      }
      const firstBillingId = allBillings[0].id;
      // Gather all billing IDs from new and updated records for linking to debit/credit memos
      const billingIds = allBillings.map(billing => billing.id);

      if (firstBillingId) {
        console.log("Creating DebitCreditBills for the first billing ID:", firstBillingId);
        await createDebitCreditBills(createdDebitCreditMemos, firstBillingId);
      } else {
        console.warn("No valid first billing ID found. Skipping DebitCreditBill creation.");
      }

      // Final success response with results
      console.log("Finished processing all billing records.");
      res.status(200).json({
        message: "Excel file processed successfully, and all billing records handled.",
        results: res.locals.billingResults,
      });
    } catch (error: any) {
      // Error handling for unexpected issues during processing
      console.error('Error processing the Excel file:', error);
      if (!res.headersSent) {
        res.status(500).json({ message: 'Failed to process Excel file.', error: error.message });
      }
    }
  },


  updateTransactionMonth: async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        console.log('No file uploaded');
        res.status(400).json({ message: 'No file uploaded.' });
        return;
      }

      console.log('File uploaded successfully');

      const workbook = xlsx.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData: any[][] = xlsx.utils.sheet_to_json(worksheet, { header: 1 });

      if (jsonData.length < 2) {
        return res.status(400).json({ message: 'No valid data found in the file.' });
      }

      const updates = jsonData.slice(1).map((row) => ({
        billingNumber: row[0]?.toString().trim(), // Column 1: Billing Number
        transactionMonth: row[1] !== undefined ? row[1].toString().trim() : " ", // Column 2: Transaction Month
      })).filter(row => row.billingNumber && row.transactionMonth);

      if (updates.length === 0) {
        return res.status(400).json({ message: 'No valid data found in the file.' });
      }

      let updateResults: any[] = [];

      for (const update of updates) {
        const { billingNumber, transactionMonth } = update;

        const existingBilling = await prisma.billing.findFirst({
          where: { billingNumber },
        });

        if (!existingBilling) {
          updateResults.push({ billingNumber, status: 'Not Found', message: 'Billing number does not exist' });
          continue;
        }

        await prisma.billing.update({
          where: { id: existingBilling.id },
          data: { transactionMonth: transactionMonth },
        });

        updateResults.push({ billingNumber, status: 'Updated', message: 'Transaction month updated successfully' });
      }

      console.log('Finished updating transaction months.');
      res.status(200).json({ message: 'Transaction month update completed.', results: updateResults });

    } catch (error: any) {
      console.error('Error updating transaction month:', error);
      res.status(500).json({ message: 'Failed to update transaction month.', error: error.message });
    }
  }






};






export default billingController;
