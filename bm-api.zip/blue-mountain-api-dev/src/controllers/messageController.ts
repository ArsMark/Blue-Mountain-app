import { Message, PrismaClient } from "@prisma/client";
import Email from "../helpers/Email";

const prisma = new PrismaClient();

const messageController = {
  getMessages: async () => {
    try {
      const messages = await prisma.message.findMany();
      const totalCount = await prisma.message.count();

      return { totalCount, messages };
    } catch (error) {
      throw error;
    }
  },
  getMessage: async (messageId: number) => {
    return await prisma.message.findUnique({
      where: {
        id: +messageId,
      },
    });
  },
  sendMessage: async (
    message: Omit<Message, "id" | "createdAt" | "updatedAt">
  ) => {
    try {
      if (!message.departmentId) {
        const error = new Error(
          "Sending email failed, department ID is required"
        );
        error.name = "department";
        throw error;
      }

      const department = await prisma.department.findUnique({
        where: {
          id: +message.departmentId,
        },
      });

      if (!department?.email) {
        const error = new Error("Sending email failed, department not found");
        error.name = "department";
        throw error;
      }

      const emailResponse = new Email();

      await emailResponse.send({
        from: {
          name: message.fullName,
          address: message.email,
        },
        to: department.email,
        subject: `${message.fullName}:${message.subject}`,
        text: message.content,
      });

      return await prisma.message.create({
        data: { ...message, departmentId: +message.departmentId },
      });
    } catch (error) {
      throw error;
    }
  },
};

export default messageController;
