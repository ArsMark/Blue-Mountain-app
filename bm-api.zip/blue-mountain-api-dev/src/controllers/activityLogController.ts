import { Prisma, PrismaClient, User } from "@prisma/client";
import logger from "../utils/logger";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const activityLogController = {
  getActivityLogs: async (
    filter: TFilter &
      Partial<{
        user: Pick<User, "id">;
      }>
  ) => {
    try {
      const condition: Prisma.ActivityLogWhereInput = {
        action: {
          contains: filter.q,
        },
        userId: filter.user?.id ? +filter.user.id : undefined,
      };

      const activityLogs = await prisma.activityLog.findMany({
        where: condition,
        include: {
          user: {
            select: {
              firstName: true,
              lastName: true,
              email: true,
              role: true,
            },
          },
        },
        orderBy: [
          {
            id: filter.sort || "asc",
          },
        ],
        skip:
          filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0,
        take: filter.limit ? +filter.limit : undefined,
      });

      const totalCount = await prisma.activityLog.count({ where: condition });

      return { totalCount, activityLogs };
    } catch (error) {
      logger(error);
      return error;
    }
  },
  addActivityLog: async (activity: { userId: number; action: string }) => {
    return await prisma.activityLog.create({ data: activity });
  },
  getActivityLog: async (activityLogId: number) => {
    return await prisma.activityLog.findUnique({
      where: {
        id: activityLogId,
      },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
            role: true,
          },
        },
      },
    });
  },
};

export default activityLogController;
