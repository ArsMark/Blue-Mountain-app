import { faker } from "@faker-js/faker";
import { PaymentInvoice, PrismaClient } from "@prisma/client";
import logger from "../utils/logger";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const paymentInvoiceController = {
  getPaymentInvoices: async (filter: TFilter & Partial<PaymentInvoice>) => {
    try {
      const limit = filter.limit || 100;

      const paymentInvoices = await prisma.paymentInvoice.findMany({
        where: {
          paymentAmount: filter.paymentAmount,
          invoiceId: filter.invoiceId ? +filter.invoiceId : undefined,
          subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        },
        include: {
          payment: true,
          subsidiary: true,
        },
        orderBy: [
          {
            lastModifiedDate: filter.sort || "desc",
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });
      const totalCount = await prisma.paymentInvoice.count();

      return { totalCount, paymentInvoices };
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getPaymentInvoice: async (paymentInvoiceId: number) => {
    return await prisma.paymentInvoice.findUnique({
      where: {
        id: paymentInvoiceId,
      },
      include: {
        subsidiary: true,
        payment: true,
      },
    });
  },
  seedPaymentInvoices: async () => {
    try {
      const paymentInvoices = [...Array(100)].map((_, index) => ({
        id: index + 1,
        invoiceId: +Math.floor(Math.random() * 100) + 1,
        paymentAmount: +faker.commerce.price() * 2,
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        paymentId: +Math.floor(Math.random() * 100) + 1,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.paymentInvoice.deleteMany();
      return await prisma.paymentInvoice.createMany({ data: paymentInvoices });
    } catch (error) {
      return error;
    }
  },
};

export default paymentInvoiceController;
