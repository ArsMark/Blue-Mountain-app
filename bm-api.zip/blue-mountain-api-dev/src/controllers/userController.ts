import { Prisma, PrismaClient, User } from "@prisma/client";
import { compareSync, hashSync } from "bcrypt";
import jwt from "jsonwebtoken";
import Email from "../helpers/Email";
import config from "../utils/config";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const userWithoutPassword: Prisma.UserSelect = {
  id: true,
  firstName: true,
  lastName: true,
  email: true,
  role: true,
  vendorId: true,
  createdAt: true,
  updatedAt: true,
};

const userController = {
  createUser: async (
    data: Pick<
      User,
      "email" | "firstName" | "lastName" | "password" | "role" | "vendorId"
    >
  ) => {
    try {
      const password = hashSync(data.password, 12);

      const isExist = await prisma.user.findUnique({
        where: {
          email: data.email,
        },
      });

      if (isExist) {
        const error = new Error("Email already exists");
        error.name = "user";
        throw error;
      }

      return await prisma.user.create({
        data: {
          ...data,
          password,
        },
        select: userWithoutPassword,
      });
    } catch (error) {
      throw error;
    }
  },
  getUsers: async (filter: TFilter) => {
    const limit = filter.limit || 100;

    return await prisma.user.findMany({
      select: userWithoutPassword,
      orderBy: [
        {
          id: filter.sort || "asc",
        },
      ],
      skip: filter.page ? limit * (filter.page - 1) : 0,
      take: +limit,
    });
  },
  getUser: async (
    data: Pick<User, "email"> & {
      includePassword?: boolean;
    }
  ) => {
    return await prisma.user.findFirst({
      where: {
        OR: [
          {
            email: data.email,
          },
        ],
      },
      select: {
        ...userWithoutPassword,
        password: data.includePassword ? true : false,
      },
    });
  },
  deleteUsers: async () => {
    return await prisma.user.deleteMany();
  },
  updateUserPassword: async (
    data:
      | {
          userId: number;
          newPassword: string;
          currentPassword: string;
          reset?: false;
        }
      | {
          userId: number;
          newPassword: string;
          reset: true;
        }
  ) => {
    try {
      const user = await prisma.user.findUnique({
        where: {
          id: data.userId,
        },
      });

      if (!data.reset) {
        const validPassword = compareSync(
          data.currentPassword,
          `${user?.password}`
        );

        if (!validPassword) {
          const error = new Error("Invalid current password");
          error.name = "user";
          throw error;
        }
      }

      const password = hashSync(data.newPassword, 12);

      return await prisma.user.update({
        where: {
          id: data.userId,
        },
        data: {
          password,
        },
        select: userWithoutPassword,
      });
    } catch (error) {
      throw error;
    }
  },
  sendResetPasswordLink: async (
    data: Pick<User, "email"> & {
      link: string;
    }
  ) => {
    try {
      const user = await prisma.user.findUnique({
        where: {
          email: data.email,
        },
      });

      if (!user) {
        const error = new Error("Email does not exist");
        error.name = "user";
        throw error;
      }

      const token = jwt.sign(user, `${config.RESET_PASSWORD_TOKEN_SECRET}`, {
        expiresIn: "15min",
      });

      const email = new Email();

      const emailResponse = await email.send({
        from: {
          name: "Blue Mountain",
          address: `${config.SYSTEM_EMAIL}`,
        },
        to: user.email,
        subject: "Reset Password",
        html: `Click the link to reset your password, it will expire in 24 hours:<a href="${data.link}/${token}">Password reset link</a>`,
      });

      if (!emailResponse?.response) {
        const error = new Error("Email not set");
        error.name = "user";
        throw error;
      }

      return `Reset password link was sent to ${user.email}`;
    } catch (error) {
      throw error;
    }
  },
};

export default userController;
