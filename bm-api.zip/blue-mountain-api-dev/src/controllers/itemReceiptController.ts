import { faker } from "@faker-js/faker";
import { ItemReceipt, Prisma, PrismaClient, User } from "@prisma/client";
import config from "../utils/config";
import { pastDate } from "../utils/date";
import logger from "../utils/logger";
import { pushReadBy, readByCondition, getVendorIDs, appendReadBy } from "../utils/prismaCondition";
import {
  TFilter,
  amountFormat,
  numberFormat,
} from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const itemReceiptController = {
  getItemReceipts: async (
    filter: TFilter &
      Partial<
        Omit<ItemReceipt, "isRead"> & {
          receivedDateRange: string;
          poDateRange: string;
          vendorName: string;
          isRead: "true" | "false";
          user: User;
        }
      >
  ) => {
    try {
      const q = filter.q;
      const qNum = numberFormat.test(`${q}`) ? +`${q}` : undefined;
      const qAmount = amountFormat.test(`${q}`)
        ? +`${q?.replace(",", "")}`
        : undefined;
      const isVendor = filter.user?.role === "vendor";

      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });

      const userId = filter.user?.id;
      const parsedId = userId !== undefined ? parseInt(userId.toString()) : undefined;
      var vendorIds = undefined
      
      if (isVendor) {
        vendorIds = await getVendorIDs(parsedId) 
      }

      const condition: Prisma.ItemReceiptWhereInput = {
        vendorId: isVendor ? { in: vendorIds } : undefined,
        totalQuantity: filter.totalQuantity,
        amount: filter.amount,
        poNumber: {
          contains: filter.poNumber,
        },
        supplierInvoiceReference: {
          contains: filter.supplierInvoiceReference,
        },
        preparedBy: {
          contains: filter.preparedBy,
        },
        checkedBy: {
          contains: filter.checkedBy,
        },
        approvedBy: {
          contains: filter.approvedBy,
        },
        receivedBy: {
          contains: filter.receivedBy,
        },
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        status: filter.status,
        vendorInvoiceNumber: {
          contains: filter.vendorInvoiceNumber,
        },
        warehouseLocationId: filter.warehouseLocationId
          ? +filter.warehouseLocationId
          : undefined,
        irNumber: {
          contains: filter.irNumber,
        },
        receivedDate: {
          gte: filter.receivedDateRange
            ? new Date(`${filter.receivedDateRange.split(",")[0]}T00:00:00Z`)
            : isVendor
            ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO)
            : undefined,
          lte: filter.receivedDateRange
            ? new Date(`${filter.receivedDateRange.split(",")[1]}T23:59:59Z`)
            : undefined,
        },
        poDate: filter.poDateRange && {
          gte: new Date(`${filter.poDateRange.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.poDateRange.split(",")[1]}T23:59:59Z`),
        },
        vendor: {
          name: {
            contains: filter.vendorName,
          },
        },
        OR: [
          {
            poNumber: {
              contains: q,
            },
          },
          {
            vendor: {
              name: {
                contains: q,
              },
            },
          },
          { totalQuantity: qNum },
          {
            status: {
              contains: q,
            },
          },
          {
            warehouseLocation: {
              address: {
                contains: q,
              },
            },
          },
          { amount: qNum },
          {
            vendorInvoiceNumber: {
              contains: q,
            },
          },
          {
            irNumber: {
              contains: q,
            },
          },
          {
            amount: qAmount,
          },
        ],
        ...readBy,
      };

      const itemReceipts = await prisma.itemReceipt.findMany({
        where: condition,
        include: {
          vendor: true,
          subsidiary: true,
          warehouseLocation: true,
        },
        orderBy: [
          {
            receivedDate: filter.sort || "desc",
          },
        ],
        skip:
          filter.page && filter.limit
            ? filter.limit * (filter.page - 1)
            : undefined,
        take: filter.limit ? +filter.limit : undefined,
      });
      const totalCount = await prisma.itemReceipt.count({ where: condition });

      const data = {
        totalCount,
        itemReceipts: itemReceipts.map(({ readBy, ...rest }) => ({
          ...rest,
          isRead: readBy?.includes(`"${filter.user?.id}"`),
        })),
      };

      return data;
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getStatuses: async () => {
    try {
      const statuses = await prisma.itemReceipt.findMany({
        select: {
          status: true,
        },
        distinct: ["status"],
      });

      return statuses.map((_) => _.status);
    } catch (error) {
      throw error;
    }
  },
  seedItemReceipts: async () => {
    try {
      const itemReceipts = [...Array(100)].map((_, index) => ({
        id: index + 1,
        totalQuantity: +(Math.floor(Math.random() * 5) + 1) * index + 1,
        amount: faker.commerce.price(),
        vendorId: +Math.floor(Math.random() * 100) + 1,
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        poNumber: `${faker.date.past().getTime()}`,
        supplierInvoiceReference: `${faker.date.past().getTime()}`,
        receivedDate: faker.date.soon(),
        poDate: faker.date.past(),
        preparedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
        checkedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
        approvedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
        receivedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
        readBy: "",
        status:
          Math.floor(Math.random() * 10) % 2 === 0 ? "rejected" : "approved",
        warehouseLocationId: Math.floor(Math.random() * 100) + 1,
        vendorInvoiceNumber: `${faker.date.anytime().getTime()}`,
        irNumber: `${faker.date.anytime().getTime()}`,
        totalExpectedQuantity:
          +(Math.floor(Math.random() * 10) + 1) * index + 2,
        totalDeliveredQuantity:
          +(Math.floor(Math.random() * 10) + 1) * index + 2,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.itemReceipt.deleteMany();
      return await prisma.itemReceipt.createMany({ data: itemReceipts });
    } catch (error) {
      return error;
    }
  },
  getItemReceipt: async (args: { itemReceiptId: number; userId: number, role: string }) => {
    try {
      const itemReceipt = await prisma.itemReceipt.findUnique({
        where: {
          id: args.itemReceiptId,
        },
        select: {
          readBy: true,
        },
      });

      const { readBy, ...rest } = await prisma.itemReceipt.update({
        where: {
          id: args.itemReceiptId,
        },
        data: {
          readBy: appendReadBy({
            readBy: itemReceipt?.readBy,
            userId: args.userId,
          }),
        },
        include: {
          subsidiary: true,
          vendor: true,
          warehouseLocation: true,
          itemReceiptItems: {
            include: {
              item: true,
            },
          },
        },
      });

      const data = { ...rest, isRead: readBy?.includes(`"${args.userId}"`) };

      return data;
    } catch (error) {
      throw error;
    }
  },
};

export default itemReceiptController;
