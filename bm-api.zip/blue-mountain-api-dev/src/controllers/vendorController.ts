import { faker } from "@faker-js/faker";
import { PrismaClient } from "@prisma/client";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const vendorController = {
  // createVendor: async (data: Pick<Vendor, "name" | "netsuiteId">) => {
  //   return await prisma.vendor.create({
  //     data,
  //   });
  // },

  getVendors: async (filter: TFilter) => {
    try {
      const limit = filter.limit || 100;

      const vendors = await prisma.vendor.findMany({
        orderBy: [
          {
            id: filter.sort || "asc",
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });

      const totalCount = await prisma.vendor.count();

      return { totalCount, vendors };
    } catch (error) {
      return error;
    }
  },

  getVendor: async (vendorId: number) => {
    return await prisma.vendor.findUnique({
      where: {
        id: vendorId,
      },
    });
  },

  seedVendors: async () => {
    try {
      const vendors = [...Array(100)].map((_, index) => ({
        id: index + 1,
        name: faker.company.name(),
        address: `${faker.location.buildingNumber()} ${faker.location.street()} ${faker.location.city()} ${faker.location.state()}`,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.vendor.deleteMany();
      return await prisma.vendor.createMany({ data: vendors });
    } catch (error) {
      return error;
    }
  },
};

export default vendorController;
