import { faker } from "@faker-js/faker";
import { Prisma, PrismaClient } from "@prisma/client";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const warehouseLocationController = {
  getWarehouseLocations: async (
    filter: TFilter &
      Partial<{
        subsidiaryId: number;
      }>
  ) => {
    const limit = filter.limit || 100;
    const condition: Prisma.WarehouseLocationWhereInput = {
      subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
      name: {
        contains: filter.q,
      },
    };

    const data = await prisma.warehouseLocation.findMany({
      where: condition,
      orderBy: [
        {
          name: filter.sort || "asc",
        },
      ],
      skip: filter.page ? limit * (filter.page - 1) : 0,
      take: +limit,
    });

    const totalCount = await prisma.warehouseLocation.count({
      where: condition,
    });

    return {
      totalCount,
      data,
    };
  },
  getWarehouseLocation: async (warehouseLocationId: number) => {
    return await prisma.warehouseLocation.findMany({
      where: {
        id: warehouseLocationId,
      },
    });
  },
  seedWarehouseLocation: async () => {
    try {
      const warehouseLocations = [...Array(100)].map((_, index) => ({
        id: index + 1,
        address: `${faker.location.buildingNumber()} ${faker.location.street()} ${faker.location.city()} ${faker.location.state()}`,
        subsidiaryId: Math.floor(Math.random() * 2) + 1,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
        name: faker.company.name(),
      }));

      await prisma.warehouseLocation.deleteMany();

      return await prisma.warehouseLocation.createMany({
        data: warehouseLocations,
      });
    } catch (error) {
      throw error;
    }
  },
};

export default warehouseLocationController;
