import { faker } from "@faker-js/faker";
import { DebitCreditMemo, Prisma, PrismaClient, User } from "@prisma/client";
import config from "../utils/config";
import { pastDate } from "../utils/date";
import { pushReadBy, readByCondition, getVendorIDs, IsdRead, appendReadBy } from "../utils/prismaCondition";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const debitCreditMemoController = {
  getDebitCreditMemos: async (
    filter: TFilter &
      Partial<
        Omit<DebitCreditMemo, "isRead"> & {
          docDateRange: string;
          vendorName: string;
          isRead: "true" | "false";
          user: User;
        }
      >
  ) => {
    try {
      const q = filter.q;
      const qNum = /^[0-9]+$/.test(`${q}`) ? +`${q}` : undefined;
      const isVendor = filter.user?.role === "vendor";

      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });

      const userId = filter.user?.id;
      const parsedId = userId !== undefined ? parseInt(userId.toString()) : undefined;
      
      var vendorIds = undefined
      if (isVendor) {
        vendorIds = await getVendorIDs(parsedId) 
      }

      const condition: Prisma.DebitCreditMemoWhereInput = {
        vendorId: isVendor ? { in: vendorIds } : undefined,
        debitCreditMemoNumber: { contains: filter.debitCreditMemoNumber },
        referenceNumber: { contains: filter.referenceNumber },
        debitCreditMemoStatus: { contains: filter.debitCreditMemoStatus },
        particular: { contains: filter.particular },
        documentNumber: { contains: filter.documentNumber },
        preparedBy: { contains: filter.preparedBy },
        approvedBy: { contains: filter.approvedBy },
        checkedBy: { contains: filter.checkedBy },
        receivedBy: { contains: filter.receivedBy },
        billTo: { contains: filter.billTo },
        billingAddress: { contains: filter.billingAddress },
        total: filter.total ? +filter.total : undefined,
        status: { contains: filter.status },
        checkAmount: filter.checkAmount ? +filter.checkAmount : undefined,
        postingType: { contains: 'Debit Memo' },
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        documentDate: {
          gte: filter.docDateRange ? new Date(`${filter.docDateRange.split(",")[0]}T00:00:00Z`)
          : isVendor
          ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO)
            : undefined,
          lte: filter.docDateRange
            ? new Date(`${filter.docDateRange.split(",")[1]}T23:59:59Z`)
            : undefined
        },
        vendor: {
          name: {
            contains: filter.vendorName,
          },
        },
        OR: [
          {
            debitCreditMemoNumber: {
              contains: q,
            },
          },
          {
            postingType: {
              contains: q,
            },
          },
          {
            vendor: {
              name: {
                contains: q,
              },
            },
          },
          { total: qNum },
          {
            debitCreditMemoStatus: {
              contains: q,
            },
          },
          { status: { contains: q } },
        ],
        ...readBy,
      };

      const debitCreditMemos = await prisma.debitCreditMemo.findMany({
        where: condition,
        include: {
          subsidiary: true,
          vendor: true,
        },
        orderBy: [
          {
            lastModifiedDate: filter.sort || "desc",
          },
        ],
        skip:
          filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0,
        take: filter.limit ? +filter.limit : undefined,
      });

      const totalCount = await prisma.debitCreditMemo.count({
        where: condition,
      });

      const data = {
        totalCount,
        debitCreditMemos: debitCreditMemos.map(({ readBy, ...rest }) => ({
          ...rest,
          isRead: IsdRead(readBy||"", filter.user?.id || 0),
        })),
      };

      return data;
    } catch (error) {
      return error;
    }
  },
  seedDebitCreditMemos: async () => {
    try {
      const debitCreditMemos = [...Array(100)].map((_, index) => ({
        id: index + 1,
        debitCreditMemoNumber: `dcm-${faker.date.past().getTime()}`,
        referenceNumber: `ref-${faker.date.anytime().getTime()}`,
        particular: faker.lorem.paragraph(),
        debitCreditMemoStatus:
          Math.floor(Math.random() * 5) % 2 === 0 ? "declined" : "approved",
        documentNumber: `docn-${faker.date.anytime().getTime()}`,
        preparedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
        approvedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
        checkedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
        receivedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
        billTo: `${faker.person.firstName()} ${faker.person.lastName()}`,
        billingAddress: `${faker.location.buildingNumber()} ${faker.location.city()} ${faker.location.country()}`,
        total: (Math.floor(Math.random() * 5) + 1) * index,
        status: Math.floor(Math.random() * 5) % 2 === 0 ? "active" : "pending",
        checkAmount: faker.commerce.price(),
        postingType:
          Math.floor(Math.random() * 5) % 2 === 0 ? "on-time" : "delayed",
        documentDate: faker.date.between({
          from: Date.now(),
          to: "2024-12-31",
        }),
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        vendorId: Math.floor(Math.random() * 100) + 1,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
        readBy: "",
        warehouseLocationId: Math.floor(Math.random() * 100) + 1,
      }));

      await prisma.debitCreditMemo.deleteMany();
      return await prisma.debitCreditMemo.createMany({
        data: debitCreditMemos,
      });
    } catch (error) {
      return error;
    }
  },
  getDebitCreditMemo: async (args: {
    debitCreditMemoId: number;
    userId: number;
    role: string
  }) => {
    try {
      const debitCreditMemo = await prisma.debitCreditMemo.findUnique({
        where: {
          id: args.debitCreditMemoId,
        },
        select: {
          readBy: true,
        },
        
      });
      
      const { readBy, ...rest } = await prisma.debitCreditMemo.update({
        where: {
          id: args.debitCreditMemoId,
        },
        data: {
          readBy: appendReadBy({
            readBy: debitCreditMemo?.readBy,
            userId: args.userId,
          }),
        },
        include: {
          billingPos: {
            include: {
              billing: {
                select: {
                  billingNumber: true,
                }
              },
            },
          },
          subsidiary: true,
          vendor: true,
        },
        
      });
      const billing = await prisma.billingPo.findFirst({
        where: {
          debitCreditMemoId: args.debitCreditMemoId,
        },
        include: {
          billing: {
            select: {
              billingNumber: true,
            },
          },
        },
      });

      const data = {
        ...rest,
        isRead: IsdRead(readBy||"", args.userId),
        billingNumberss: billing
      };

      return data;
    } catch (error) {
      throw error;
    }
  },
  getStatuses: async () => {
    try {
      const statuses = await prisma.debitCreditMemo.findMany({
        select: {
          status: true,
        },
        distinct: ["status"],
      });

      return statuses.map((_) => _.status);
    } catch (error) {
      throw error;
    }
  },
  getPostingTypes: async () => {
    try {
      const postingTypes = await prisma.debitCreditMemo.findMany({
        select: {
          postingType: true,
        },
        distinct: ["postingType"],
      });

      return postingTypes.map((_) => _.postingType);
    } catch (error) {
      throw error;
    }
  },
};

export default debitCreditMemoController;
