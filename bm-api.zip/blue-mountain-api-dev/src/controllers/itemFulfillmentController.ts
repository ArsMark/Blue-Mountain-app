import { faker } from "@faker-js/faker";
import { ItemFulfillment, Prisma, PrismaClient, User } from "@prisma/client";
import config from "../utils/config";
import { pastDate } from "../utils/date";
import logger from "../utils/logger";
import { pushReadBy, readByCondition, getVendorIDs, appendReadBy } from "../utils/prismaCondition";
import { TFilter } from "../utils/validations/filterValidation";
import withVAT from "../utils/withVAT";

const prisma = new PrismaClient();

const itemFulfillmentController = {
  getItemFulfillments: async (
    filter: TFilter &
      Partial<
        Omit<ItemFulfillment, "isRead"> & {
          fulfillmentDate: string;
          pullOutDate: string;
          vendorName: string;
          isRead: "true" | "false";
          vraNumber: string;
          user: User;
        }
      >
  ) => {
    try {
      const q = filter.q;
      const qNum = /^[0-9]+$/.test(`${q}`) ? +`${q}` : undefined;
      const isVendor = filter.user?.role === "vendor";

      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });

      const userId = filter.user?.id;
      const parsedId = userId !== undefined ? parseInt(userId.toString()) : undefined;
      
      var vendorIds = undefined
      if (isVendor) {
        vendorIds = await getVendorIDs(parsedId) 
      }

      const condition: Prisma.ItemFulfillmentWhereInput = {
        vendorId: isVendor ? { in: vendorIds } : undefined,
        preparedBy: { contains: filter.preparedBy },
        approvedBy: { contains: filter.approvedBy },
        itemFulFillmentNumber: { contains: filter.itemFulFillmentNumber },
        documetStatus: { contains: filter.documetStatus },
        totalQuantity: filter.totalQuantity,
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        pullOutDate: filter.pullOutDate && {
          gte: new Date(`${filter.pullOutDate.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.pullOutDate.split(",")[1]}T23:59:59Z`),
        },
        fulfillmentDate: filter.fulfillmentDate && {
          gte: new Date(`${filter.fulfillmentDate.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.fulfillmentDate.split(",")[1]}T23:59:59Z`),
        },
        vendor: {
          name: {
            contains: filter.vendorName,
          },
        },
        lastModifiedDate: {
          gte: isVendor ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO) : undefined,
        },
        OR: [
          {
            vendor: {
              name: {
                contains: q,
              },
            },
          },
          { totalQuantity: qNum },
          {
            itemFulFillmentNumber: {
              contains: q,
            },
          },
        ],
        ...readBy,
      };

      const itemFulfillments = await prisma.itemFulfillment.findMany({
        where: condition,
        include: {
          vendor: true,
          subsidiary: true,
          warehouseLocation: true,
          vendorReturnAuthorization: true,
        },
        orderBy: [
          {
            lastModifiedDate: filter.sort || "desc",
          },
        ],
        skip:
          filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0,
        take: filter.limit ? +filter.limit : undefined,
      });

      const totalCount = await prisma.itemFulfillment.count({
        where: condition,
      });

      const data = {
        totalCount,
        itemFulfillments: itemFulfillments.map(({ readBy, ...rest }) => ({
          ...rest,
          isRead: readBy?.includes(`"${filter.user?.id}"`),
        })),
      };

      return data;
    } catch (error) {
      logger(error);
      return error;
    }
  },
  seedItemFulfillments: async () => {
    try {
      const itemFulfillments = [...Array(100)].map((_, index) => ({
        id: index + 1,
        itemFulFillmentNumber: `${faker.date.past().getTime()}`,
        preparedBy: faker.person.fullName(),
        approvedBy: faker.person.fullName(),
        totalQuantity: +(Math.floor(Math.random() * 10) + 1) * index + 1,
        documetStatus:
          Math.floor(Math.random() * 5) % 2 === 0 ? "active" : "pending",
        warehouseLocationId: Math.floor(Math.random() * 100) + 1,
        readBy: "",
        subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
        pullOutDate: faker.date.between({
          from: "2023-01-01",
          to: Date.now(),
        }),
        vendorReturnAuthorizationId: Math.floor(Math.random() * 100) + 1,
        fulfillmentDate: faker.date.between({
          from: Date.now(),
          to: "2024-01-01",
        }),
        vendorId: +Math.floor(Math.random() * 100) + 1,
        lastModifiedDate: faker.date.between({
          from: new Date("2022-01-01"),
          to: new Date("2023-12-31"),
        }),
      }));

      await prisma.itemFulfillment.deleteMany();
      return await prisma.itemFulfillment.createMany({
        data: itemFulfillments,
      });
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getItemFulfillment: async (args: {
    itemFulfillmentId: number;
    userId: number;
    role: string
  }) => {
    try {
      const itemFulfillment = await prisma.itemFulfillment.findUnique({
        where: {
          id: args.itemFulfillmentId,
        },
      });

      const { readBy, ...rest } = await prisma.itemFulfillment.update({
        where: {
          id: args.itemFulfillmentId,
        },
        data: {
          readBy: appendReadBy({
            userId: args.userId,
            readBy: itemFulfillment?.readBy
          }),
        },
        include: {
          subsidiary: true,
          vendor: true,
          warehouseLocation: true,
          vendorReturnAuthorization: {
            select: {
              vraNumber: true,
              warehouseLocation: {
                select: {
                  name: true,
                  address: true
                },
              },
            },
          },
          itemFulfillmentItems: {
            include: {
              item: true,
            },
          },
        },
      });
    
      const data = {
        ...rest,
        location: rest.vendorReturnAuthorization?.warehouseLocation?.name,
        siteAddress: rest.vendorReturnAuthorization?.warehouseLocation?.address,
        isRead: readBy?.includes(`"${args.userId}"`),
        itemFulfillmentItems: rest.itemFulfillmentItems.map((item) => ({
          ...item,
          grossNet: withVAT(+item.grossNet),
          totalAmount: withVAT(+item.totalAmount),
        })),
      };

      return data;
    } catch (error) {
      throw error;
    }
  },
  getDocumentStatuses: async () => {
    try {
      const documentStatuses = await prisma.itemFulfillment.findMany({
        select: {
          documetStatus: true,
        },
        distinct: ["documetStatus"],
      });

      return documentStatuses.map((_) => _.documetStatus);
    } catch (error) {
      throw error;
    }
  },
};

export default itemFulfillmentController;
