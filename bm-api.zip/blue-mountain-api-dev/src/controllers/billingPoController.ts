import { faker } from "@faker-js/faker";
import { BillingPo, Prisma, PrismaClient } from "@prisma/client";
import logger from "../utils/logger";
import { TFilter } from "../utils/validations/filterValidation";

const prisma = new PrismaClient();

const billingPoController = {
  getBillingPos: async (filter: TFilter & Partial<BillingPo>) => {
    try {
      const limit = filter.limit || 100;

      const condition: Prisma.BillingPoWhereInput = {
        type: filter.type,
        transactionNo: filter.transactionNo,
        grossAmount: filter.grossAmount ? +filter.grossAmount : undefined,
        taxAmount: filter.taxAmount ? +filter.taxAmount : undefined,
        netAmount: filter.netAmount ? +filter.netAmount : undefined,
        discount: filter.discount ? +filter.discount : undefined,
        total: filter.total ? +filter.total : undefined,
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
      };

      const billingPos = await prisma.billingPo.findMany({
        where: condition,
        include: {
          billing: true,
          subsidiary: true,
          debitCreditMemo: true,
        },
        orderBy: [
          {
            lastModifiedDate: filter.sort || "asc",
          },
        ],
        skip: filter.page ? limit * (filter.page - 1) : 0,
        take: +limit,
      });
      const totalCount = await prisma.billingPo.count({ where: condition });

      return { totalCount, billingPos };
    } catch (error) {
      return error;
    }
  },
  seedBiillingPos: async () => {
    try {
      const billingPos = [...Array(100)].map((_) => {
        const billingDCMID = Math.floor(Math.random() * 100) + 1;

        return {
          type: billingDCMID % 2 === 0 ? "bill" : "debit/credit",
          subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
          transactionNo: `${faker.date.anytime().getTime()}`,
          grossAmount: faker.commerce.price(),
          taxAmount: +faker.commerce.price() / 0.12,
          netAmount: +faker.commerce.price() / 0.8,
          discount: +faker.commerce.price() / 0.15,
          total: +faker.commerce.price() / 0.9,
          ...(billingDCMID % 2 === 0
            ? { billingId: billingDCMID }
            : { debitCreditMemoId: billingDCMID }),
          lastModifiedDate: faker.date.between({
            from: new Date("2022-01-01"),
            to: new Date("2023-12-31"),
          }),
          itemId: Math.floor(Math.random() * 100) + 1,
          billingId: Math.floor(Math.random() * 100) + 1,
        };
      });

      await prisma.billingPo.deleteMany();
      return await prisma.billingPo.createMany({ data: billingPos });
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getBillingPo: async (billingPoId: number) => {
    return await prisma.billingPo.findUnique({
      where: {
        id: billingPoId,
      },
      include: {
        subsidiary: true,
        billing: true,
        debitCreditMemo: true,
      },
    });
  },
};

export default billingPoController;
