import { faker } from "@faker-js/faker";
import { Prisma, PrismaClient, PurchaseOrder, User } from "@prisma/client";
import config from "../utils/config";
import { pastDate } from "../utils/date";
import logger from "../utils/logger";
import { pushReadBy, readByCondition, getVendorIDs, checkIsRead, appendReadBy, IsdRead } from "../utils/prismaCondition";
import {
  TFilter,
  amountFormat,
  numberFormat,
} from "../utils/validations/filterValidation";
import withVAT from "../utils/withVAT";
import { equal } from "joi";

type TPurchaseOrder = Omit<
  PurchaseOrder,
  "netsuiteId" | "createdAt" | "updatedAt"
>;

const prisma = new PrismaClient();

const parsePrismaDecimal = (value: number) => new Prisma.Decimal(value);
function roundToTwoDecimals(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}
function roundToNearestInteger(value: number): number {
  // Round the value using Math.round() to the nearest integer
  return Math.round(value);
}

const purchaseOrderController = {
  getPurchaseOrders: async (
    filter: TFilter &
      Partial<
        Omit<PurchaseOrder, "isRead"> & {
          deliveryDateRange: string;
          poDateRange: string;
          vendorName: string;
          isRead: "true" | "false";
          user: User;
        }
      >
  ) => {

    console.log(filter)
    try {
      const q = filter.q;
      const qNum = numberFormat.test(`${q}`) ? +`${q}` : undefined;
      const qAmount = amountFormat.test(`${q}`)
        ? +`${q?.replace(",", "")}`
        : undefined;
      const isVendor = filter.user?.role === "vendor";
      const status = ['Pending Supervisor Approval', 'Rejected by Supervisor']
      const readBy = readByCondition({
        isRead: filter.isRead,
        userId: filter.user?.id,
      });
      
      const userId = filter.user?.id;
      const parsedId = userId !== undefined ? parseInt(userId.toString()) : undefined;
      var vendorIds = undefined
      
      if (isVendor) {
        vendorIds = await getVendorIDs(parsedId) 
      }
      const poDate: Prisma.DateTimeFilter = {};
      const condition: Prisma.PurchaseOrderWhereInput = {
        vendorId: isVendor ? { in: vendorIds } : undefined,
        poNumber: { contains: filter.poNumber },
        preparedBy: { contains: filter.preparedBy },
        checkedBy: { contains: filter.checkedBy },
        remarks: { contains: filter.remarks },
        approvedBy: { contains: filter.approvedBy },
        shippingAddress: { contains: filter.shippingAddress },
        terms: { contains: filter.terms },
        documentStatus: {
          contains: filter.documentStatus,
          ...(isVendor && { notIn: status }),
        },
        totalQuantity: filter.totalQuantity ? +filter.totalQuantity : undefined,
        status: { contains: filter.status },
        warehouseLocationId: filter.warehouseLocationId ? +filter.warehouseLocationId : undefined,
        location: { contains: filter.location },
        totalCases: filter.totalCases ? +filter.totalCases : undefined,
        deliveryArea: { contains: filter.deliveryArea },
        subsidiaryId: filter.subsidiaryId ? +filter.subsidiaryId : undefined,
        deliveryDate: filter.deliveryDateRange && {
          gte: new Date(`${filter.deliveryDateRange.split(",")[0]}T00:00:00Z`),
          lte: new Date(`${filter.deliveryDateRange.split(",")[1]}T23:59:59Z`),
        },
        poDate: {
          gte: filter.poDateRange
            ? new Date(`${filter.poDateRange.split(",")[0]}T00:00:00Z`)
            : isVendor
            ? pastDate(+config.VENDOR.RESULTS_DAYS_AGO)
            : undefined,
          lte: filter.poDateRange
            ? new Date(`${filter.poDateRange.split(",")[1]}T23:59:59Z`)
            : undefined,
        },
        vendor: {
          name: {
            contains: filter.vendorName,
          },
        },
        OR: [
          {
            poNumber: {
              contains: q,
            },
          },
          {
            vendor: {
              name: {
                contains: q,
              },
            },
          },
          {
            totalQuantity: qNum,
          },
          {
            status: {
              contains: q,
            },
          },
          {
            warehouseLocation: {
              address: {
                contains: q,
              },
            },
          },
          {
            documentStatus: {
              contains: q,
            },
          },
        ],
        ...readBy,
      };      
      
      const purchaseOrders = await prisma.purchaseOrder.findMany({
        where: condition,
        include: {
          vendor: true,
          subsidiary: true,
          warehouseLocation: true,
          purchaseOrderItems: true,
        },
        orderBy: [
          {
            poDate: filter.sort || "desc",
          },
        ],
        skip:
          filter.page && filter.limit ? filter.limit * (filter.page - 1) : 0,
        take: filter.limit ? +filter.limit : undefined,
      });
      const totalCount = await prisma.purchaseOrder.count({ where: condition });

      const data = {
        totalCount,
        purchaseOrders: purchaseOrders.map(
          ({ readBy, purchaseOrderItems, ...rest }) => {
            const totalAmount = purchaseOrderItems.reduce((acc, cur) => {
              const amount = withVAT(+cur.cost) * cur.quantity;
              return Math.round((amount + acc) * 100) / 100;
            }, 0);

            return {
              ...rest,
              isRead: IsdRead(readBy|| "", filter.user?.id || 0),
              totalAmount,
            };
          }
        ),
      };

      return data;
    } catch (error) {
      logger(error);
      return error;
    }
  },
  getPurchaseOrder: async (args: {
    purchaseOrderId: number;
    userId: number;
    role: string
  }) => {
    try {
      const purchaseOrder = await prisma.purchaseOrder.findUnique({
        where: {
          id: args.purchaseOrderId,
        },
        select: {
          readBy: true,
          grandTotal: true,
        },
      });

      const newList = appendReadBy({ readBy: purchaseOrder?.readBy, userId: args.userId });

      const { readBy, purchaseOrderItems, ...rest } =
        await prisma.purchaseOrder.update({
          where: {
            id: args.purchaseOrderId,
          },
          data: {
            readBy: newList
          },
          include: {
            subsidiary: true,
            vendor: true,
            purchaseOrderItems: true,
          },
        });

        

      
      const modalTotalAmount = purchaseOrderItems.reduce(
        (acc, cur) => acc + roundToNearestInteger(withVAT(+cur.cost)) * cur.quantity,
        0
      );
      // const totalTradeDiscount = rest.totalTradeDiscount.toNumber();
      // const totalCentralDropDiscrount = rest.totalCentralDropDiscrount.toNumber()
      // const totalCentralTlcDiscount = rest.totalCentralTlcDiscount.toNumber()
      // const totalOtherSpecialDiscount = rest.totalOtherSpecialDiscount.toNumber()
      // const totalDiscount =
      // totalTradeDiscount +
      //   totalCentralDropDiscrount +
      //   totalCentralTlcDiscount +
      //   totalOtherSpecialDiscount;

      // const grandTotal = modalTotalAmount + totalDiscount;
      const data = {
        ...rest,
        isRead: readBy?.includes(`${args.userId}`),
        purchaseOrderItems: purchaseOrderItems.map((item) => ({
          ...item,
          cost: withVAT(+item.cost),
          amount: roundToNearestInteger(withVAT(+item.amount)),
        })),
        totalAmount: modalTotalAmount,
        grandTotal:  purchaseOrder?.grandTotal,
      };

      return data;
    } catch (error) {
      throw error;
    }
  },
  getDocumentStatuses: async (role: string ) => {
    try {
      // isVendor
      const status = ['Pending Supervisor Approval', 'Rejected by Supervisor'];
      let documentStatuses = null;

      if (role === 'admin') {
        documentStatuses = await prisma.purchaseOrder.findMany({
          select: {
            documentStatus: true,
          },
          distinct: ["documentStatus"],
        });
      } else {
        documentStatuses = await prisma.purchaseOrder.findMany({
          where: {
            documentStatus: {
              notIn: status,
            },
          },
          select: {
            documentStatus: true,
          },
          distinct: ["documentStatus"],
        });
      }
      
      return documentStatuses?.map((_) => _.documentStatus);
    } catch (error) {
      throw error;
    }
  },
  getStatuses: async () => {
    try {
      const statuses = await prisma.purchaseOrder.findMany({
        select: {
          status: true,
        },
        distinct: ["status"],
      });

      return statuses.map((_) => _.status);
    } catch (error) {
      throw error;
    }
  },
  // seedPurchaseOrders: async () => {
  //   try {
  //     const purchaseOrders: TPurchaseOrder[] = [...Array(100)].map(
  //       (_, index) => ({
  //         id: index + 1,
  //         poNumber: `${faker.date.past().getTime()}`,
  //         poDate: faker.date.recent(),
  //         deliveryDate: faker.date.soon(),
  //         deliveryArea: `${faker.location.buildingNumber()} ${faker.location.city()} ${faker.location.country()} ${faker.location.zipCode()}`,
  //         totalCases: parsePrismaDecimal(Math.floor(Math.random() * 100) + 11),
  //         totalQuantity: +Math.floor(Math.random() * 1000) + 101,
  //         status: Math.floor(Math.random() * 10) % 2 === 0 ? "old" : "new",
  //         location: `${faker.location.buildingNumber()} ${faker.location.city()} ${faker.location.country()} ${faker.location.zipCode()}`,
  //         documentStatus:
  //           Math.floor(Math.random() * 10) % 2 === 0 ? "old" : "new",
  //         terms: faker.lorem.paragraph(),
  //         shippingAddress: `${faker.location.buildingNumber()} ${faker.location.city()} ${faker.location.country()} ${faker.location.zipCode()}`,
  //         totalAmount: parsePrismaDecimal(
  //           Math.floor(Math.random() * 10000) + 1001
  //         ),
  //         subTotal: parsePrismaDecimal(
  //           Math.floor(Math.random() * 10000) + 1001
  //         ),
  //         remarks: faker.lorem.sentence(),
  //         preparedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
  //         checkedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
  //         approvedBy: `${faker.person.firstName()} ${faker.person.lastName()}`,
  //         subsidiaryId: +(Math.floor(Math.random() * 10) % 2 === 0) + 1,
  //         vendorId: index + 1,
  //         totalTradeDiscount: parsePrismaDecimal(+faker.commerce.price()),
  //         totalCentralDropDiscrount: parsePrismaDecimal(
  //           +faker.commerce.price()
  //         ),
  //         totalCentralTlcDiscount: parsePrismaDecimal(+faker.commerce.price()),
  //         totalOtherSpecialDiscount: parsePrismaDecimal(
  //           +faker.commerce.price()
  //         ),
  //         warehouseLocationId: Math.floor(Math.random() * 100) + 1,
  //         lastModifiedDate: faker.date.between({
  //           from: new Date("2022-01-01"),
  //           to: new Date("2023-12-31"),
  //         }),
  //         vat: parsePrismaDecimal(+faker.commerce.price()),
  //         grandTotal: parsePrismaDecimal(+faker.commerce.price()),
  //         readBy: "",
  //       })
  //     );

  //     await prisma.purchaseOrder.deleteMany();
  //     return await prisma.purchaseOrder.createMany({ data: purchaseOrders });
  //   } catch (error) {
  //     logger(error);
  //     return error;
  //   }
  // },
};

export default purchaseOrderController;
