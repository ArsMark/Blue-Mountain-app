import { Request, Response, NextFunction } from "express";
import logger from "../utils/logger";
import {
  TokenName,
  verifyAccessToken,
  verifyrRefreshedAccessToken,
} from "../utils/token";

const verifyUser = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader?.replace("Bearer", "").trim();

  if (!token) return res.sendStatus(401);

  verifyAccessToken(token)
    .then((user: any) => {
      req.body = { ...req.body, ...user };
      req.user = user;
      next();
    })
    .catch((error) => {
      logger(error);

      verifyrRefreshedAccessToken(`${req.cookies?.[TokenName.refreshedToken]}`)
        .then((user: any) => {
          req.body = { ...req.body, ...user };
          req.user = user;
          next();
        })
        .catch((error) => {
          logger(error);
          return res.sendStatus(403);
        });
    });
};

export default verifyUser;
