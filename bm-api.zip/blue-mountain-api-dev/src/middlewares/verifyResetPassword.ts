import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import config from "../utils/config";

const verifyResetPassword = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader?.replace("Bearer", "").trim();

  if (!token) return res.sendStatus(401);

  jwt.verify(
    token,
    `${config.RESET_PASSWORD_TOKEN_SECRET}`,
    (err, user: any) => {
      if (err) return res.sendStatus(403);

      req.body = { ...req.body, ...user };
      next();
    }
  );
};

export default verifyResetPassword;
