import { Request, Response, NextFunction } from "express";

const verifyRole = (roles: Array<"admin" | "developer" | "employee">) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const role = req.body?.role;

    roles.includes(role)
      ? next()
      : res
          .status(403)
          .send(
            `Account must be ${
              roles.length > 1 &&
              roles.slice(0, roles.length - 1).join(", ") + "or"
            } ${roles[roles.length - 1] || ""}`
          );
  };
};

export default verifyRole;
