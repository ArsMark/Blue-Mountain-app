import { User } from "@prisma/client";
import { hashSync } from "bcrypt";

const users: Array<
  Pick<User, "email" | "password" | "firstName" | "lastName" | "role">
> = [
  {
    email: "admin@bm.com",
    password: hashSync("admin123", 12),
    firstName: "John",
    lastName: "Doe",
    role: "admin",
  },
  {
    email: "employee@bm.com",
    password: hashSync("employee123", 12),
    firstName: "Mary Jane",
    lastName: "Smith",
    role: "employee",
  },
];

export default users;
