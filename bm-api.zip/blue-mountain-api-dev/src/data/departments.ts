import { Department } from "@prisma/client";

const departments: Array<Pick<Department, "email" | "name">> = [
  {
    name: "Marketing",
    email: "bmmarketing@bminc.com.ph",
  },
  {
    name: "Accounting",
    email: "bmaccounting@bminc.com.ph",
  },
  {
    name: "Purchasing",
    email: "bmpurchasing@bminc.com.ph",
  },
  {
    name: "Warehouse",
    email: "bmwarehouse@bminc.com.ph",
  },
  {
    name: "IT",
    email: "bmit@bminc.com.ph",
  },
];

export default departments;
