export enum notificationTypes {
  purchaseOrder = "purchase order",
  itemReceipt = "item receipt",
  vendorReturnAuthorization = "vendor return authorization",
  itemFulfillment = "item fulfillment",
  billing = "billing",
  payment = "payment",
  debitCreditMemo = "debit credit memo",
}
