import { Queue } from "bullmq"; // Ensure BullMQ is imported correctly

const connection = { host: "127.0.0.1", port: 6379 };
const jobQueue = new Queue("jobQueue", { connection });

/**
 * Add a job to the queue
 * @param jobName - Unique job type
 * @param data - Payload for the job
 */
export const addJobToQueue = async (jobName: string, data: Record<string, any> = {}) => {
    await jobQueue.add(jobName, data);
    console.log(`Added job: ${jobName}`);
};

export { jobQueue };
