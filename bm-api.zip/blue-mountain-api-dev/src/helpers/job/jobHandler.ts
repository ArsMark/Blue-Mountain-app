import { getBillingData } from "../../utils/service/fetchBillingData";
import { getPaymentData } from "../../utils/service/fetchPaymentData";

import { getPurchaseOrderData } from "../../utils/service/fetchPurchaseOrderData";


interface JobHandlers {
    [key: string]: (data?: Record<string, any>) => Promise<void>;
}

const jobHandlers: JobHandlers = {
    pullBillingData: async () => {
        console.log("Pulling billing data...");

        try {
            const response = await getBillingData()
            console.log("The JOB IS DONE")
        } catch (error) {
            console.error("Error pulling billing data:", error);
        }
    },
    pullPaymentData: async()=>{
        console.log("Pulling payment data...")
        try {
            const response = await getPaymentData()
            console.log("The JOB IS DONE")
        } catch (error) {
            console.error("Error pulling billing data:", error);
        }
    },
    pullPurchaseOrderData: 
    async()=>{
        console.log("Pulling purchase order data...")
        try {
            const response = await getPurchaseOrderData()
            console.log("The JOB IS DONE")
        } catch (error) {
            console.error("Error pulling billing data:", error);
        }
    }

    

};

export default jobHandlers;
