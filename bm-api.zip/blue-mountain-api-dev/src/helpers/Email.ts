import { createTransport } from "nodemailer";
import { MailOptions } from "nodemailer/lib/sendmail-transport";
import config from "../utils/config";

class Email {
  public async send(mailOptions: MailOptions) {
    try {
      const transporter = createTransport({
        service: "gmail",
        host: "smtp.gmail.com",
        port: 587,
        secure: true,
        auth: {
          user: config.SYSTEM_EMAIL,
          pass: config.SYSTEM_PASSWORD,
        },
      });

      return await transporter.sendMail(mailOptions);
    } catch (error) {
      throw error;
    }
  }
}

export default Email;
