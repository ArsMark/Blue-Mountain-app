import { Worker, Job } from "bullmq";
import jobHandlers from "../job/jobHandler";
const connection = { host: "127.0.0.1", port: 6379 };

const worker = new Worker(
    "jobQueue",
    async (job: Job) => {
        console.log(`Processing job: ${job.name}`);


        console.log("Available Handlers:", Object.keys(jobHandlers));

        if (jobHandlers[job.name]) {
            await jobHandlers[job.name](job.data);
            console.log(`Job "${job.name}" completed.`);
        } else {
            console.error(`No handler found for job: ${job.name}`);
        }
    },
    { connection }
);

console.log("Worker is running...");
