import "dotenv/config";

const config = {
  PORT: process.env.PORT,
  ENVIRONMENT: process.env.ENVIRONMENT,
  TOKEN_SECRET: process.env.TOKEN_SECRET,
  REFRESH_TOKEN_SECRET: process.env.REFRESH_TOKEN_SECRET,
  SENDGRID_API_KEY: process.env.SENDGRID_API_KEY,
  NETSUITE_CONFIG: {
    consumer_key: process.env.NETSUITE_CONSUMER_KEY,
    consumer_secret_key: process.env.NETSUITE_CONSUMER_SECRET,
    token: process.env.NETSUITE_ACCESS_TOKEN,
    token_secret: process.env.NETSUITE_TOKEN_SECRET,
    realm: process.env.NETSUITE_REALM,
  },
  SYSTEM_EMAIL: process.env.SYSTEM_EMAIL,
  SYSTEM_PASSWORD: process.env.SYSTEM_PASSWORD,
  RESET_PASSWORD_TOKEN_SECRET: process.env.RESET_PASSWORD_TOKEN_SECRET,
  TIME_ZONE: process.env.TIME_ZONE,
  VENDOR: {
    RESULTS_DAYS_AGO: process.env.RESULTS_DAYS_AGO || -365,
  },
  BUSINESS: {
    VAT_RATE: +`${process.env.VAT_RATE}`,
  },
};

export default config;
