import config from "./config";
import jwt from "jsonwebtoken";

export enum TokenName {
  refreshedToken = "refreshedToken",
  accessToken = "accessToken",
}

export const generateAccessToken = (payload: any) => {
  return jwt.sign(payload, `${config.TOKEN_SECRET}`, { expiresIn: "12h" });
};

export const generateRefreshedAccessToken = (payload: any) => {
  return jwt.sign(payload, `${config.REFRESH_TOKEN_SECRET}`, {
    expiresIn: "7d",
  });
};

export const verifyAccessToken = (accessToken: string) => {
  return new Promise((resolve, reject) => {
    jwt.verify(`${accessToken}`, `${config.TOKEN_SECRET}`, (error, user) => {
      if (error) return reject("Invalid access token");

      resolve(user);
    });
  });
};

export const verifyrRefreshedAccessToken = (refreshedAccessToken: string) => {
  return new Promise((resolve, reject) => {
    jwt.verify(
      `${refreshedAccessToken}`,
      `${config.REFRESH_TOKEN_SECRET}`,
      (error, user) => {
        if (error) return reject("Invalid refreshed access token");

        resolve(user);
      }
    );
  });
};
