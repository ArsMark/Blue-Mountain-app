import Joi, { ValidationError } from "joi";

export const isValidationError = (error: any) => {
  return error instanceof ValidationError;
};

export const validateSchema = async (schema: Joi.ObjectSchema) => {
  return await schema.validateAsync(schema, { abortEarly: false });
};
