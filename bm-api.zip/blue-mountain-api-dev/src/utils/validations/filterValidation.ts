import Joi from "joi";

export type TFilter = Partial<{
  page: number;
  limit: number;
  sort: "asc" | "desc";
  q: string;
  creationDateRange: string;
}>;

export const dateRangeFormat =
  /^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$/;

export const amountFormat = /^[0-9]+(?:,[0-9]{3})*(?:\.[0-9]+)?$/;

export const numberFormat = /^[0-9]+$/;

export const validateFilter = async (data: any, extend?: Joi.ObjectSchema) => {
  let schema = Joi.object({
    page: Joi.number().min(1),
    limit: Joi.number().min(1).when("page", {
      is: Joi.exist(),
      then: Joi.required(),
    }),
    sort: Joi.string().regex(/^asc|desc$/, `"asc" or "desc"`),
    q: Joi.string(),
    creationDateRange: Joi.string().regex(
      dateRangeFormat,
      `"yyyy-mm-dd,yyyy-mm-dd"`
    ),
  });

  if (extend) schema = schema.concat(extend);

  return await schema.validateAsync(data, { abortEarly: false });
};
