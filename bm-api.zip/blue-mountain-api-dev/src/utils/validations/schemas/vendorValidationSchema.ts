import Joi from "joi";

export const vendorValidationSchema = {
  createVendor: Joi.object({
    name: Joi.string().required(),
    netsuiteId: Joi.number().required(),
  }),
};
