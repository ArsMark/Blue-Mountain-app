import { User } from "@prisma/client";
import Joi from "joi";

export const validateLogin = async (data: Pick<User, "email" | "password">) => {
  const schema = Joi.object({
    email: Joi.string().required().email(),
    password: Joi.string().required(),
  });

  return await schema.validateAsync(data, { abortEarly: false });
};
