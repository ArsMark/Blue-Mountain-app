import { stringify } from "csv-stringify";
import { Response } from "express";

type TProps = {
  response: Response;
  data: Array<Record<string, unknown>>;
  filename: string;
};

const csv = (props: TProps) => {
  try {
    const stringifiedCSV = stringify(props.data, {
      header: true,
      cast: {
        date: (value) => value.toLocaleDateString(),
      },
    });

    props.response.setHeader("Content-Type", "text/csv");
    props.response.setHeader(
      "Content-Disposition",
      `attachment; filename="${props.filename}_${Date.now()}.csv"`
    );

    return stringifiedCSV.pipe(props.response);
  } catch (error) {
    throw error;
  }
};

export default csv;
