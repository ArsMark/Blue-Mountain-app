export const pastDate = (addDays: number) => {
  const date = new Date();
  date.setDate(date.getDate() - addDays);

  return date;
};
