import { func } from "joi";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

export const readByCondition = (args: {
  isRead?: "true" | "false";
  userId?: number;
}) => {
  const readCondition = {
    readBy: {
      contains: `/${args.userId}/`,
    },
  };
  const unreadCondition = {
    OR: [
      {
        readBy: {
          not: {
            contains: `/${args.userId}/`,
          },
        },
      },
      {
        readBy: null,
      },
    ],
  };

  if (args.isRead === undefined) return {};

  
  return args.isRead === "true" ? readCondition : unreadCondition;
};



export function checkIsRead(readBy: any){
  return readBy != null ? true : false
}

export function IsdRead(readBy: string, userId:number){
  const readByList = readBy.split("-")

  return readByList.includes(`/${userId}/`)
}
export const pushReadBy = (args: {
  readBy?: string | null,
  userId: number,
  role: string
}) => {
  const readByIds = `${args.readBy}`.split(",");
  if (readByIds[0] == 'null' && args.role != 'vendor') {
    return undefined;
  }

  return !readByIds?.length ? `,"${args.userId}"` : `"${args.userId}"`;
};


export const appendReadBy = (args: {
  readBy?: string | null,
  userId: number,
}) => {
  const readByIds = args.readBy ? `${args.readBy}`.split("-") : [];

  console.log(readByIds)

  if (readByIds.includes(`/${args.userId}/`)) {
    return args.readBy
    
  }

  
  readByIds.push(`/${args.userId}/`)
  const list = readByIds.join("-")

  return list;
};

export async function getVendorIDs(userID: any) {
  const currentUserId = parseInt(userID)

  const vendorIDs = await prisma.userVendor.findMany({
    where: {userId: currentUserId },
    select: {
      vendorId: true,
    },
  });
  
  return vendorIDs.map(record => record.vendorId);
}
