import config from "./config";

const withVAT = (amount: number) => {
  return amount * config.BUSINESS.VAT_RATE + amount;
};

export default withVAT;
