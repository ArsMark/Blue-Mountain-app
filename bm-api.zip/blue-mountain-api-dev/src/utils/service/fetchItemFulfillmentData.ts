import config from "../config";
import { PrismaClient, ItemFulfillment } from "@prisma/client";

const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";
import { findItem } from "./fetchItemData";
import { findVendorReturnAuthorization } from "./fetchVendorReturnAuthorizationData";
import { processVRAData } from "./getVRAData";

const prisma = new PrismaClient();
const limit = 500;

export const getItemFulfillmentData = async () => {
  const existingRecords = await prisma.itemReceipt.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = "";
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  // query = '&q=lastModifiedDate after "05/31/2024"';
  var response = await NsApi.request({
    path: "record/v1/itemFulfillment?limit=" + limit + query,
  });

  const records = response.data.items;
  console.log(query, 'getItemFulfillmentData', records.length)
  await processData(
    records,
    query,
    response.data.hasMore,
    response.data.links[0].href,
    1
  );

  return true;
};

const processData = async (
  records: string[] | any[],
  query: string,
  hasMore: boolean,
  link: string,
  page: number
) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse;
    refetch1: try {
      newResponse = await NsApi.request({
        path: "record/v1/itemFulfillment/" + records[x].id,
      });
    } catch (err) {
      break refetch1;
    }
    
    if (newResponse.data) {
      if (newResponse.data.orderType == "VendAuth") {
        var subsidiaryId: any = await findSubsidiary(
          null,
          parseInt(newResponse.data.subsidiary.id)
        );
        var locationId: any = newResponse.data.location
          ? await findLocation(null, parseInt(newResponse.data.location.id))
          : null;
        var vendorId: any = newResponse.data.entity
          ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null))
          : null;
        var vra: any = await findVendorReturnAuthorization(
          null,
          parseInt(newResponse.data.createdFrom?.id ?? null)
        );
        if (!vra && subsidiaryId) {
          vra = await processVRAData(newResponse.data.orderId)
        }
        console.log(newResponse.data.id, 'vra', vra.pullOutDate)
        var data = {
          netsuiteId: parseInt(newResponse.data.id),
          fulfillmentDate: newResponse.data.tranDate ? new Date(newResponse.data.tranDate) : null,
          itemFulFillmentNumber: newResponse.data.tranId,
          documetStatus: "",
          preparedBy: newResponse.data.custbody_all_preparedby ?? "",
          approvedBy: "", // Need To Update,
          totalQuantity: 0,
          srsNo: newResponse.data.custbody_inventryadjstment_srsref,
          pullOutDate: vra.pullOutDate,
          createdAt: new Date(newResponse.data.createdDate),
          vendorId: vendorId,
          subsidiaryId: subsidiaryId,
          warehouseLocationId: locationId,
          vendorReturnAuthorizationId: vra?.id ?? 0,
          lastModifiedDate: new Date(newResponse.data.lastModifiedDate),
        };
  
        var itemfulfillment = await prisma.itemFulfillment.findFirst({
          where: { netsuiteId: parseInt(records[x].id) },
        });
        if (itemfulfillment) {
          itemfulfillment = await prisma.itemFulfillment.update({
            where: { id: itemfulfillment?.id },
            data: data,
          });
          console.log('updated', data.fulfillmentDate)
        } else {
          itemfulfillment = await prisma.itemFulfillment.create({
            data: data,
          });
          console.log(
            "{ \n VRA Number:" +
              newResponse.data.tranId +
              " \n ID: " +
              newResponse.data.id +
              " \n Created Date: " +
              newResponse.data.createdDate +
              " \n Order Type: " +
              newResponse.data.orderType +
              " \n }"
          );
        }
  
        if (vra) {
          await prisma.vendorReturnAuthorization.update({
            where: { id: vra?.id ?? 0 },
            data: {
              itemFulFillmentNumber: newResponse.data.tranId,
              // pullOutDate: new Date(newResponse.data.pickedDate ?? null), //as per client, no need to update this field
            },
          });
        }
  
        var itemPath = "record/v1/itemFulfillment/" + records[x].id + "/item";
        var items;
        refetch2: try {
          items = await NsApi.request({
            path: itemPath,
          });
        } catch (err) {
          break refetch2;
        }
  
        var processItemRecord = await processItemData(
          items.data.items,
          itemPath,
          itemfulfillment
        );
  
        await prisma.itemFulfillment.update({
          where: { id: itemfulfillment?.id },
          data: {
            totalQuantity: processItemRecord.totalQuantity,
          },
        });
      }
    }
    
  }
  if (hasMore) {
    var response;
    refetch4: try {
      response = await NsApi.request({
        path:
          "record/v1/itemFulfillment?limit=" +
          limit +
          "&offset=" +
          page * limit +
          query,
      });
      records = response.data.items;
    } catch (err) {
      break refetch4;
    }

    records = response.data.items;
    await processData(
      records,
      query,
      response.data.hasMore,
      response.data.links[0].href,
      page + 1
    );
  }
};

const processItemData = async (
  records: string[] | any[],
  url: string,
  itemfulfillment: ItemFulfillment
) => {
  var totalQuantity = 0;

  await prisma.itemFulfillmentItem.deleteMany({
    where: {
      itemFulfillmentId: itemfulfillment.id,
    },
  });

  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf("/") + 1);

    var newResponse;
    refetch3: try {
      newResponse = await NsApi.request({
        path: url + "/" + id,
      });
    } catch (err) {
      console.log(err);
      break refetch3;
    }

    var item = newResponse.data;
    var itemData: any = await findItem(null, parseInt(item.item.id));
    var data = {
      netsuiteId: 0,
      itemId: itemData?.id ?? null,
      grossNet: item.itemUnitPrice ?? 0,
      quantity: item.quantity ?? 0,
      totalAmount: item.itemFxAmount ?? 0,
      itemFulfillmentId: itemfulfillment.id,
      subsidiaryId: itemfulfillment.subsidiaryId,
      lastModifiedDate: itemfulfillment.lastModifiedDate,
    };

    totalQuantity += parseFloat(item.quantity ?? 0);

    await prisma.itemFulfillmentItem.create({
      data: data,
    });
  }

  return {
    totalQuantity: totalQuantity,
  };
};
