import config from "../config";
import { PrismaClient } from "@prisma/client";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const prisma = new PrismaClient();

export const processItemNesuite = async (netsuiteId: number ) => {

    var newResponse = null;
    refetch1:
    try {
      newResponse = await NsApi.request({
        path: 'record/v1/inventoryitem/' + netsuiteId
      });
    } catch (err) {
      break refetch1
    }
   
    if (newResponse.data.itemId) {    
      var data = {
        barcode: newResponse.data.upcCode ?? '',
        name: newResponse.data.itemId,
        description: newResponse.data.itemId,
        lastModifiedDate: newResponse.data.lastModifiedDate,
        conversionToCase: newResponse.data.custitem_item_conversiontocase,
        cost: parseFloat(newResponse.data.cost ?? 0),
        netsuiteId: netsuiteId
      };
    
      var item = await prisma.item.findFirst({
        where: { netsuiteId: netsuiteId }
      });

      if (item) {
        await prisma.item.update({
          where: { id: item?.id },
          data: data
        });
      }
      else {
        await prisma.item.create({
          data: data,
        });
        console.log('Item created', netsuiteId)
      }
    }
    
    var finditem = await prisma.billing.findFirst({
      where: { netsuiteId: netsuiteId },
      select: {id: true}
    });
    
  return finditem
}





