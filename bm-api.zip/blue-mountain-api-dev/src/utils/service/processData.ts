import { getVendorData } from "./fetchVendorData";
import { getItemData } from "./fetchItemData";
import { getPurchaseOrderData } from "./fetchPurchaseOrderData";
import { getItemReceiptData } from "./fetchItemReceiptData";
import { getLocationData } from "./fetchLocationData";
import { getBillingData } from "./fetchBillingData";
import { getPaymentData } from "./fetchPaymentData";
import { getDebitCreditMemoData } from "./fetchDebitCreditMemoData";
import { getJournalEntryData } from "./fetchJournalEntry";
import { getVendorReturnAuthorizationData } from "./fetchVendorReturnAuthorizationData";
import { getItemFulfillmentData } from "./fetchItemFulfillmentData";

export const processData = async () => {

    let response = await getVendorData();
    response = await getItemData();
    response = await getLocationData();
    response = await getPurchaseOrderData();
    response = await getItemReceiptData();
    response = await getBillingData();
    response = await getPaymentData();
    response = await getVendorReturnAuthorizationData();
    response = await getItemFulfillmentData();
    response = await getDebitCreditMemoData();
    response = await getJournalEntryData();
};