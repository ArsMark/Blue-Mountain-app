import config from "../config";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

export const processTransactionNo = async (netsuiteId: number ) => {

  var newResponse = null;

  const sqlQuery = `
    SELECT DISTINCT transactionnumber 
    FROM transaction th 
    JOIN transactionline tl 
    ON th.id = tl.transaction 
    WHERE th.id = ${netsuiteId}
  `;
  
  refetch1:
  try {
    newResponse = await NsApi.request({
      path: 'query/v1/suiteql',
      method: 'POST',
      headers: {
        'Prefer': 'transient',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        q: sqlQuery
      })
    });
    
    return newResponse.data.items[0].transactionnumber
  } catch (err) {
    console.error('Error fetching data:', err);
    break refetch1
    // Handle error appropriately, e.g., show a notification to the user
  }

   
}
