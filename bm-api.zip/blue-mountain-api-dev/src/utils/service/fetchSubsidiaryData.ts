import config from "../config";
import { PrismaClient } from "@prisma/client";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const prisma = new PrismaClient();
const limit = 1000;

export const getSubsidiaryData = async () => {

  const existingRecords = await prisma.subsidiary.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = '';
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  var response = await NsApi.request({
    path: 'record/v1/subsidiary?limit=' + limit + query
  });

  const records = response.data.items;

  await processData(records, query, response.data.hasMore, response.data.links[0].href, 1)

  return true;


};

const processData = async (records: string[] | any[], query: string, hasMore: boolean, link: string, page: number) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse = await NsApi.request({
      path: 'record/v1/subsidiary/' + records[x].id
    });
    if (newResponse.data.name) {

      var data = {
        name: newResponse.data.name,
        logo: '',
        lastModifiedDate: newResponse.data.lastModifiedDate,
        netsuiteId: parseInt(records[x].id)
      };

      var subsidiary = await prisma.subsidiary.findFirst({
        where: { netsuiteId: parseInt(records[x].id) }
      });
      if (subsidiary) {
        await prisma.subsidiary.update({
          where: { id: subsidiary?.id },
          data: data
        });
      }
      else {
        await prisma.subsidiary.create({
          data: data,
        });
      }

    }

  }
  if (hasMore) {
    var response = await NsApi.request({
      path: 'record/v1/subsidiary?limit=' + limit + '&offset=' + (page * limit) + query
    });
    records = response.data.items;
    await processData(records, query, response.data.hasMore, response.data.links[0].href, page + 1)
  }

}

export const findSubsidiary = async (url: string | null, id: number | null) => {

  var subsidiaryId = id;
  if (!subsidiaryId) {
    var netsuiteSubsidiary = await NsApi.request({
      path: url
    });

    netsuiteSubsidiary = netsuiteSubsidiary.data.items[0]
    subsidiaryId = parseInt(netsuiteSubsidiary.id)
  }
  var subsidiary = await prisma.subsidiary.findFirst({
    where: { netsuiteId: subsidiaryId }
  });


  return subsidiary?.id;

};