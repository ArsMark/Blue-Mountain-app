import config from "../config";
import { PrismaClient, DebitCreditMemo } from "@prisma/client";
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const prisma = new PrismaClient();
const limit = 100;

export const getJournalEntryData = async () => {

  const existingRecords = await prisma.debitCreditMemo.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = '';
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  
  // query = '&q=lastModifiedDate after "05/01/2024"';
  var response = await NsApi.request({
    path: 'record/v1/journalentry?limit=' + limit + query
  });

  const records = response.data.items;
  console.log(records.length, 'journalentry')
  await processData(records, query, response.data.hasMore, response.data.links[0].href, 1)

  return true;

};

const processData = async (records: string[] | any[], query: string, hasMore: boolean, link: string, page: number) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse = null;
    refetch1:
    try {
      newResponse = await NsApi.request({
        path: 'record/v1/journalentry/' + records[x].id
      });
    } catch (err) {
      break refetch1
    }
    if (newResponse.data.tranId) {

      console.log("{ \n Number:" + newResponse.data.tranId
        + " \n ID: " + newResponse.data.id
        + " \n Created Date: " + newResponse.data.createdDate
        + " \n }");

        var linePath = 'record/v1/journalentry/' + records[x].id + '/line'
        
        var linesNewResponse = null;
        refetch2:
        try {
          linesNewResponse = await NsApi.request({
            path: linePath
          });
        } catch (err) {
          break refetch2
        }

        let line_ids: string[] = [];
        linesNewResponse.data.items.forEach((item :any, index: number) => {
          const id = item.links[0].href.split('/').pop();
          line_ids.push(id)
        }); 
       
        var amount = await processItemData(linesNewResponse.data.items, linePath, newResponse);
        
        console.log(linePath + "/" + line_ids[0])
        var lineNewResponse = null;
        refetch4: try {
            lineNewResponse = await NsApi.request({
            path: linePath + "/" + line_ids[0],
          });
         
        } catch (err) {
          break refetch4;
        }
      
      var subsidiaryId: any = await findSubsidiary(null, parseInt(newResponse.data.subsidiary.id))
      var locationId: any = newResponse.data.location ? await findLocation(null, parseInt(newResponse.data.location?.id ?? null)) : null
      var vendorId: any = lineNewResponse.data?.entity ? await findVendor(null, parseInt(lineNewResponse.data.entity?.id ?? null)) : null
      // need transaction number
      var data = {
        documentDate: new Date(newResponse.data.tranDate),
        total: amount.debitAmount,
        documentNumber: newResponse.data.tranId,
        status: "",
        creditAmount: amount.creditAmount,
        checkAmount: amount.debitAmount ,
        postingType: amount.debitAmount < 0 ? 'Debit Memo' : 'Credit Memo',
        subsidiaryId: subsidiaryId,
        debitCreditMemoNumber: newResponse.data.tranId,
        particular: newResponse.data.memo ?? "",
        referenceNumber: newResponse.data.custbody_invntoryadjustment_extrnldocu ?? "", // need to update
        debitCreditMemoStatus: "", // need to update
        preparedBy: newResponse.data.custbody_all_preparedby ?? "",
        approvedBy: "",
        checkedBy: "",
        receivedBy: "",
        billTo: lineNewResponse.data.entity?.refName ?? "",
        billingAddress: lineNewResponse.data.billAddress ?? "",
        vendorId: vendorId,
        warehouseLocationId: locationId,
        netsuiteId: parseInt(newResponse.data.id),
        lastModifiedDate: new Date(newResponse.data.lastModifiedDate)
      };

      var journal = await prisma.debitCreditMemo.findFirst({
        where: { netsuiteId: parseInt(newResponse.data.id) }
      });

      if (journal) {
        await prisma.debitCreditMemo.update({
          where: { id: journal.id },
          data: data
        });
        console.log('journal updated', newResponse.data.id)
      }
      else {
        await prisma.debitCreditMemo.create({
          data: data,
        });
        console.log('journal created', newResponse.data.id)
      }

    }

  }
  if (hasMore) {
    var response = null;
    refetch3:
    try {
      response = await NsApi.request({
        path: 'record/v1/journalentry?limit=' + limit + '&offset=' + (page * limit) + query
      });
    } catch (err) {
      console.log(err);
      break refetch3
    }
    records = response.data.items;
    await processData(records, query, response.data.hasMore, response.data.links[0].href, page + 1)
  }

}

const processItemData = async (
  records: string[] | any[],
  url: string,
  debitCreditMemo: DebitCreditMemo
) => {
  var debit_amount = 0

  var credit_amount = 0
  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf("/") + 1);

    var newResponse;
    refetch3: try {
      newResponse = await NsApi.request({
        path: url + "/" + id,
      });
    } catch (err) {
      console.log(err);
      break refetch3;
    }

    var item = newResponse.data;
    credit_amount += item.credit ?? 0
    debit_amount += item.debit ?? 0
  }

  return {
    debitAmount: debit_amount,
    creditAmount: credit_amount
  };
};
