import config from "../config";

const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const fetchData = async (url: string) => {
  const response = await NsApi.request({
    path: url,
  });
  return response.data;
};

export default fetchData;
