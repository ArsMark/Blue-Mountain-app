import config from "../config";
import { PrismaClient } from "@prisma/client";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";
import { processApply } from "./netsuiteUpdates/updateDebitCreditMemo";
import { processTransactionNo } from "./getTransactionNo";

const prisma = new PrismaClient();
const limit = 1000;

export const getDebitCreditMemoData = async () => {

  const existingRecords = await prisma.item.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = '';
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  // query = '&q=lastModifiedDate after "07/01/2024"';
  var response = await NsApi.request({
    path: 'record/v1/vendorCredit?limit=' + limit + query
  });
  
  const records = response.data.items;
  console.log(query, 'getDebitCreditMemoData', records.length)
  await processData(records, query, response.data.hasMore, response.data.links[0].href, 1)

  return true;
};

const processData = async (records: string[] | any[], query: string, hasMore: boolean, link: string, page: number) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse = null;
    refetch1:
    try {
      newResponse = await NsApi.request({
        path: 'record/v1/vendorCredit/' + records[x].id
      });
    } catch (err) {
      break refetch1
    }
    if (newResponse.data) {
      var subsidiaryId: any = await findSubsidiary(null, parseInt(newResponse.data.subsidiary.id))
      var locationId: any = newResponse.data.location ? await findLocation(null, parseInt(newResponse.data.location?.id ?? null)) : null
      var vendorId: any = newResponse.data.entity ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null)) : null
      const trn_no = await processTransactionNo(parseInt(newResponse.data.id))
      // need transaction number
      var data = {
        documentDate: new Date(newResponse.data.tranDate),
        total: newResponse.data.total,
        documentNumber: trn_no,
        status: "",
        checkAmount: newResponse.data.total ?? 0,
        postingType: getPostingType(newResponse), // need to update
        subsidiaryId: subsidiaryId,
        debitCreditMemoNumber: newResponse.data.tranId,
        particular: newResponse.data.memo ?? "",
        referenceNumber: newResponse.data.tranId ?? "", // need to update
        debitCreditMemoStatus: "", // need to update
        preparedBy: newResponse.data.custbody_all_preparedby,
        approvedBy: "",
        checkedBy: "",
        receivedBy: "",
        billTo: newResponse.data.entity?.refName ?? "",
        billingAddress: newResponse.data.billAddress ?? "",
        vendorId: vendorId,
        warehouseLocationId: locationId,
        netsuiteId: parseInt(newResponse.data.id),
        lastModifiedDate: new Date(newResponse.data.lastModifiedDate)
      };

      var debitCreditmemo = await prisma.debitCreditMemo.findFirst({
        where: { netsuiteId: parseInt(records[x].id) }
      });
      if (debitCreditmemo) {
        debitCreditmemo =  await prisma.debitCreditMemo.update({
          where: { id: debitCreditmemo?.id },
          data: data
        });
      }
      else {
        debitCreditmemo =  await prisma.debitCreditMemo.create({
          data: data,
        });
        console.log("{ \n Number:" + newResponse.data.tranId
        + " \n ID: " + newResponse.data.id
        + " \n Created Date: " + newResponse.data.createdDate
        + " \n }");
      }
      const itemPath = 'record/v1/vendorCredit/' + debitCreditmemo.netsuiteId + '/apply';
        let items = null;
        refetch2:
        try {
          items = await NsApi.request({
            path: itemPath
          });
        } catch (err) {
          break refetch2;
        }
        await processApply(items.data.items, itemPath, debitCreditmemo.id);

    }
    
  }
  if (hasMore) {
    var response = null;
    refetch3:
    try {
      response = await NsApi.request({
        path: 'record/v1/vendorCredit?limit=' + limit + '&offset=' + (page * limit) + query
      });
    } catch (err) {
      console.log(err);
      break refetch3
    }
    records = response.data.items;
    await processData(records, query, response.data.hasMore, response.data.links[0].href, page + 1)
  }

}

function getPostingType(netsuite: { data: { tranId: string } }): string {
  const { tranId } = netsuite.data;

  return tranId.includes('DM') || tranId.includes('VRA')  ? 'Debit Memo' : 'Credit Memo';
}