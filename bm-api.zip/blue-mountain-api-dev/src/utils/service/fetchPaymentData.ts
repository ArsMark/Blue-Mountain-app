import { PrismaClient, Payment } from "@prisma/client";

import config from "../config";
import { findBilling } from "./fetchBillingData";
import { findItem } from "./fetchItemData";
import { findLocation } from "./fetchLocationData";
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { processBillData } from "./getBillData";
import { parse } from "path";
import { processItemData } from "./netsuiteUpdates/updatePayment";

const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const prisma = new PrismaClient();
const limit = 1000;

export const getPaymentData = async () => {
  const existingRecords = await prisma.payment.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = "";
  if (existingRecords.length) {
    var lastModifiedDate = new Date(
      existingRecords[0].lastModifiedDate
    ).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  // query = '&q=lastModifiedDate after "07/19/2024"';
  var response = await NsApi.request({
    path: "record/v1/vendorPayment?limit=" + limit + query,
  });
 
  const records = response.data.items;
  console.log(query, 'getPaymentData', records.length)
  await processData(
    records,
    query,
    response.data.hasMore,
    response.data.links[0].href,
    1
  );

  return true;
};

const processData = async (
  records: string[] | any[],
  query: string,
  hasMore: boolean,
  link: string,
  page: number
) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse = null;
    refetch1: try {
      newResponse = await NsApi.request({
        path: "record/v1/vendorPayment/" + records[x].id,
      });
    } catch (err) {
      break refetch1;
    }
    // console.log(newResponse.data)

    if (newResponse.data.tranId < 0) continue;

    if (newResponse.data.tranId) {
      var subsidiaryId: any = await findSubsidiary(
        null,
        parseInt(newResponse.data.subsidiary.id)
      );
      var locationId: any = newResponse.data.location
        ? await findLocation(null, parseInt(newResponse.data.location.id))
        : null;
      var vendorId: any = newResponse.data.entity
        ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null))
        : null;

      var paymentType = null;
      refetch2: try {
        paymentType = await NsApi.request({
          path: "record/v1/account/" + newResponse.data.account?.id,
        });
      } catch (err) {
        break refetch2;
      }

      paymentType = paymentType.data;
      let release_date = newResponse.data?.custbody15
      console.log('release_date', release_date)
      if (release_date) {
        const [month, day, year] = newResponse.data?.custbody15.split('/');
        if (year == '24') {
          release_date = parseDate(release_date)
        }else{
          release_date =  `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        }
        
      }
      
      console.log(release_date, newResponse.data.id)
      var data = {
        transactionNo: newResponse.data.tranId ?? "",
        cvNumber: newResponse.data.tranId ?? "",
        cvDate: new Date(newResponse.data?.tranDate ?? null),
        debitMemo: 0, // Need To Update
        creditMemo: 0, // Need To Update
        journal: 0, // Need To Update
        netAmount: 0, // Need To Update
        totalWithHoldingTax: 0, // Need To Update
        date: new Date(newResponse.data.tranDate ?? null),
        createdAt: new Date(newResponse.data.createdDate ?? null),
        amount: newResponse.data.total ?? "",
        releaseDate: new Date(release_date ?? newResponse.data.tranDate),
        currency: newResponse.data.currency?.refName ?? "",
        netsuiteId: parseInt(newResponse.data.id),
        paymentMethod: paymentType.acctType?.refName ?? "",
        bank: paymentType.acctName ?? "",
        checkNumber: newResponse.data.custbody_check_checknumber ?? null,
        vendorId: vendorId,
        subsidiaryId: subsidiaryId,
        warehouseLocationId: locationId,
        lastModifiedDate: new Date(newResponse.data.lastModifiedDate),
      };

      var payment = await prisma.payment.findFirst({
        where: { netsuiteId: parseInt(records[x].id) },
      });
      if (payment) {
        payment = await prisma.payment.update({
          where: { id: payment?.id },
          data: data,
        });
      } else {
        payment = await prisma.payment.create({
          data: data,
        });
        console.log(
          "Created { \n Transaction No:" +
            newResponse.data.tranId +
            " \n ID: " +
            newResponse.data.id +
            " \n Created Date: " +
            newResponse.data.createdDate +
            " \n }"
        );
      }
      var itemPath = "record/v1/vendorPayment/" + records[x].id + "/apply";
      var items = null;
      refetch3: try {
        items = await NsApi.request({
          path: itemPath,
        });
      } catch (err) {
        break refetch3;
      }

      await processItemData(items.data.items, itemPath, payment);
    }
  }
  if (hasMore) {
    var response = await NsApi.request({
      path:
        "record/v1/vendorPayment?limit=" +
        limit +
        "&offset=" +
        page * limit +
        query,
    });
    records = response.data.items;
    await processData(
      records,
      query,
      response.data.hasMore,
      response.data.links[0].href,
      page + 1
    );
  }
};

// const processItemData = async (
//   records: string[] | any[],
//   url: string,
//   payment: Payment
// ) => {
//   for (var x = 0; x < records.length; x++) {
//     var link: string = records[x].links[0].href;
//     var id = link.substr(link.lastIndexOf("/") + 1);

//     // await prisma.paymentInvoice.deleteMany({
//     //   where: {
//     //     paymentId: payment.id
//     //   },
//     // });

//     var newResponse = null;
//     refetch4: try {
//       newResponse = await NsApi.request({
//         path: url + "/" + id,
//       });
//     } catch (err) {
//       break refetch4;
//     }
//     var item = newResponse.data;
//     if (item.apply == true) {
//       // var newItem: any = await findItem(null, parseInt(item.doc?.id ?? 0));
//       var billing = await prisma.billing.findFirst({
//         where: { netsuiteId: parseInt(item.doc?.id) }
//       });

//       // console.log(billing?.id ?? null)
//       if (billing === null && item.doc?.id != null) {
//         processBillData(parseInt(item.doc?.id))
//       }
//       billing =  await prisma.billing.findFirst({
//         where: { netsuiteId: parseInt(item.doc?.id) }
//       });
//         var data = {
//           netsuiteId: billing?.netsuiteId,
//           invoiceId: billing?.id ?? null,
//           paymentAmount: billing?.grossAmount ?? 0,
//           type: item.type,
//           createdFrom: item.createdFrom,
//           refName: item.doc?.refName,
//           refNum: item.refNum,
//           apply: item.apply,
//           applyDate: item.applyDate ? new Date(item.applyDate) : null,
//           paymentId: payment.id,
//           subsidiaryId: payment.subsidiaryId,
//           lastModifiedDate: payment.lastModifiedDate,
//         };
//         var payment_invoice = await prisma.paymentInvoice.findFirst({
//           where: {  paymentId: payment.id,  subsidiaryId: payment.subsidiaryId, refNum: item.refNum }
//         });
//         if (payment_invoice) {
//           await prisma.paymentInvoice.update({
//             where: { id: payment_invoice.id },
//             data: data,
//           });
//         } else {
//           await prisma.paymentInvoice.create({
//             data: data,
//           });
//         }
      
//     }
  
//   }
// };

const parseDate = (dateString: string): Date => {
  // Split the string by '/'
  const [month, day, year] = dateString.split('/').map(Number);

  // Check if the year is given as two digits and adjust accordingly
  const fullYear = year + 2000; // Assuming the input year is from 2000-2099

  // Create a new Date object
  const date = new Date(fullYear, month - 1, day);

  return date;
};