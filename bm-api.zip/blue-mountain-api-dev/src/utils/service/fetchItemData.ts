import config from "../config";
import { PrismaClient } from "@prisma/client";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";
const prisma = new PrismaClient();
const limit = 1000;

export const getItemData = async () => {

  const existingRecords = await prisma.item.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = '';
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  // query = '&q=lastModifiedDate after "11/01/2023"';
  var response = await NsApi.request({
    path: 'record/v1/inventoryitem?limit=' + limit + query
  });
  
  const records = response.data.items;
  console.log(query, 'getItemData', records.length)
  await processData(records, query, response.data.hasMore, response.data.links[0].href, 1)

  return true;
};

const processData = async (records: string[] | any[], query: string, hasMore: boolean, link: string, page: number) => {
  for (var x = 0; x < records.length; x++) {
    refetch:
    try {
      var newResponse = await NsApi.request({
        path: 'record/v1/inventoryitem/' + records[x].id
      });
      if (newResponse.data.itemId) {

        var subsidiaryId: any = await findSubsidiary('record/v1/inventoryitem/' + records[x].id + '/subsidiary', null)

        var data = {
          barcode: newResponse.data.upcCode ?? '',
          name: newResponse.data.itemId,
          description: newResponse.data.itemId,
          lastModifiedDate: newResponse.data.lastModifiedDate,
          conversionToCase: newResponse.data.custitem_item_conversiontocase,
          cost: parseFloat(newResponse.data.cost ?? 0),
          netsuiteId: parseInt(records[x].id)
        };

        var item = await prisma.item.findFirst({
          where: { netsuiteId: parseInt(records[x].id) }
        });
        if (item) {
          await prisma.item.update({
            where: { id: item?.id },
            data: data
          });
        }
        else {
          await prisma.item.create({
            data: data,
          });
          console.log('created')
        }
      }
    } catch (err) {
      break refetch
    }

  }
  if (hasMore) {
    var response = await NsApi.request({
      path: 'record/v1/inventoryitem?limit=' + limit + '&offset=' + (page * limit) + query
    });
    records = response.data.items;
    await processData(records, query, response.data.hasMore, response.data.links[0].href, page + 1)
  }

}

// export const createItem = async (data: any){

// }
export const findItem = async (url: string | null, id: number | null) => {

  var itemId = id;
  if (!itemId) {
    var netsuiteItem = await NsApi.request({
      path: url
    });

    netsuiteItem = netsuiteItem.data.items[0]
    itemId = netsuiteItem.id
    console.log(itemId);
  }
  var item = await prisma.item.findFirst({
    where: { netsuiteId: itemId }
  });


  return item;

};