import config from "../config";
import { PrismaClient, ItemReceipt, PurchaseOrderItem } from "@prisma/client";

const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";
import { findItem } from "./fetchItemData";
import { findPurchaseOrder } from "./fetchPurchaseOrderData";

const prisma = new PrismaClient();
const limit = 1000;

export const getItemReceiptData = async () => {
  const existingRecords = await prisma.itemReceipt.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });
  
  var query = "";
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  // query = '&q=lastModifiedDate after "10/10/2023"';
  var response = await NsApi.request({
    path: "record/v1/itemreceipt?limit=" + limit + query,
  });
  
  const records = response.data.items;
  console.log(query, 'getItemReceiptData', records.length)
  await processData(
    records,
    query,
    response.data.hasMore,
    response.data.links[0].href,
    1
  );

  return true;
};

const processData = async (
  records: string[] | any[],
  query: string,
  hasMore: boolean,
  link: string,
  page: number
) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse;
    console.log(records[x]);
    refetch1: try {
      newResponse = await NsApi.request({
        path: "record/v1/itemreceipt/" + records[x].id,
      });
    } catch (err) {
      break refetch1;
    }

    console.log(
      "{ \n IR Number:" +
        newResponse.data.tranId +
        " \n Order Type: " +
        newResponse.data.orderType +
        " \n ID: " +
        newResponse.data.id +
        " \n Created Date: " +
        newResponse.data.createdDate +
        " \n }"
    );
    if (newResponse.data.orderType == "PurchOrd") {
      var subsidiaryId: any = await findSubsidiary(
        null,
        parseInt(newResponse.data.subsidiary.id)
      );
      var locationId: any = await findLocation(
        null,
        parseInt(newResponse.data.location.id)
      );
      var vendorId: any = newResponse.data.entity
        ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null))
        : null;
      var purchaseOrder: any = await findPurchaseOrder(
        null,
        parseInt(newResponse.data.createdFrom.id)
      );
      var data = {
        poNumber: purchaseOrder?.poNumber ?? "",
        supplierInvoiceReference:
          newResponse.data.custbody_itemreceipt_supplierinvoicer ?? "",
        receivedDate: new Date(newResponse.data?.tranDate ?? null),
        poDate: new Date(purchaseOrder?.poDate ?? null),
        preparedBy: newResponse.data.custbody_all_preparedby ?? "",
        checkedBy: newResponse.data.custbody_po_checkedby ?? "",
        approvedBy: "",
        receivedBy: "",
        totalQuantity: 0, // Need To Update,
        totalExpectedQuantity: purchaseOrder?.totalQuantity ?? 0,
        totalDeliveredQuantity: 0, // Need To Update,
        amount: 0, // Need To Update
        netsuiteId: parseInt(newResponse.data.id),
        vendorId: vendorId,
        subsidiaryId: subsidiaryId,
        status: purchaseOrder?.documentStatus,
        createdAt: new Date(newResponse.data.createdDate),
        vendorInvoiceNumber:
          newResponse.data.custbody_itemreceipt_supplierinvoicer ?? "",
        irNumber: newResponse.data.tranId,
        warehouseLocationId: locationId,
        lastModifiedDate: new Date(newResponse.data.lastModifiedDate),
      };

      var itemreceipt = await prisma.itemReceipt.findFirst({
        where: { netsuiteId: parseInt(records[x].id) },
      });
      if (itemreceipt) {
        itemreceipt = await prisma.itemReceipt.update({
          where: { id: itemreceipt?.id },
          data: data,
        });
      } else {
        itemreceipt = await prisma.itemReceipt.create({
          data: data,
        });
      }
      var itemPath = "record/v1/itemreceipt/" + records[x].id + "/item";
      var items;
      refetch2: try {
        items = await NsApi.request({
          path: itemPath,
        });
      } catch (err) {
        break refetch2;
      }

      var purchaseOrderItems = await prisma.purchaseOrderItem.findMany({
        where: {
          purchaseOrderId: purchaseOrder?.id ?? null,
        },
      });

      var processItemRecord = await processItemData(
        items.data.items,
        itemPath,
        itemreceipt,
        purchaseOrderItems
      );

      await prisma.itemReceipt.update({
        where: { id: itemreceipt?.id },
        data: {
          totalQuantity: processItemRecord.totalQuantity,
          totalDeliveredQuantity: processItemRecord.totalQuantity,
          amount: processItemRecord.totalAmount,
        },
      });
    }
  }
  if (hasMore) {
    refetch4: try {
      var response = await NsApi.request({
        path:
          "record/v1/itemreceipt?limit=" +
          limit +
          "&offset=" +
          page * limit +
          query,
      });
      records = response.data.items;
    } catch (err) {
      break refetch4;
    }
    await processData(
      records,
      query,
      response.data.hasMore,
      response.data.links[0].href,
      page + 1
    );
  }
};

export const processItemData = async (
  records: string[] | any[],
  url: string,
  itemreceipt: ItemReceipt,
  purchaseOrderItems: any
) => {
  var totalAmount = 0;
  var totalQuantity = 0;

  await prisma.itemReceiptItems.deleteMany({
    where: {
      itemReceiptId: itemreceipt.id,
    },
  });

  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf("/") + 1);

    var newItemResponse;
    refetch3: try {
      newItemResponse = await NsApi.request({
        path: url + "/" + id,
      });
    } catch (err) {
      console.log(err);
      break refetch3;
    }

    var item = newItemResponse.data;
    var itemData: any = await findItem(null, parseInt(item?.item?.id));
    var expectedQuantity = 0;

    for (var i = 0; i <= purchaseOrderItems.length; i++) {
      if (purchaseOrderItems[i]?.itemId == itemData?.id) {
        expectedQuantity = purchaseOrderItems[i].quantity;
        break;
      }
    }

    var data = {
      netsuiteId: 0,
      itemId: itemData?.id,
      expectedQuantity: item.quantityRemaining ?? 0,
      deliveredQuantity: item.quantity ?? 0,
      itemReceiptId: itemreceipt.id,
      subsidiaryId: itemreceipt.subsidiaryId,
      lastModifiedDate: itemreceipt.lastModifiedDate,
    };

    totalQuantity += parseInt(item.quantity ?? 0);
    totalAmount += parseFloat(item.itemFxAmount ?? 0);

    await prisma.itemReceiptItems.create({
      data: data,
    });
  }

  return {
    totalAmount: totalAmount,
    totalQuantity: totalQuantity,
  };
};
