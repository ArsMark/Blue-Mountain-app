import config from "../config";
import { PrismaClient } from "@prisma/client";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const prisma = new PrismaClient();
const limit = 1000;
import { hashSync } from "bcrypt";
import {createPassword} from "./netsuiteUpdates/updateUserVendor"
export const getVendorData = async () => {

  const existingRecords = await prisma.vendor.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = '';
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  // query = '&q=lastModifiedDate after "01/15/2021"';
 
  var response = await NsApi.request({
    path: 'record/v1/vendor?limit=' + limit + query
  });

  const records = response.data.items;
  console.log('getVendorData', records.length)
  await processData(records, query, response.data.hasMore, response.data.links[0].href, 1)

  return true;

};

const processData = async (records: string[] | any[], query: string, hasMore: boolean, link: string, page: number) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse = await NsApi.request({
      path: 'record/v1/vendor/' + records[x].id
    });
    if (newResponse.data.companyName && newResponse.data.email != undefined) {
      var data = {
        name: newResponse.data.companyName,
        lastModifiedDate: newResponse.data.lastModifiedDate,
        address: newResponse.data.defaultAddress, 
        netsuiteId: parseInt(records[x].id)
      };

      var oldVendor = await prisma.vendor.findFirst({
        where: { netsuiteId: parseInt(records[x].id) }
      });

      var vendor;
      const email = newResponse.data.email
      console.log(email)
      var existUser;
       existUser = await prisma.user.findFirst({
        where: { email: email}
      });

      if (oldVendor) {
        vendor = await prisma.vendor.update({
          where: { id: oldVendor?.id },
          data: data
        });

      }
      else {
        vendor = await prisma.vendor.create({
          data: data,
        });
      }
      let password = ''
      if (vendor.netsuiteId) {
        password = createPassword(vendor.name.trim(), vendor.netsuiteId)
      }
      console.log(`vendor: ${vendor.name} , email:, ${email}, password:, ${password}`)
      var userData = {
        email: email,
        password: hashSync(password, 12),
        role: "vendor",
        firstName: newResponse.data.companyName,
        lastName: "",
        vendorId: vendor?.id
      };

      if (existUser) {
        existUser =  await prisma.user.update({
          where: { id: existUser?.id },
          data: userData
        });
      }
      else{
        existUser = await prisma.user.create({
          data: userData
        });
      }

      if (vendor && existUser) {
        console.log(newResponse.data.email)
       
        var existVendor = await prisma.userVendor.findFirst({
          where: { vendorId: vendor?.id, }
        });

        var userVendorData = {
          userId: existUser?.id,
          vendorId: vendor?.id
        };

        if (existVendor) {
          await prisma.userVendor.update({
            where: { id: existVendor?.id },
            data: userVendorData
          });
        }
        else{
          await prisma.userVendor.create({
            data: userVendorData
          });
        }
       
        console.log("{ \n Vendor Name:" + newResponse.data.companyName
        + " \n ID: " + newResponse.data.id
        + " \n Created Date: " + newResponse.data.createdDate
        + "\n email" + newResponse.data.email
        + " \n }");
      }

    }

  }
  if (hasMore) {
    var response = await NsApi.request({
      path: 'record/v1/vendor?limit=' + limit + '&offset=' + (page * limit) + query
    });
    records = response.data.items;
    await processData(records, query, response.data.hasMore, response.data.links[0].href, page + 1)
  }

}

export const findVendor = async (url: string | null, id: number | null) => {

  var vendorId = id

  if (!vendorId) {
    var netsuiteVendor = await NsApi.request({
      path: url
    });

    netsuiteVendor = netsuiteVendor.data.items[0]
    vendorId = parseInt(netsuiteVendor.id)
  }
  var vendor = await prisma.vendor.findFirst({
    where: { netsuiteId: vendorId }
  });

  return vendor?.id;

};