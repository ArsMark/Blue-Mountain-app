import config from "../config";
import { PrismaClient, Billing } from "@prisma/client";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";
import { findItem } from "./fetchItemData";
import { findPurchaseOrder } from "./fetchPurchaseOrderData";
import {discounts, processExpenseData, processItemData} from "./netsuiteUpdates/updateBilling"
import withVAT from "../withVAT";
import { Decimal } from "@prisma/client/runtime/library";

const prisma = new PrismaClient();
const limit = 1000;
let totalCount = 0;

export const getBillingData = async () => {

  const existingRecords = await prisma.billing.findMany({
    orderBy: [
        { lastModifiedDate: 'desc' }
    ],
    take: 1,
    select: {
        lastModifiedDate: true
    }
  });
  
  var query = '';
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    console.log(lastModifiedDate)
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  // query = '&q=lastModifiedDate after "07/07/2024"';
  var response = await NsApi.request({
    path: 'record/v1/vendorBill?limit=' + limit + query
  });
  
  const records = response.data.items;
  console.log(query, 'getBillingData', records.length)
  await processData(records, query, response.data.hasMore, response.data.links[0].href, 1)

  return true;

};

const processData = async (records: string[] | any[], query: string, hasMore: boolean, link: string, page: number) => {

  for (var x = 0; x < records.length; x++) {

    var newResponse = null;
    refetch1:
    try {
      newResponse = await NsApi.request({
        path: 'record/v1/vendorBill/' + records[x].id
      });
    } catch (err) {
      break refetch1
    }

    if (newResponse.data) {
      var subsidiaryId: any = newResponse.data.subsidiary ? await findSubsidiary(null, parseInt(newResponse.data.subsidiary.id)) : null
      var locationId: any = newResponse.data.location ? await findLocation(null, parseInt(newResponse.data.location?.id ?? null)) : null
      var vendorId: any = newResponse.data.entity ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null)) : null

      var billing = await prisma.billing.findFirst({
        where: { netsuiteId: parseInt(records[x].id) }
      });

      var data = {
        type: "bill",
        billingNumber: newResponse.data.tranId ?? "",
        terms: newResponse.data.terms?.refName ?? "",
        transactionDate: new Date(newResponse.data.tranDate ?? null),
        dueDate: new Date(newResponse.data.dueDate ?? null),
        docStartDate: new Date(),
        docEndDate: new Date(),
        dateModified: new Date(),
        cbrStatus: newResponse.data.approvalStatus?.refName ?? "",
        currency: newResponse.data.currency.refName ?? "",
        netsuiteId: parseInt(newResponse.data.id) ?? 0,
        counterReceiptNumber: "",
        supplierInvoiceReference: newResponse.data.custbody_itemreceipt_supplierinvoicer ?? "",
        vendorId: vendorId,
        subsidiaryId: subsidiaryId,
        docNumber: newResponse.data.tranId ?? "",
        remarks: newResponse.data.custbody_po_notes ?? "",
        warehouseLocationId: locationId,

        poNumber: "",
        irNumber: "",
        lastModifiedDate: new Date(newResponse.data.lastModifiedDate ?? null),
        withHoldingTax: 0,
        ewt: 0,
        centralDropDiscount: 0,
        centralTlcDiscount: 0,
        otherSpecialDiscount: 0,
        tradeDiscount: 0,

        amount: newResponse.data.total ?? "",
        grossAmount: newResponse.data.total ?? "",
        netAmount: newResponse.data.total - (newResponse.data.total * 0.12),
        total: newResponse.data.total,
        vat: newResponse.data.total * 0.12

      };

      if (billing) {
        billing = await prisma.billing.update({
          where: { id: billing?.id },
          data: data
        });
        console.log('updated netsuiteId', newResponse.data.id)
      }
      else {
        billing = await prisma.billing.create({
          data: data,
        });
        console.log("{ \n Billing NUmber:" + newResponse.data.tranId
        + " \n ID: " + newResponse.data.id
        + " \n Created Date: " + newResponse.data.createdDate
        + " \n }");
      }
      var itemPath = 'record/v1/vendorBill/' + records[x].id + '/item'
      var items = null
      refetch2:
      try {
        items = await NsApi.request({
          path: itemPath
        });
      } catch (err) {
        break refetch2
      }

      const expensePath = 'record/v1/vendorBill/' + billing.netsuiteId + '/expense';
      let expenses = null;
      refetch3:
      try {
        expenses = await NsApi.request({
          path: expensePath
        });
      } catch (err) {
        break refetch3;
      }

      const expenseTax = await processExpenseData(expenses.data.items, expensePath);
      console.log(newResponse.data.id, 'billing', newResponse.data.lastModifiedDate, expenseTax)
      const processItemRecord = await processItemData(items.data.items, itemPath, billing.id)
      const totalDiscount = discounts(processItemRecord)
      const netAmount =  parseFloat(newResponse.data.total)
      const totalWhtax = expenseTax + processItemRecord.withHoldingTax;
      const grossAmount = netAmount + Math.abs(totalWhtax)

      await prisma.billing.update({
        where: { id: billing?.id },
        data: {
          grossAmount: grossAmount,
          total: netAmount,
          withHoldingTax: totalWhtax,
          netAmount: processItemRecord.total_netAmount,
          vat: processItemRecord.total_tax,
          ewt: processItemRecord.withHoldingTax,
          poNumber: processItemRecord.poNumber,
          irNumber: processItemRecord.irNumber,
          centralDropDiscount: totalDiscount.centralDropDiscount,
          centralTlcDiscount:  totalDiscount.centralTlcDiscount,
          otherSpecialDiscount:  totalDiscount.otherSpecialDiscount,
          tradeDiscount:  totalDiscount.tradeDiscount,
        }
      });
    }
    totalCount++;
  }
  if (hasMore) {
    refetch3:
    try {
      console.log(query, 'query')
      var response = await NsApi.request({
        path: 'record/v1/vendorBill?limit=' + limit + '&offset=' + (page * limit) + query
      });
    } catch (err) {
      console.log(err);
      break refetch3
    }
    records = response.data.items;
    await processData(records, query, response.data.hasMore, response.data.links[0].href, page + 1)
  }

}

// const processItemData = async (records: string[] | any[], url: string, billing: Billing) => {

//   var withHoldingTax = 0;
//   var poNumber = "";
//   var irNumber = "";
//   var centralDropDiscount = 0
//   var centralTlcDiscount = 0
//   var otherSpecialDiscount = 0
//   var tradeDiscount = 0
//   var totalGrossAmount = 0

//   for (var x = 0; x < records.length; x++) {
//     var link: string = records[x].links[0].href;
//     var id = link.substr(link.lastIndexOf('/') + 1)
   
//     var newResponse = null
//     refetch4:
//     try {
//       newResponse = await NsApi.request({
//         path: url + '/' + id
//       });
//     } catch (err) {
//       break refetch4
//     }
//     if (newResponse.data) {
//       var item = newResponse.data
//       if (item.item.refName.includes('TOTAL CENTRAL DROP DISCOUNT')) {
//         centralDropDiscount = item.amount ?? 0
//       }
//       if (item.item.refName.includes("TOTAL TRADE DISCOUNT")) {
//         tradeDiscount = item.amount ?? 0
    
//       }
//       if (item.item.refName.includes('TLC DISCOUNT') ) {
//         centralTlcDiscount = item.amount ?? 0
//       }
//       if (item.item.refName.includes('WHTAX') ) {
//         withHoldingTax = item.amount ?? 0
//       }
//       if (item.item.refName.includes('TOTAL OTHER DISCOUNT') ) {
//         otherSpecialDiscount = item.amount ?? 0
//       }
//       if (item.itemType.refName == "InvtPart") {
//         totalGrossAmount += withVAT(item.amount)
//         var purchaseOrder: any = await findPurchaseOrder(null, parseInt(item.orderDoc?.id ?? 1))
  
//         if (!purchaseOrder)
//           continue;
//         var itemReceipt: any = await prisma.itemReceipt.findFirst({
//           where: {
//             poNumber: purchaseOrder.poNumber
//           }
//         });
//         var newItem: any = await findItem(null, parseInt(item.item?.id))
//         poNumber = purchaseOrder?.poNumber ?? ""
//         irNumber = itemReceipt?.irNumber ?? ""
        
//         otherSpecialDiscount = Math.abs(purchaseOrder?.totalOtherSpecialDiscount ?? 0)
//         tradeDiscount = Math.abs(purchaseOrder?.totalTradeDiscount ?? 0)
  
//         const sum = (...arr: number[]) => [...arr].reduce((acc, val) => acc + val, 0);
//         var discount = sum(centralDropDiscount, centralTlcDiscount, otherSpecialDiscount, tradeDiscount)
  
//         var netAmount = item.amount ?? 0;
//         var taxAmount = (item.amount ?? 0) * 0.12;
//         var grossAmount = netAmount + taxAmount - discount;
//         var total = grossAmount;
        
//         var data = {
//           type: "bill",
//           transactionNo: itemReceipt?.irNumber ?? "",
//           itemId: parseInt(newItem?.id) ?? "",
//           grossAmount: grossAmount,
//           taxAmount: taxAmount,
//           netAmount: netAmount,
//           discount: discount,
//           total: total,
//           billingId: billing.id,
//           subsidiaryId: billing.subsidiaryId,
//           debitCreditMemoId: null,
//           lastModifiedDate: billing.lastModifiedDate,
//         };
//         var billingPo = await prisma.billingPo.findFirst({
//           where: { billingId: billing.id, subsidiaryId: billing.subsidiaryId, 
//                     transactionNo: itemReceipt?.irNumber, itemId: parseInt(newItem?.id)}
//         });
        
//         if (billingPo) {
//           // console.log(billingPo, 'existing')
//           await prisma.billingPo.update({
//             where: { id: billingPo?.id },
//             data: data
//           });
//         } else {
//           await prisma.billingPo.create({
//             data: data,
//           });
//         }
//     }
     
//     }

//   }

//   return {
//     grossAmount: totalGrossAmount,
//     withHoldingTax: withHoldingTax,
//     poNumber: poNumber,
//     irNumber: irNumber,
//     centralDropDiscount: centralDropDiscount,
//     centralTlcDiscount: centralTlcDiscount,
//     otherSpecialDiscount: otherSpecialDiscount,
//     tradeDiscount: tradeDiscount,
//   };

// }

export const findBilling = async (url: string | null, id: number | null) => {

  var billingId = id

  if (!billingId) {
    var netsuiteBilling = await NsApi.request({
      path: url
    });

    netsuiteBilling = netsuiteBilling.data.items[0]
    billingId = parseInt(netsuiteBilling.id)
  }
  var billing = await prisma.billing.findFirst({
    where: { netsuiteId: billingId }
  });

  return billing;

};


