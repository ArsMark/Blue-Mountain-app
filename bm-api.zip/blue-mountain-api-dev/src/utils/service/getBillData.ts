import config from "../config";
import { PrismaClient, Billing } from "@prisma/client";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";
import { findItem } from "./fetchItemData";
import { findPurchaseOrder } from "./fetchPurchaseOrderData";
import {discounts, processExpenseData, processItemData} from "./netsuiteUpdates/updateBilling"
import withVAT from "../withVAT";
import { addVat } from "./netsuiteUpdates/updatePurchaseOrderItem";

const prisma = new PrismaClient();

export const processBillData = async (netsuiteId: number ) => {

    var newResponse = null;
    refetch1:
    try {
      newResponse = await NsApi.request({
        path: `record/v1/vendorBill/${netsuiteId}` 
      });
    } catch (err) {
      break refetch1
    }
   
    if (newResponse) {
      var subsidiaryId: any = newResponse.data?.subsidiary ? await findSubsidiary(null, parseInt(newResponse.data.subsidiary?.id )) : null
      // console.log(newResponse.data?.subsidiary)
      if (subsidiaryId) {
        var locationId: any = newResponse.data.location ? await findLocation(null, parseInt(newResponse.data.location?.id ?? null)) : null
      var vendorId: any = newResponse.data.entity ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null)) : null

      var get_billing = await prisma.billing.findFirst({
        where: { netsuiteId: netsuiteId }
      });

      var data = {
        type: "bill",
        billingNumber: newResponse.data.tranId ?? "",
        terms: newResponse.data.terms?.refName ?? "",
        transactionDate: new Date(newResponse.data.tranDate ?? null),
        dueDate: new Date(newResponse.data.dueDate ?? null),
        docStartDate: new Date(),
        docEndDate: new Date(),
        dateModified: new Date(),
        cbrStatus: newResponse.data.approvalStatus?.refName ?? "",
        currency: newResponse.data.currency.refName ?? "",
        netsuiteId: parseInt(newResponse.data.id) ?? 0,
        counterReceiptNumber: "",
        supplierInvoiceReference: newResponse.data.custbody_itemreceipt_supplierinvoicer ?? "",
        vendorId: vendorId,
        subsidiaryId: subsidiaryId,
        docNumber: newResponse.data.tranId ?? "",
        remarks: newResponse.data.custbody_po_notes ?? "",
        warehouseLocationId: locationId,

        poNumber: "",
        irNumber: "",
        lastModifiedDate: new Date(newResponse.data.lastModifiedDate ?? null),
        withHoldingTax: 0,
        ewt: 0,
        centralDropDiscount: 0,
        centralTlcDiscount: 0,
        otherSpecialDiscount: 0,
        tradeDiscount: 0,

        amount: newResponse.data.total ?? "",
        grossAmount: newResponse.data.total ?? "",
        netAmount: newResponse.data.total - (newResponse.data.total * 0.12),
        total: newResponse.data.total,
        vat: newResponse.data.total * 0.12

      };

      if (get_billing) {
        get_billing = await prisma.billing.update({
          where: { id: get_billing?.id },
          data: data
        });
      }
      else {
        get_billing = await prisma.billing.create({
          data: data,
        });
        console.log("{ \n Billing NUmber:" + newResponse.data.tranId
        + " \n ID: " + newResponse.data.id
        + " \n Created Date: " + newResponse.data.createdDate
        + " \n }");
      }
      var itemPath = 'record/v1/vendorBill/' + netsuiteId + '/item'
      var items = null
      refetch2:
      try {
        items = await NsApi.request({
          path: itemPath
        });
      } catch (err) {
        break refetch2
      }

      const expensePath = 'record/v1/vendorBill/' + netsuiteId + '/expense';
      let expenses = null;
      refetch3:
      try {
        expenses = await NsApi.request({
          path: expensePath
        });
      } catch (err) {
        break refetch3;
      }

      var processItemRecord = await processItemData(items.data.items, itemPath, get_billing.id)
      const totalDiscount = discounts(processItemRecord)
      const expenseTax = await processExpenseData(expenses.data.items, expensePath);
      const netAmount =  parseFloat(newResponse.data.total)
      const totalWhtax = expenseTax + processItemRecord.withHoldingTax;
      const grossAmount = netAmount + Math.abs(totalWhtax)
        await prisma.billing.update({
          where: { id: get_billing?.id },
          data: {
            grossAmount: grossAmount,
            total: netAmount,
            withHoldingTax: totalWhtax,
            ewt: processItemRecord.withHoldingTax,
            poNumber: processItemRecord.poNumber,
            irNumber: processItemRecord.irNumber,
            centralDropDiscount: totalDiscount.centralDropDiscount,
            centralTlcDiscount:  totalDiscount.centralTlcDiscount,
            otherSpecialDiscount:  totalDiscount.otherSpecialDiscount,
            tradeDiscount:  totalDiscount.tradeDiscount,
          }
        });
      }
      
    }
    var updatedBilling = await prisma.billing.findFirst({
      where: { netsuiteId: netsuiteId }
    });
    
      return {updatedBilling}
}



