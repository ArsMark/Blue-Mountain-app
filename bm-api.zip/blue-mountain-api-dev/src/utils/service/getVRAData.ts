import config from "../config";
import { PrismaClient, VendorReturnAuthorization } from "@prisma/client";

const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";
import { processItemData } from "./fetchVendorReturnAuthorizationData";
import { deadlinePullOutDate } from "./netsuiteUpdates/updateVRA";

const prisma = new PrismaClient();

export const processVRAData = async (netsuiteId: number ) => {

  var newResponse = null;
  refetch1:
  try {
    newResponse = await NsApi.request({
      path: `record/v1/vendorReturnAuthorization/${netsuiteId}`
    });
  } catch (err) {
    break refetch1
  }
 
  if (newResponse) {
    if (newResponse.data?.tranId) {
      var subsidiaryId: any = await findSubsidiary(
        null,
        parseInt(newResponse.data.subsidiary.id)
      );
      var locationId: any = newResponse.data.location
        ? await findLocation(null, parseInt(newResponse.data.location.id))
        : null;
      var vendorId: any = newResponse.data.entity
        ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null))
        : null;

      var data = {
        netsuiteId: parseInt(newResponse.data.id),
        fulfillmentDate: new Date(newResponse.data.tranDate), // will be update on item fulfillment
        itemFulFillmentNumber: "", // will be update on item fulfillment
        pullOutDate: deadlinePullOutDate(newResponse.data.tranDate), // will be update on item fulfillment
        documetStatus: newResponse.data.orderStatus?.refName ?? "",
        quantity: 0,
        totalAmount:  0,
        grossAmount: newResponse.data.total,
        siteLocation: newResponse.data.billAddress ?? "",
        preparedBy: newResponse.data.custbody_all_preparedby ?? "",
        srsNumber: newResponse.data?.custbody_inventryadjstment_srsref ?? "",
        vraNumber: newResponse.data.tranId ?? "",
        vraStatus: newResponse.data.status?.refName ?? "",
        createdAt: new Date(newResponse.data.createdDate ?? null),
        vendorId: vendorId,
        subsidiaryId: subsidiaryId,
        warehouseLocationId: locationId,
        lastModifiedDate: new Date(newResponse.data.lastModifiedDate),
      };

      var vra = await prisma.vendorReturnAuthorization.findFirst({
        where: { netsuiteId: netsuiteId },
      });
      if (vra) {
        vra = await prisma.vendorReturnAuthorization.update({
          where: { id: vra?.id },
          data: data,
        });
        console.log('updated', vra.id)
      } else {
        vra = await prisma.vendorReturnAuthorization.create({
          data: data,
        });
        console.log(
          "{ \n Created VRA Number:" +
            newResponse.data.tranId +
            " \n ID: " +
            newResponse.data.id +
            " \n Created Date: " +
            newResponse.data.createdDate +
            " \n }"
        );
  
      }
      var itemPath =
        `record/v1/vendorReturnAuthorization/${netsuiteId}/item`;

      var items = null;
      refetch2: try {
        items = await NsApi.request({
          path: itemPath,
        });
      } catch (err) {
        break refetch2;
      }
      console.log('VRA', newResponse.data.id)
      var processItemRecord = await processItemData(
        items.data.items,
        itemPath,
        vra
      );
     
      const totalAmount = parseFloat(newResponse.data.total) - processItemRecord.totalTradeDiscount
      await prisma.vendorReturnAuthorization.update({
        where: { id: vra?.id },
        data: {
          totalAmount:  totalAmount,
          totalTradeDiscount: processItemRecord.totalTradeDiscount,
          quantity: processItemRecord.totalQuantity,
        },
      });
    }

    const created_vra = await prisma.vendorReturnAuthorization.findFirst({
      where: { netsuiteId: netsuiteId },
    });

    return created_vra
  }
}