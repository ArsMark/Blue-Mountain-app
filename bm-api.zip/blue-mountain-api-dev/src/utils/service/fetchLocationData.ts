import config from "../config";
import { PrismaClient } from "@prisma/client";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";

const prisma = new PrismaClient();
const limit = 1000;

export const getLocationData = async () => {

  const existingRecords = await prisma.warehouseLocation.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = '';
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  var response = await NsApi.request({
    path: 'record/v1/location?limit=' + limit + query
  });

  const records = response.data.items;

  await processData(records, query, response.data.hasMore, response.data.links[0].href, 1)

  return true;
};

const processData = async (records: string[] | any[], query: string, hasMore: boolean, link: string, page: number) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse = await NsApi.request({
      path: 'record/v1/location/' + records[x].id
    });
    if (newResponse.data.name) {

      var subsidiaryId: any = await findSubsidiary('record/v1/location/' + records[x].id + '/subsidiary', null)

      var netsuiteLocationMainAddress = await NsApi.request({
        path: 'record/v1/location/' + records[x].id + '/mainAddress'
      });

      netsuiteLocationMainAddress = netsuiteLocationMainAddress.data

      var data = {
        name: newResponse.data.name,
        lastModifiedDate: newResponse.data.lastModifiedDate,
        address: netsuiteLocationMainAddress.addrText,
        subsidiaryId: subsidiaryId,
        netsuiteId: parseInt(records[x].id)
      };
      
      var location = await prisma.warehouseLocation.findFirst({
        where: { netsuiteId: parseInt(records[x].id) }
      });
      if (location) {
        await prisma.warehouseLocation.update({
          where: { id: location?.id },
          data: data
        });
      }
      else {
        await prisma.warehouseLocation.create({
          data: data,
        });
      }

    }

  }
  if (hasMore) {
    var response = await NsApi.request({
      path: 'record/v1/location?limit=' + limit + '&offset=' + (page * limit) + query
    });
    records = response.data.items;
    await processData(records, query, response.data.hasMore, response.data.links[0].href, page + 1)
  }

}

export const findLocation = async (url: string | null, id: number | null) => {

  var locationId = id;
  if (!locationId) {
    var netsuiteLocation = await NsApi.request({
      path: url
    });

    netsuiteLocation = netsuiteLocation.data.items[0]
    locationId = parseInt(netsuiteLocation.id)
  }

  var location = await prisma.warehouseLocation.findFirst({
    where: { netsuiteId: locationId }
  });

  return location?.id;

};