import config from "../config";
import { PrismaClient, VendorReturnAuthorization } from "@prisma/client";

const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";
import { findItem } from "./fetchItemData";
import { processItemNesuite } from "./getItem";
import { deadlinePullOutDate } from "./netsuiteUpdates/updateVRA";
import withVAT from "../withVAT";
const prisma = new PrismaClient();
const limit = 1000;

export const getVendorReturnAuthorizationData = async () => {
  const existingRecords = await prisma.payment.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = "";
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  //query = '&q=lastModifiedDate after "06/01/2024"';
  var response = await NsApi.request({
    path: "record/v1/vendorReturnAuthorization?limit=" + limit + query,
  });

  const records = response.data.items;
  console.log('vendorReturnAuthorization',query, records.length )
  await processData(
    records,
    query,
    response.data.hasMore,
    response.data.links[0].href,
    1
  );

  return true;
};

const processData = async (
  records: string[] | any[],
  query: string,
  hasMore: boolean,
  link: string,
  page: number
) => {
  for (var x = 0; x < records.length; x++) {
    var newResponse = null;
    refetch1: try {
      newResponse = await NsApi.request({
        path: "record/v1/vendorReturnAuthorization/" + records[x].id,
      });
    } catch (err) {
      break refetch1;
    }

    if (newResponse.data?.tranId) {
      var subsidiaryId: any = await findSubsidiary(
        null,
        parseInt(newResponse.data.subsidiary.id)
      );
      var locationId: any = newResponse.data.location
        ? await findLocation(null, parseInt(newResponse.data.location.id))
        : null;
      var vendorId: any = newResponse.data.entity
        ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null))
        : null;

      var data = {
        netsuiteId: parseInt(newResponse.data.id),
        fulfillmentDate: new Date(newResponse.data.tranDate), // will be update on item fulfillment
        itemFulFillmentNumber: "", // will be update on item fulfillment
        pullOutDate: deadlinePullOutDate(newResponse.data.tranDate), // will be update on item fulfillment
        documetStatus: newResponse.data.orderStatus?.refName ?? "",
        quantity: 0,
        totalAmount:  0,
        grossAmount: newResponse.data.total,
        siteLocation: newResponse.data.billAddress ?? "",
        preparedBy: newResponse.data.custbody_all_preparedby ?? "",
        srsNumber: newResponse.data?.custbody_inventryadjstment_srsref ?? "",
        vraNumber: newResponse.data.tranId ?? "",
        vraStatus: newResponse.data.status?.refName ?? "",
        createdAt: new Date(newResponse.data.createdDate ?? null),
        vendorId: vendorId,
        subsidiaryId: subsidiaryId,
        warehouseLocationId: locationId,
        lastModifiedDate: new Date(newResponse.data.lastModifiedDate),
      };

      var vra = await prisma.vendorReturnAuthorization.findFirst({
        where: { netsuiteId: parseInt(records[x].id) },
      });
      if (vra) {
        vra = await prisma.vendorReturnAuthorization.update({
          where: { id: vra?.id },
          data: data,
        });
        console.log('updated', vra.id)
      } else {
        vra = await prisma.vendorReturnAuthorization.create({
          data: data,
        });
        console.log(
          "{ \n Created VRA Number:" +
            newResponse.data.tranId +
            " \n ID: " +
            newResponse.data.id +
            " \n Created Date: " +
            newResponse.data.createdDate +
            " \n }"
        );
  
      }
      var itemPath =
        "record/v1/vendorReturnAuthorization/" + records[x].id + "/item";

      var items = null;
      refetch2: try {
        items = await NsApi.request({
          path: itemPath,
        });
      } catch (err) {
        break refetch2;
      }
      console.log('VRA', newResponse.data.id)
      var processItemRecord = await processItemData(
        items.data.items,
        itemPath,
        vra
      );
     
      const totalAmount = parseFloat(newResponse.data.total) - processItemRecord.totalTradeDiscount
      await prisma.vendorReturnAuthorization.update({
        where: { id: vra?.id },
        data: {
          totalAmount:  totalAmount,
          totalTradeDiscount: processItemRecord.totalTradeDiscount,
          quantity: processItemRecord.totalQuantity,
        },
      });
    }
  }
  if (hasMore) {
    var response;
    refetch4: try {
      response = await NsApi.request({
        path:
          "record/v1/vendorReturnAuthorization?limit=" +
          limit +
          "&offset=" +
          page * limit +
          query,
      });
      records = response.data.items;
    } catch (err) {
      break refetch4;
    }
    await processData(
      records,
      query,
      response.data.hasMore,
      response.data.links[0].href,
      page + 1
    );
  }
};

export const processItemData = async (
  records: string[] | any[],
  url: string,
  vra: VendorReturnAuthorization
) => {
  var totalQuantity = 0;
  var totalAmount = 0;
  var totalTradeDiscount = 0

  await prisma.vendorReturnAuthorizationItem.deleteMany({
    where: {
      vendorReturnAuthorizationId: vra.id,
    },
  });
  
  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf("/") + 1);

    var newResponse = null;
    refetch3: try {
      newResponse = await NsApi.request({
        path: url + "/" + id,
      });
    } catch (err) {
      break refetch3;
    }

    var item = newResponse.data;
    if (item) {
      var itemData: any = await findItem(null, parseInt(item.item?.id));

      var data = {
        netsuiteId: 0,
        itemId: itemData?.id ?? 1,
        grossNet: item.amount,
        quantity: item.quantity ?? 0,
        totalAmount: withVAT(item.amount),
        vendorReturnAuthorizationId: vra.id,
        subsidiaryId: vra.subsidiaryId,
        lastModifiedDate: vra.lastModifiedDate,
      };

      if (!itemData) {
        itemData = processItemNesuite(parseInt(item.item?.id))
        console.log('no item',itemData.id, item.item)
      }

      totalTradeDiscount += item.custcol_po_tradediscountamount ?? 0
      totalQuantity += item.quantity ?? 0;

      await prisma.vendorReturnAuthorizationItem.create({
        data: data,
      });
      
    }

    }
    
  return {
    totalQuantity: totalQuantity,
    totalAmount: totalAmount,
    totalTradeDiscount
  };
};

export const findVendorReturnAuthorization = async (
  url: string | null,
  id: number | null
) => {
  var vendrReturnAuthorizationId = id;

  if (!vendrReturnAuthorizationId) {
    var netsuiteVendorReturnAuthorization = await NsApi.request({
      path: url,
    });

    netsuiteVendorReturnAuthorization =
      netsuiteVendorReturnAuthorization.data.items[0];
    vendrReturnAuthorizationId = parseInt(netsuiteVendorReturnAuthorization.id);
  }
  var vendorReturnAuthorization =
    await prisma.vendorReturnAuthorization.findFirst({
      where: { netsuiteId: vendrReturnAuthorizationId },
    });

  return vendorReturnAuthorization;
};
