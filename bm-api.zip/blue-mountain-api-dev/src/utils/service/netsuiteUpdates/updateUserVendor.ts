import { PrismaClient, Billing } from "@prisma/client";
import config from "../../config";
import { Request, Response } from "express";
const NsApiWrapper = require('netsuite-rest');
import { hashSync } from "bcrypt";
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const prisma = new PrismaClient();

 const updateUserVendor = async (req: Request, res: Response) => {
  try {
    const vendors = await prisma.vendor.findMany({
      // where: {
      //   id: 468,
      //   // lastModifiedDate: { lte: new Date("2020-08-13") }
      // },
      select: {
        netsuiteId: true,
        id: true,
        name: true
      },
      take: 1 //remove when using this update
    });
   
    console.log(vendors.length)
    for (const vendor of vendors) {
      try {
        const currentHour = new Date().getHours();
        // console.log(currentHour > 2)
        // This will terminate the api process every 2 AM
        if (currentHour > 3) {
          console.log(
            " vendor netsuite ID " + vendor?.netsuiteId
          );
          break;
        }
       
        let newResponse = null;
        refetch1:
        try {
          newResponse = await NsApi.request({
            path: 'record/v1/vendor/' + vendor.netsuiteId
          });
        } catch (err) {
          break refetch1;
        }
        var vendor_data = {
          name: newResponse.data.companyName,
          lastModifiedDate: newResponse.data.lastModifiedDate,
          address: newResponse.data.defaultAddress, 
          netsuiteId: vendor.netsuiteId
        };

        if (vendor) {
          await prisma.vendor.update({
            where: { id: vendor?.id },
            data: vendor_data
          });
          console.log(vendor_data.address)
        }
       
        // const users = [
        //   { email: "admin24@bminc.com.ph", role: "admin", firstName: "Admin", password: hashSync('Adm24bmportal', 12), lastName: ""},
        //   { email: "admin.acctg24@bminc.com.ph", role: "admin-accounting", firstName: "Admin/Accounting", password: hashSync('AdmAcct24bmportal', 12), lastName: "" },
        //   { email: "accounting24@bminc.com.ph", role: "accounting", firstName: "Accounting", password: hashSync('Acct24bmportal', 12), lastName: "" },
        //   { email: "puchasing24@bminc.com.ph", role: "puchasing", firstName: "Puchasing", password: hashSync('Pcs24bmportal', 12), lastName: "" },
        //   { email: "warehouse24@bminc.com.ph", role: "warehouse", firstName: "Warehouse", password: hashSync('Whs24bmportal', 12), lastName: "" }
        // ];
        
        // for (const user of users) {
        //   await prisma.user.create({
        //     data: user
        //   });
        // }
        
        if (newResponse.data.companyName && newResponse.data.email != undefined) {
          // const email = newResponse.data.email
        
          // var existUser;
          //  existUser = await prisma.user.findFirst({
          //   where: { email: email}
          // });
          // let password = ''
          // if (vendor.netsuiteId) {
          //   password = createPassword(vendor.name.trim(), vendor.netsuiteId)
          // }
          
          // console.log(`vendor: ${vendor.name} , email:, ${email}, password:, ${password}`)
          // var userData = {
          //   email: email,
          //   password: hashSync(password, 12),
          //   role: "vendor",
          //   firstName: newResponse.data.companyName,
          //   lastName: "",
          //   vendorId: vendor?.id
          // };
    
          // if (existUser) {
          //   existUser =  await prisma.user.update({
          //     where: { id: existUser?.id },
          //     data: userData
          //   });
          // }
          // else{
          //   existUser = await prisma.user.create({
          //     data: userData
          //   });
          // }
    
          // if (vendor && existUser && vendor.netsuiteId) {
            
           
          //   var existVendor = await prisma.userVendor.findFirst({
          //     where: { vendorId: vendor?.id, }
          //   });
            
          //   var userVendorData = {
          //     userId: existUser?.id,
          //     vendorId: vendor?.id
          //   };
    
          //   if (existVendor) {
          //     await prisma.userVendor.update({
          //       where: { id: existVendor?.id },
          //       data: userVendorData
          //     });
          //     // console.log('Updated userVendor')
          //   }
          //   else{
          //     await prisma.userVendor.create({
          //       data: userVendorData
          //     });
          //   console.log("{ \n Vendor Name:" + newResponse.data.companyName
          //     + " \n ID: " + newResponse.data.id
          //     + " \n Created Date: " + newResponse.data.createdDate
          //     + "\n email" + newResponse.data.email
          //     + " \n }");
          //   }
          // }
        }
      }catch (error) {
        console.log("Vendor Netsuite ID: " + vendor?.netsuiteId);
        console.log(error);
        continue;
      }
      
    } 
    res.status(200).json({ message: "UserVendor update process completed successfully." });
    return true;
  }catch (error) {
    console.error("Error in updateUserVendor:", error);
    res.status(500).json({ message: "An error occurred during the billing update process.", error });
    return false;
  }
};
export default updateUserVendor

export  const createPassword = (vendor: string, vendorID: number) => {
  const splitVendor = vendor.split(' ')
  const password = splitVendor.map((ven) => ven.substring(0, 1)).join('');
  const passwordName = password.charAt(0).toUpperCase() + password.slice(1).toLowerCase();
  return `${passwordName}${vendorID}`
}