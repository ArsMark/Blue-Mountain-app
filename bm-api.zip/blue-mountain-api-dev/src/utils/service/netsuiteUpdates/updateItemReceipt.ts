import { PrismaClient, ItemReceipt } from "@prisma/client";
import {  Request, Response } from "express";
import config from "../../config";
import fetchData from "../fetchData";
import { findPurchaseOrder } from "../fetchPurchaseOrderData";
import {processItemData} from "../fetchItemReceiptData";


const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const updateItemReceipt = async (req: Request, res: Response) => {
  try {
    const prisma = new PrismaClient();
    const itemReceipts = await prisma.itemReceipt.findMany({
      where: {
        // id: {gte: 42306},
        status: 'new',
        lastModifiedDate: {gte: new Date('2024-04-01')},
        // totalExpectedQuantity: {equals: 0},
        // OR: [{ receivedDate: new Date("1970-01-01") }],
      },
      select: {
        netsuiteId: true,
        id: true,
      },
    });
    console.log(itemReceipts.length)
    for (const itemReceipt of itemReceipts) {
      try {
        const currentHour = new Date().getHours();

        //This will terminate the api process every 3 AM
        if (currentHour > 4) {
          console.log(
            "Item receipt received date terminated at netsuite ID " +
              itemReceipt?.netsuiteId
          );
          break;
        }

        const data = await fetchData(
          `record/v1/itemreceipt/${itemReceipt.netsuiteId}`
        );

        if (!data.tranDate) {
          console.log(
            "No tranDate found for item receipt netsuite ID: " +
              itemReceipt?.netsuiteId
          );
          continue;
        }

        var purchaseOrder: any = await findPurchaseOrder(
          null,
          parseInt(data.createdFrom.id)
        );
        var purchaseOrderItems = await prisma.purchaseOrderItem.findMany({
          where: {
            purchaseOrderId: purchaseOrder?.id ?? null,
          },
        });

        var itemPath = "record/v1/itemreceipt/" + itemReceipt.netsuiteId + "/item";
        var items;
        refetch2: try {
          items = await NsApi.request({
            path: itemPath,
          });
        } catch (err) {
          break refetch2;
        }
        var get_itemreceipt = await prisma.itemReceipt.findFirst({
          where: { id: itemReceipt.id },
        });
        var processItemRecord = null
        if (get_itemreceipt) {
          //  processItemRecord = await processItemData(
          //   items.data.items,
          //   itemPath,
          //   get_itemreceipt,
          //   purchaseOrderItems
          // );
        }
       
        console.log('update status', purchaseOrder.documentStatus)
        await prisma.itemReceipt.update({
          where: {
            id: itemReceipt.id,
          },
          data: {
            status: purchaseOrder.documentStatus
            // totalDeliveredQuantity: processItemRecord?.totalQuantity,
            // totalExpectedQuantity: purchaseOrder?.totalQuantity,
            // receivedDate: new Date(data.tranDate),
          },
        });

        console.log(
          `Item receipt (Netduited ID: ${itemReceipt.netsuiteId}) received date updated to ${data.tranDate}`
        );
      } catch (error) {
        console.log("Netsuite ID: " + itemReceipt?.netsuiteId);
        console.log(error);
        continue;
      }
    }

    res.status(200).send({
      updated: `${itemReceipts.length} Item receipts updated`,
      
    });
  } catch (error) {
    console.log(error);
    res.status(500);
  }
};

export default updateItemReceipt;
