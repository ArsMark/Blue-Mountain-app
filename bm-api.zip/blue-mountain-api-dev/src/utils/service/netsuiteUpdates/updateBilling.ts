import { PrismaClient, Billing } from "@prisma/client";
import config from "../../config";
import { Request, Response } from "express";
const NsApiWrapper = require('netsuite-rest');
import { findItem } from "../fetchItemData";
import { findPurchaseOrder } from "../fetchPurchaseOrderData";
import { addVat } from "./updatePurchaseOrderItem";
import { processItemNesuite } from "../getItem";
import withVAT from "../../withVAT";

const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const prisma = new PrismaClient();

const updateBilling = async (req: Request, res: Response) => {
  try {
    const billings = await prisma.billing.findMany({
      where: {
        // id: 67870,
        // lastModifiedDate: { gte: new Date("2024-07-01") },
        // // poNumber: { equals: '' }
        // id: {gte: 66797}
        // OR: [
        //   {poNumber: { equals: '' } }
        // ]
      },
      take: 1,
      select: {
        netsuiteId: true,
        id: true,
      }
    });
    console.log('billings', billings.length)
    for (const billing of billings) {
      try {
        const currentHour = new Date().getHours();
        // console.log(currentHour > 2)
        // This will terminate the api process every 2 AM
        // if (currentHour > 2) {
        //   console.log(
        //     "billing pull out and fulfillment date terminated at netsuite ID " +
        //     billing?.netsuiteId
        //   );
        //   break;
        // }

        let newResponse = null;
        refetch1:
        try {
          newResponse = await NsApi.request({
            path: 'record/v1/vendorBill/' + billing.netsuiteId
          });
        } catch (err) {
          break refetch1;
        }

        if (!newResponse.data.tranDate) {
          console.log(
            "No tranDate found for billing netsuite ID: " + billing?.netsuiteId
          );
          continue;
        }
        const itemPath = 'record/v1/vendorBill/' + billing.netsuiteId + '/item';
        let items = null;
        refetch2:
        try {
          items = await NsApi.request({
            path: itemPath
          });
        } catch (err) {
          break refetch2;
        }

        const expensePath = 'record/v1/vendorBill/' + billing.netsuiteId + '/expense';
        let expenses = null;
        refetch3:
        try {
          expenses = await NsApi.request({
            path: expensePath
          });
        } catch (err) {
          break refetch3;
        }

        const expenseTax = await processExpenseData(expenses.data.items, expensePath);
        const processItemRecord = await processItemData(items.data.items, itemPath, billing.id);
        const netAmount =  parseFloat(newResponse.data.total)
        const totalDiscount = discounts(processItemRecord)
        
        const totalWhtax = expenseTax + processItemRecord.withHoldingTax;
        const grossAmount = netAmount + Math.abs(totalWhtax)
        console.log(netAmount, expenseTax, grossAmount, totalWhtax);
        await prisma.billing.update({
          where: {
            id: billing.id,
          },
          data: {
            grossAmount: grossAmount,
            total: netAmount,
            transactionDate: new Date(newResponse.data.tranDate ?? null),
            withHoldingTax: totalWhtax,
            ewt: processItemRecord.withHoldingTax,
            netAmount: processItemRecord.total_netAmount,
            vat: processItemRecord.total_tax,
            poNumber: processItemRecord.poNumber,
            irNumber: processItemRecord.irNumber,
            centralDropDiscount: totalDiscount.centralDropDiscount,
            centralTlcDiscount:  totalDiscount.centralTlcDiscount,
            otherSpecialDiscount:  totalDiscount.otherSpecialDiscount,
            tradeDiscount:  totalDiscount.tradeDiscount,
          }
        });
        
        
        console.log(`Updated billing (Netsuite ID: ${newResponse.data.id})`);
        
      } catch (error) {
        console.log("Netsuite ID: " + billing?.netsuiteId);
        console.log(error);
        continue;
      }
    }

    res.status(200).json({ message: "Billing update process completed successfully." });
    return true;

  } catch (error) {
    console.error("Error in updateBilling:", error);
    res.status(500).json({ message: "An error occurred during the billing update process.", error });
    return false;
  }
};


export const processItemData = async (records: string[] | any[], url: string, billing_id: number) => {
  var withHoldingTax = 0;
  var poNumber = "";
  var irNumber = "";
  var centralDropDiscount = 0
  var centralTlcDiscount = 0
  var otherSpecialDiscount = 0
  var tradeDiscount = 0
  var grossAmount = 0
  var total_tax = 0
  var total_netAmount = 0

  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf('/') + 1)
   
    var newResponse = null
    refetch4:
    try {
      newResponse = await NsApi.request({
        path: url + '/' + id
      });
    } catch (err) {
      break refetch4
    }

    if (newResponse.data) {
      var item = newResponse.data
      if (item.itemType.refName == "InvtPart") {
        
        var purchaseOrder: any = await findPurchaseOrder(null, parseInt(item.orderDoc?.id ?? 1))
        // var purchaseOrder = await prisma.purchaseOrder.findFirst({
        //   where: { netsuiteId: parseInt(item.orderDoc?.id) },
        //   select: {poNumber: true},
        // });
        if (!purchaseOrder)
          continue;
        var itemReceipt: any = await prisma.itemReceipt.findFirst({
          where: {
            poNumber: purchaseOrder.poNumber
          }
        });
        const vatItemAmount = withVAT(item.amount)
        grossAmount += vatItemAmount
        // +=
        var getItem: any = await findItem(null, parseInt(item.item?.id))
        // console.log(getItem.id)
        if (!getItem) {
          getItem = processItemNesuite(parseInt(item.item?.id))
          // console.log(getItem.id)
        }
        poNumber = purchaseOrder?.poNumber ?? ""
        irNumber = itemReceipt?.irNumber ?? ""
        var billing = await prisma.billing.findFirst({
          where: { id: billing_id},
          select:{
            subsidiaryId: true,
            lastModifiedDate: true,
          }
        });
        var netAmount = item.amount ?? 0;
        var taxAmount = (item.amount ?? 0) * 0.12;
        total_tax += taxAmount
        total_netAmount += netAmount
        var total_discount = Itemdiscounts(item)
        if (Number.isNaN(total_discount)) {
          total_discount = 0
        }
        // console.log(vatItemAmount, total_discount)

        if (billing) {
          var data = {
            type: "bill",
            transactionNo: itemReceipt?.irNumber ?? "",
            itemId: getItem?.id,
            grossAmount: vatItemAmount,
            taxAmount: taxAmount,
            quantity: item.quantity ?? 0 ,
            netAmount: netAmount,
            discount: total_discount,
            total: vatItemAmount,
            billingId: billing_id,
            subsidiaryId: billing?.subsidiaryId,
            lastModifiedDate: billing?.lastModifiedDate,
          };
          
          var billingPo = await prisma.billingPo.findFirst({
            where: { billingId: billing_id, subsidiaryId: billing?.subsidiaryId, 
                      transactionNo: itemReceipt?.irNumber, itemId: getItem.id}
          });
          if (billingPo) {
            await prisma.billingPo.update({
              where: { id: billingPo?.id },
              data: data
            });
            console.log('updated billingPo')
          } else {
            console.log('created billingPo')
            await prisma.billingPo.create({
              data: data,
            });
          }
        }
      }
     
      if (item.item.refName.includes('TOTAL CENTRAL DROP DISCOUNT')) {
        centralDropDiscount = item.amount ?? 0
      }
      if (item.item.refName.includes("TOTAL TRADE DISCOUNT")) {
        tradeDiscount = item.amount ?? 0
     
      }
      if (item.item.refName.includes('TLC DISCOUNT') ) {
        centralTlcDiscount = item.amount ?? 0
      }
      if (item.item.refName.includes('WHTAX') ) {
        withHoldingTax = item.amount ?? 0
      }
      if (item.item.refName.includes('TOTAL OTHER DISCOUNT') ) {
        otherSpecialDiscount = item.amount ?? 0
      }
    }
  
  }
  
  return {
    grossAmount,
    total_netAmount,
    total_tax,
    withHoldingTax: withHoldingTax,
    poNumber: poNumber,
    irNumber: irNumber,
    centralDropDiscount: centralDropDiscount,
    centralTlcDiscount: centralTlcDiscount,
    otherSpecialDiscount: otherSpecialDiscount,
    tradeDiscount: tradeDiscount,
  };
}

export const processExpenseData = async (records: string[] | any[], url: string) => {
  var withHoldingTax = 0;
  
  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf('/') + 1)
   
    var newResponse = null
    refetch4:
    try {
      newResponse = await NsApi.request({
        path: url + '/' + id
      });
    } catch (err) {
      break refetch4
    }

    if (newResponse.data) {
      var item = newResponse.data
     if (item.account.id == '441') {
      withHoldingTax = item.amount ?? 0
     }
    }
  
  }
  
  return withHoldingTax;

}

export const discounts = (items: any) => {
  const tctd = addVat(items.centralTlcDiscount)
  const ttd = addVat(items.tradeDiscount)
  const tcdd = addVat(items.centralDropDiscount)
  const tosd = addVat(items.otherSpecialDiscount)
  const sum = (...arr: number[]) => {
    return arr.reduce((acc, val) => Math.round((acc + val) * 100) / 100, 0); // Rounding each addition step to two decimals
  };

  var discount = sum(tctd, ttd, tcdd, tosd)

  return{
    discount: discount,
    centralTlcDiscount: tctd,
    tradeDiscount: ttd,
    centralDropDiscount: tcdd,
    otherSpecialDiscount: tosd,
  };
  
};
const changeNumber = (number: number) => {
  return Math.abs(number)
}
export const Itemdiscounts = (items: any) =>{
  const tradeDiscount = changeNumber(items.custcol_po_tradediscountamount)
  const centraldropamount =  changeNumber(items.custcol_po_centraldropamount)
  const otherdiscountamt = changeNumber(items.custcol_po_otherdiscountamt)
  const tlcamount  =  changeNumber(items.custcol_po_tlcamount)

  const item_discounts = tradeDiscount + centraldropamount + otherdiscountamt + tlcamount
  
  return item_discounts
}
export default updateBilling;