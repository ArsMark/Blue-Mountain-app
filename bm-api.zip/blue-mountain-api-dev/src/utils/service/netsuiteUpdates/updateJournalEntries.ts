import { PrismaClient, Payment } from "@prisma/client";
import { Request, Response } from "express";
import config from "../../config";
import fetchData from "../fetchData";
import { processBillData } from "../getBillData";
import { processTransactionNo } from "../getTransactionNo";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
const prisma = new PrismaClient();
interface Bill {
  previousdoc: string;
}

const updateJournalEntry = async (req: Request, res: Response) => {
  try {
    const journalEntries = await prisma.debitCreditMemo.findMany({
      where: {
        id: 18252,
        lastModifiedDate: { gte: new Date("2023-12-12") },
        AND: [
          {
            documentNumber: {
              contains: "JRNL"
            }
          },
        ],
      },
      select: {
        netsuiteId: true,
        id: true,
        createdAt: true, 
      },
    });

    console.log(journalEntries.length);

    for (const je of journalEntries) {
      try {
        const currentHour = new Date().getHours();

        const data = await fetchData(`record/v1/journalentry/${je.netsuiteId}`);
        
        if (!data.tranDate) {
          console.log("No tranDate found for journalentry netsuite ID: " + je?.netsuiteId);
          continue;
        }

        if (je.netsuiteId) {
          const nextDocData = await nextTransactionLineLink(je.netsuiteId);

          console.log(`dcm (Netsuited ID: ${data.tranId}) updated with nextDocData`);
        }
      } catch (error) {
        console.log("Netsuite ID: " + je?.netsuiteId);
        console.log(error);
        continue;
      }
    }

    res.status(200).send({ updated: 'Updated Debit Credit' });
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
};

export const nextTransactionLineLink = async (journalEntryID: number) => {
  try {
    const response = await NsApi.request({
      path: 'query/v1/suiteql',
      method: "POST",
      headers: {
        'Prefer': 'transient'
      },
      body: JSON.stringify({
        q: `SELECT * FROM nexttransactionlinelink WHERE nextdoc = ${journalEntryID}`
      })
    });
    const billings =  checkBill(response.data.items)
    // console.log(response.data.items);
    return response;
  } catch (error) {
    console.error(error);
    throw new Error('Internal Server Error');
  }
};

const checkBill = async (billings: Bill[]) => {
  let paymentID = '';
  let je_billings: number[] = [];

  for (const billing of billings) {
    paymentID = await findPayment(parseInt(billing.previousdoc));
    if (paymentID !== '') {
      break;
    }
  }

  if (paymentID !== '') {
    const payment = await prisma.payment.findFirst({
      where: { id: parseInt(paymentID) },
      include: {
        paymentInvoices: {
          include: {
            billing: true,
          },
        },
      },
    });

    if (payment && payment.paymentInvoices) {
      const billing_ids = payment.paymentInvoices.map(invoice => {
        if (invoice.billing) {
          return invoice.billing.netsuiteId;
        }
        return null; // Return null explicitly when there's no billing
      }).filter((id): id is number => id !== null && id !== undefined); // Filter out null and undefined

      je_billings = billings.map(bill => {
        return parseInt(bill.previousdoc);
      });

      if (billing_ids.length > 0 && je_billings.length > 0) {
        const jeBills = billing_ids.filter(item => !je_billings.includes(item));
        console.log(jeBills);
        if (jeBills.length > 0) {
          for (const jebill of jeBills) {
            createPaymentBill(jebill, payment)
          }
          
          // gawa ka ng paymentInvoice at debitCreditBill
        }
        else{
          // gawa ka ng debitCreditBill
        }
      }
    }
  }
};


const findPayment = async (netsuiteId: number) => {
  let paymentID = ''
  const billing = await prisma.billing.findFirst({
    where: { netsuiteId: netsuiteId }
  });
  console.log(billing?.id)
  if (billing) {
    const payment_invoice = await prisma.paymentInvoice.findFirst({
      where: { invoiceId: billing.id }
    });
    if (payment_invoice) {
      paymentID += payment_invoice?.paymentId
    }
  }
  console.log('findPayment', paymentID)
  return paymentID
}

const createPaymentBill = async (netsuiteId: number, payment: Payment) =>{
  const billing = await prisma.billing.findFirst({
    where: { netsuiteId: netsuiteId }
  });

  if (billing) {
    // var data = {
    //   netsuiteId: billing?.netsuiteId,
    //   invoiceId: billing?.id ?? null,
    //   paymentAmount: billing?.grossAmount ?? 0,
    //   type: 'Bill',
    //   createdFrom: item.createdFrom,
    //   refName: item.doc?.refName,
    //   refNum: item.refNum,
    //   apply: item.apply,
    //   applyDate: item.applyDate ? new Date(item.applyDate) : null,
    //   paymentId: payment.id,
    //   subsidiaryId: payment.subsidiaryId,
    //   lastModifiedDate: payment.lastModifiedDate,
    // };
  }
}

const createCreditBill = async (billId: number, journalEntryID: number) => {

}

export default updateJournalEntry;
