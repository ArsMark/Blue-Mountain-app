import { PrismaClient } from "@prisma/client";
import { Request, Response  } from "express";
import fetchData from "../fetchData";
import { findVendorReturnAuthorization } from "../fetchVendorReturnAuthorizationData";

const updateItemFulfillment = async (req: Request, res: Response) => {
  try {
    const prisma = new PrismaClient();
    const itemFulfillments = await prisma.itemFulfillment.findMany({
      where: {
        pullOutDate: { gte: new Date("1970-01-01") },
        fulfillmentDate: {gte: new Date("2023-01-01")},
      },
      select: {
        netsuiteId: true,
        id: true,
      },
    });
    console.log(itemFulfillments.length)
    for (const itemFulfillment of itemFulfillments) {
      try {
        const currentHour = new Date().getHours();

        //This will terminate the api process every 6 AM
        // if (currentHour > 6) {
        //   console.log(
        //     "Item fulfillment pullout date terminated at netsuite ID " +
        //       itemFulfillment?.netsuiteId
        //   );
        //   break;
        // }

        const data = await fetchData(
          `record/v1/itemFulfillment/${itemFulfillment.netsuiteId}`
        );

        if (!data.tranDate) {
          console.log(
            "No tranDate found for item fulfillment netsuite ID: " +
              itemFulfillment?.netsuiteId
          );
          continue;
        }
        var vra: any = await findVendorReturnAuthorization(
          null,
          parseInt(data.createdFrom?.id ?? null)
        );
        await prisma.itemFulfillment.update({
          where: {
            id: itemFulfillment.id,
          },
          data: {
            createdAt: new Date(data.createdDate),
            fulfillmentDate: new Date(data.tranDate),
            pullOutDate: vra.pullOutDate,
            srsNo: data.custbody_inventryadjstment_srsref,
          },
        });

        console.log(
          `Item fulfillment srsNO: ${data.custbody_inventryadjstment_srsref}
          (Netduited ID: ${itemFulfillment.netsuiteId}) pullout date updated to ${data.tranDate}`
        );
      } catch (error) {
        console.log("Netsuite ID: " + itemFulfillment?.netsuiteId);
        console.log(error);
        continue;
      }
    }

  
    res.status(200).send({
      updated: itemFulfillments.length,
    });
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
};

export default updateItemFulfillment;
