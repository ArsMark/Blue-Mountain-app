import { PrismaClient } from "@prisma/client";
import { Request, Response } from "express";
import config from "../../config";
import fetchData from "../fetchData";
import { processBillData } from "../getBillData";
import { processTransactionNo } from "../getTransactionNo";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
const prisma = new PrismaClient();
const updateDebitCreditMemo = async ( req: Request, res: Response) => {

  try {
    const prisma = new PrismaClient();
    const debitCreditmemos = await prisma.debitCreditMemo.findMany({
      where: {
        // id: {lte: 16609},
        lastModifiedDate: {gte: new Date("2024-01-17")},
        // billings: {equals: 'null'},
        OR: [
          {
            documentNumber: {
              contains: "DM"
            }
          },
          {
            documentNumber: {
              contains: "VRA"
            }
          }
        ],
      },
      take: 1,
      select: {
        netsuiteId: true,
        id: true,
        createdAt: true, 
        postingType: true
      },
    });
    console.log(debitCreditmemos.length)
    for (const dcm of debitCreditmemos) {
      try {
        const currentHour = new Date().getHours();
        // console.log(currentHour > 2)
        // This will terminate the api process every 2 AM
        if (currentHour > 2) {
          console.log(
            "dcm pull out and fulfillment date terminated at netsuite ID " +
            dcm?.netsuiteId
          );
          break;
        }
       
        const data = await fetchData(
          `record/v1/vendorCredit/${dcm.netsuiteId}`
        );
          // console.log(data.total)
        if (!data.tranDate) {
          console.log(
            "No tranDate found for dcm netsuite ID: " + dcm?.netsuiteId
          );
          continue;
        }
        const itemPath = 'record/v1/vendorCredit/' + dcm.netsuiteId + '/apply';
        let items = null;
        refetch2:
        try {
          items = await NsApi.request({
            path: itemPath
          });
        } catch (err) {
          break refetch2;
        }
        if (dcm.netsuiteId) {
          const trn_no = await processTransactionNo(dcm.netsuiteId)
          // const billing_id = await processApply(items.data.items, itemPath, dcm.id);
          console.log('updateDebitCreditMemo',trn_no)
          await prisma.debitCreditMemo.update({
            where: {
              id: dcm.id,
            },
            data: {
              documentNumber: trn_no,
              postingType: getPostingType(data.tranId, data.total)
            },
          });
  
          console.log(
            `dcm (Netsuited ID: ${data.tranId}) update posting type to ${getPostingType(data.tranId, data.total)}`
          );
        }
       
      } catch (error) {
        console.log("Netsuite ID: " + dcm?.netsuiteId);
        console.log(error);
        continue;
      }
    }

    res.status(200).send({
      updated: 'updated Debit Credit',
      // unUpdated: unUpdatedCount,
    });
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
};


export const processApply = async (
  records: string[] | any[],
  url: string,
  dcmId: any,
) => {
  var action = ''
  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf("/") + 1);
    var newResponse = null;
    refetch4: try {
      newResponse = await NsApi.request({
        path: url + "/" + id,
      });
    } catch (err) {
      break refetch4;
    }
    if (newResponse.data) {
      var item = newResponse.data;
      // console.log(records.length > 120 && x == 100 && item.apply == false)
      if (records.length > 50 && x == 40 && item.apply == false) {
        break
      }
      // bill_id = item.doc?.id
      if (item.apply == true) {
        var updated_biling = null
        var billing = await prisma.billing.findFirst({
          where: { netsuiteId: parseInt(item.doc?.id)}
        });
        if (billing === null && item.doc?.id != null) {
          if (item?.doc?.id != undefined) {
            updated_biling = (await processBillData(parseInt(item?.doc?.id))).updatedBilling
          }
         
        }
        if(updated_biling){
          billing = updated_biling
        }
  
        console.log('bill_id',billing?.id, item?.doc.id, item.apply)
        var dcb = await prisma.debitCreditBill.findFirst({
          where: {
            dcmId: dcmId,
            billingId: billing?.id
          }
        });
        if (dcb) {
          console.log('meron dcb')
          await prisma.debitCreditBill.update({
            where: {
              id: dcb.id,
            },
            data: {
              dcmId: dcmId,
              billingId: billing?.id
            }
          });
          action = 'updated'
        }
        else if(billing){
          await prisma.debitCreditBill.create({
            data: {
              dcmId: dcmId,
              billingId: billing?.id
            }
          });
          action = 'created'
        }
       
      }
    }
  
  
  }
  return {action: action}
};

function getPostingType(tranId: string, total: string ): string {
 
  return tranId.includes('DM') || tranId.includes('VRA')  ? 'Debit Memo' : 'Credit Memo';
}

export default updateDebitCreditMemo;