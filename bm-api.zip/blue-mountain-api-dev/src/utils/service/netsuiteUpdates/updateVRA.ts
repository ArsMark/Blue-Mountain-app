import { PrismaClient } from "@prisma/client";
import config from "../../config";
import { Request, Response } from "express";
import fetchData from "../fetchData";
import { processItemData } from "../fetchVendorReturnAuthorizationData";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);

const updateVRA = async (req: Request, res: Response) => {
  try {
    const prisma = new PrismaClient();
    const vras = await prisma.vendorReturnAuthorization.findMany({
      where: {
        // lastModifiedDate: 
        // id: 8030,
        // id: {gte: 7712},
        createdAt: {gte: new Date("2024-01-01")},
        // pullOutDate: new Date("1970-01-01") 
        // OR: [
        //   { updatedAt: {gte: new Date("2024-06-01")} },
        //   // { fulfillmentDate: null },
        //   // { pullOutDate: new Date("1970-01-01") },
        //   // { pullOutDate: null },
        // ],
      },
      take: 1, //remove when using this update
      select: {
        netsuiteId: true,
        id: true,
      },
    });
    console.log('total vras',vras.length)
    for (const curr_vra of vras) {
      try {
        const currentHour = new Date().getHours();

        // This will terminate the api process every 2 AM
        // if (currentHour > 2) {
        //   console.log(
        //     "VRA netsuite ID " + curr_vra?.netsuiteId
        //   );
        //   break;
        // }

        const data = await fetchData(
          `record/v1/vendorReturnAuthorization/${curr_vra.netsuiteId}`
        );

        if (!data.tranDate) {
          console.log(
            "No tranDate found for vra netsuite ID: " + curr_vra?.netsuiteId
          );
          continue;
        }

        var itemPath = "record/v1/vendorReturnAuthorization/" + curr_vra.netsuiteId + "/item";
        var vra = await prisma.vendorReturnAuthorization.findFirst({
          where: { id: curr_vra.id},
        });

        var items = null;
        refetch2: try {
          items = await NsApi.request({
            path: itemPath,
          });
        } catch (err) {
          break refetch2;
        }
        if (vra && items) {
          var processItemRecord = await processItemData(
            items.data.items,
            itemPath,
            vra
          );
          
          const totalAmount = parseFloat(data.total) - processItemRecord.totalTradeDiscount
          console.log(parseFloat(data.total))
          await prisma.vendorReturnAuthorization.update({
            where: {
              id: curr_vra.id,
            },
            data: {
              grossAmount: parseFloat(data.total),
              vraStatus: data.status?.refName ?? "",
              totalAmount:  totalAmount,
              totalTradeDiscount: processItemRecord.totalTradeDiscount,
              pullOutDate: deadlinePullOutDate(data.tranDate),
              // createdAt: new Date(data.createdDate),
              // fulfillmentDate: new Date(data.tranDate),
              // srsNumber: data.custbody_inventryadjstment_srsref
            },
          });

          console.log(
            ` srsNumber: ${data.custbody_inventryadjstment_srsref}
            VRA (Netsuited ID: ${curr_vra.netsuiteId}) pullout and fulfillment date updated to ${data.tranDate}`
          );
        }
      
      } catch (error) {
        console.log("Netsuite ID: " + curr_vra?.netsuiteId);
        console.log(error);
        continue;
      }
    }

    res.status(200).send({
      updated: 'Update VRA',
    });
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
};

export function deadlinePullOutDate(date: string) {
  const dealine_pullOutDate = new Date(date);
  dealine_pullOutDate.setDate(dealine_pullOutDate.getDate() + 30);
  return dealine_pullOutDate
}

export default updateVRA;


