import { PrismaClient, PurchaseOrder } from "@prisma/client";
import { Request, Response } from "express";
import fetchData from "../fetchData";
import {processItemData} from "../fetchPurchaseOrderData";
import withVAT from "../../withVAT";

const updatePurchaseOrderItem = async (req: Request, res: Response) => {
  try {
    const prisma = new PrismaClient();
    const purchaseOrders = await prisma.purchaseOrder.findMany({
      where: {
        id:  73386,
        // OR: [{ poDate: {gte: new Date("2023-01-17")} }],
      },
    });
    console.log('purchaseOrders', purchaseOrders.length)
    for (const purchaseOrder of purchaseOrders) {
      try {
        const currentHour = new Date().getHours();
        // console.log(currentHour > 2)
        // This will terminate the api process every 2 AM
        if (currentHour > 2) {
          console.log(
            "purchaseOrder netsuite ID " + purchaseOrder?.netsuiteId
          );
          break;
        }
        const po_data = await fetchData(
          `record/v1/purchaseOrder/${purchaseOrder.netsuiteId}`
        );
        const data = await fetchData(
          `record/v1/purchaseOrder/${purchaseOrder.netsuiteId}/item`
        );
        var itemPath = "record/v1/purchaseorder/" + purchaseOrder.netsuiteId + "/item";
        var poItem = await processItemData(
          data.items,
          itemPath,
          purchaseOrder
        );
        var vat =
        parseFloat(po_data.total) -
        (parseFloat(po_data.total) / 112) * 100;
        // console.log('withVat', addVat(poItem.totalOtherSpecialDiscount))
        await prisma.purchaseOrder.update({
          where: {
            id: purchaseOrder.id,
          },
          data: {
            totalQuantity: poItem.quantity,
            totalCases: poItem.totalCase,
            totalCentralTlcDiscount: addVat(poItem.totalCentralTlcDiscount),
            totalTradeDiscount: addVat(poItem.totalTradeDiscount),
            totalCentralDropDiscrount: addVat(poItem.totalCentralDropDiscount),
            totalOtherSpecialDiscount: addVat(poItem.totalOtherSpecialDiscount),
            vat: vat,
            subTotal: po_data.subtotal,
            deliveryDate: new Date(po_data.custbody_po_deliverydate ?? null),
          },
        });
        console.log(
          `${addVat(poItem.totalCentralDropDiscount)} Purchase Order (Netsuite ID: ${purchaseOrder.netsuiteId}) data updated`
        );
      } catch (error) {
        console.log("Netsuite ID: " + purchaseOrder?.netsuiteId);
        console.log(error);
        continue;
      }
    }
    console.log(res.status)
    res.status(200).send("Puchase order item updated successfully");
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
};

export function addVat(discount: number) {
  return discount != 0  ? withVAT(discount) : 0 
}
export default updatePurchaseOrderItem;
