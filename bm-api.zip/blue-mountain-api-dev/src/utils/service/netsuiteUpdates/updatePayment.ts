import { PrismaClient, Payment } from "@prisma/client";
import config from "../../config";
import { Request, Response  } from "express";
const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findLocation } from "../fetchLocationData";
import { findSubsidiary } from "../fetchSubsidiaryData";
import { findVendor } from "../fetchVendorData";
import { processBillData } from "../getBillData";
const prisma = new PrismaClient();
const updatePayments = async (req: Request,res: Response) => {
  
  try {
    const payment_invoices = await prisma.paymentInvoice.findMany({
      where: {
        invoiceId: null,
        updatedAt: {gte: new Date("2024-06-01")},
        lastModifiedDate: {gte: new Date("2024-06-01")}
      },
      take: 1,//remove when using this update
      select: {
        paymentId: true
      },
      distinct: ['paymentId']
    })
   
    let payment_ids = payment_invoices
      .map((payment) => payment.paymentId)
      .filter((id): id is number => id !== null);

    const payments = await prisma.payment.findMany({
      where: {
        id: {in: payment_ids},
        // id: {
        //   gte: 13799,
        // },
        // lastModifiedDate: { gt: new Date("2024-07-01")} 
        // OR: [{ cvDate: { gt: new Date("2024-01-01")} }],
      },
      select: {
        netsuiteId: true,
        id: true,
      },
    });
    console.log(payments.length)
    for (const findpayment of payments) {
      try {
        const currentHour = new Date().getHours();
        // console.log(currentHour > 2)
        // This will terminate the api process every 2 AM
        if (currentHour > 2) {
          console.log(
            "payment pull out and fulfillment date terminated at netsuite ID " +
            findpayment?.netsuiteId
          );
          break;
        }
        
      var newResponse = null;
      refetch1: try {
        newResponse = await NsApi.request({
          path: "record/v1/vendorPayment/" + findpayment.netsuiteId,
        });
      } catch (err) {
        break refetch1;
      }
 
      if (newResponse.data.tranId < 0) continue;

      if (newResponse.data.tranId) {
        var subsidiaryId: any = await findSubsidiary(
          null,
          parseInt(newResponse.data.subsidiary.id)
        );
        if (subsidiaryId) {
          var locationId: any = newResponse.data.location
          ? await findLocation(null, parseInt(newResponse.data.location.id))
          : null;
        var vendorId: any = newResponse.data.entity
          ? await findVendor(null, parseInt(newResponse.data.entity?.id ?? null))
          : null;

        var paymentType = null;
        refetch2: try {
          paymentType = await NsApi.request({
            path: "record/v1/account/" + newResponse.data.account?.id,
          });
        } catch (err) {
          break refetch2;
        }

        paymentType = paymentType.data;
        var data = {
          transactionNo: newResponse.data.tranId ?? "",
          cvNumber: newResponse.data.tranId ?? "",
          cvDate: new Date(newResponse.data?.tranDate ?? null),
          debitMemo: 0, // Need To Update
          creditMemo: 0, // Need To Update
          journal: 0, // Need To Update
          netAmount: 0, // Need To Update
          totalWithHoldingTax: 0, // Need To Update
          date: new Date(newResponse.data.tranDate ?? null),
          createdAt: new Date(newResponse.data.createdDate ?? null),
          amount: newResponse.data.total ?? "",
          releaseDate: new Date(newResponse.data?.tranDate ?? null),
          currency: newResponse.data.currency?.refName ?? "",
          netsuiteId: parseInt(newResponse.data.id),
          paymentMethod: paymentType.acctType?.refName ?? "",
          bank: paymentType.acctName ?? "",
          checkNumber: newResponse.data.custbody_check_checknumber ?? null,
          vendorId: vendorId,
          subsidiaryId: subsidiaryId,
          warehouseLocationId: locationId,
          lastModifiedDate: new Date(newResponse.data.lastModifiedDate),
        };

        var payment = await prisma.payment.findFirst({
          where: { netsuiteId: findpayment.netsuiteId},
        });
     
        if (payment) {
          payment = await prisma.payment.update({
            where: { id: payment?.id },
            data: data,
          });
          console.log('Updated Payment')
        } else {
          payment = await prisma.payment.create({
            data: data,
          });
          console.log('Created Payment')
        }
        var itemPath = "record/v1/vendorPayment/" + findpayment.netsuiteId + "/apply";
        var items = null;
        refetch3: try {
          items = await NsApi.request({
            path: itemPath,
          });
        } catch (err) {
          break refetch3;
        }

        await processItemData(items.data.items, itemPath, payment);
        console.log(`updated Payment netsuite ID ${findpayment.id}`)
      }
      
      }
      }
    catch (error) {
      // console.log("Netsuite ID: " + findpayment.netsuiteId);
      console.log(error);
      continue;
    }
    }

    res.status(200).send({
      updated: 'done'
    });
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
};

export const processItemData = async (
  records: string[] | any[],
  url: string,
  payment: Payment
) => {
  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf("/") + 1);

    var newResponse = null;
    refetch4: try {
      newResponse = await NsApi.request({
        path: url + "/" + id,
      });
    } catch (err) {
      break refetch4;
    }
    var item = newResponse.data;
   
    if (item.apply == true) {
      var updated_biling = null
      console.log(item.doc?.id)
      var billing = await prisma.billing.findFirst({
        where: { netsuiteId: parseInt(item.doc?.id) }
      });
      const check_billing = billing?.id ?? null
      if (check_billing === null && item.doc?.id != null) {
        if (item?.doc?.id != undefined) {
          updated_biling = (await processBillData(parseInt(item?.doc?.id))).updatedBilling
        }
       
      }
      console.log(billing?.id, 'billing_id')
      console.log(updated_biling?.id, 'new billing')
      
      var data = {
        netsuiteId: 0,
        invoiceId: billing?.id ?? updated_biling?.id,
        paymentAmount: item.total ?? 0,
        type: item.type,
        createdFrom: item.createdFrom,
        refName: item.doc?.refName,
        refNum: item.refNum,
        apply: item.apply,
        applyDate: item.applyDate ? new Date(item.applyDate) : null,
        paymentId: payment.id,
        subsidiaryId: payment.subsidiaryId,
        lastModifiedDate: payment.lastModifiedDate,
      };
      var payment_invoice = await prisma.paymentInvoice.findFirst({
        where: {  paymentId: payment.id,  subsidiaryId: payment.subsidiaryId, 
                  refNum: item.refNum }
      });
      if (payment_invoice) {
        await prisma.paymentInvoice.update({
          where: { id: payment_invoice.id },
          data: data,
        });
        console.log('Payment Invoice Updated')
      } else {
        await prisma.paymentInvoice.create({
          data: data,
        });
        console.log('Payment Invoice Created')
      }
      
    }
  
  }
};

export default updatePayments;