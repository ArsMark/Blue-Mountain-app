import { PrismaClient } from "@prisma/client";
import {  Request, Response  } from "express";
import config from "../../config";
import fetchData from "../fetchData";

const NsApiWrapper = require('netsuite-rest');
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
const prisma = new PrismaClient();
const updateWarehouseLocation = async ( res: Response) => {

  try {
    const prisma = new PrismaClient();
    const warehouseLocations = await prisma.warehouseLocation.findMany({
      where: {
      id: {gte: 733},
      updatedAt: {gte: new Date('2023-10-02')},
      },
      take: 1,//remove when using this update
      select: {
        netsuiteId: true,
        id: true,
      },
    });
    console.log(warehouseLocations.length)
    for (const location of warehouseLocations) {
      try {
        const currentHour = new Date().getHours();
        // console.log(currentHour > 2)
        // This will terminate the api process every 2 AM
        if (currentHour > 2) {
          console.log(
            "location netsuite ID " + location?.netsuiteId
          );
          break;
        }
       
        const data = await fetchData(
          `record/v1/location/${location.netsuiteId}`
        );
          // console.log(data.total)
        if (!data) {
          console.log(
            "No data found for location netsuite ID: " + location?.netsuiteId
          );
          continue;
        }
        const addressPath = 'record/v1/location/' + location.netsuiteId + '/mainAddress';
        let address = null;
        refetch2:
        try {
          address = await NsApi.request({
            path: addressPath
          });
        } catch (err) {
          break refetch2;
        }
        console.log(address.data.addrText)
     
        await prisma.warehouseLocation.update({
          where: {
            id: location.id,
          },
          data: {
            address: address.data.addrText
          },
        });

        console.log(
          `warehouseLocation (Netsuited ID: ${data.netsuiteId}) updated address `
        );
      } catch (error) {
        console.log("Netsuite ID: " + location?.netsuiteId);
        console.log(error);
        continue;
      }
    }

    res.status(200).send({
      updated: 'updated Debit Credit',
      // unUpdated: unUpdatedCount,
    });
  } catch (error) {
    console.log(error);
    res.sendStatus(500);
  }
};

export default updateWarehouseLocation;