import config from "../config";
import { PrismaClient, PurchaseOrder } from "@prisma/client";

const NsApiWrapper = require("netsuite-rest");
const NsApi = new NsApiWrapper(config.NETSUITE_CONFIG);
import { findSubsidiary } from "./fetchSubsidiaryData";
import { findVendor } from "./fetchVendorData";
import { findLocation } from "./fetchLocationData";
import { findItem } from "./fetchItemData";
import { addVat } from "./netsuiteUpdates/updatePurchaseOrderItem";
import { notificationTypes } from "../../data/notificationTypes";

const prisma = new PrismaClient();
const limit = 1000;
let totalCount = 0;

export const getPurchaseOrderData = async () => {
  totalCount = 0;
  const existingRecords = await prisma.purchaseOrder.findMany({
    orderBy: [
      {
        lastModifiedDate: "desc",
      },
    ],
    take: 1,
  });

  var query = "";
  if (existingRecords.length) {
    var lastModifiedDate = new Date(existingRecords[0].lastModifiedDate).toLocaleDateString();
    query = '&q=lastModifiedDate after "' + lastModifiedDate + '"';
  }
  
  // query = '&q=lastModifiedDate after "06/01/2024"';
  var response = await NsApi.request({
    path: "record/v1/purchaseorder?limit=" + limit + query,
  });

  const records = response.data.items;


  // const testResponse= await NsApi.request({
  //   path: "record/v1/purchaseorder/" + "5810627",
  // });

  // console.log("CHECK FOR  5810627")
  // console.log(testResponse)
  await processPurchaseOrderData(
    records,
    query,
    response.data.hasMore,
    response.data.links[0].href,
    1
  );

  return true;
};

const processPurchaseOrderData = async (
  records: string[] | any[],
  query: string,
  hasMore: boolean,
  link: string,
  page: number
) => {
  console.log(query, 'Puchase Order',  records.length)
  for (var x = 0; x < records.length; x++) {
    var newResponse = null;
    refetch1: try {
      newResponse = await NsApi.request({
        path: "record/v1/purchaseorder/" + records[x].id,
      });
    } catch (err) {
      break refetch1;
    }
    if (newResponse.data.tranId) {
     
      var subsidiaryId: any = newResponse.data.subsidiary ? 
        await findSubsidiary(null, parseInt(newResponse.data.subsidiary.id)) 
          : null
      if (subsidiaryId) {
        
        var locationId: any = await findLocation(
          null,
          parseInt(newResponse.data.location.id)
        );
        var vendorId: any = await findVendor(
          null,
          parseInt(newResponse.data.entity.id)
        );
        var data = {
          poNumber: newResponse.data.tranId,
          poDate: new Date(newResponse.data.createdDate),
          deliveryDate: new Date(
            newResponse.data.custbody_po_deliverydate ?? null
          ),
          deliveryArea: newResponse.data.custbody_po_deliveryarea?.refName ?? "",
          totalCases: 0,
          totalQuantity: 0,
          status: "new",
          location: newResponse.data.location.refName ?? "",
          documentStatus: newResponse.data.status.refName ?? "",
          terms: newResponse.data.custbody_po_terms ?? "",
          shippingAddress: newResponse.data.shipAddress,
          remarks: newResponse.data.custbody_po_remarks ?? "",
          preparedBy: newResponse.data.custbody_all_preparedby ?? "",
          checkedBy: newResponse.data.custbody_po_checkedby ?? "",
          approvedBy: newResponse.data.custbody_po_approvedby ?? "",
          subTotal: newResponse.data.subtotal,
          subsidiaryId: subsidiaryId,
          vendorId: vendorId,
          totalTradeDiscount: 0,
          totalCentralDropDiscrount: 0,
          totalCentralTlcDiscount: 0,
          totalOtherSpecialDiscount: 0,
          warehouseLocationId: locationId,
          totalAmount: 0,
          vat: 0,
          grandTotal: newResponse.data.total,
          lastModifiedDate: newResponse.data.lastModifiedDate,
          createdAt: newResponse.data.createdDate,
          netsuiteId: parseInt(records[x].id),
        };
  
        var purchaseorder = await prisma.purchaseOrder.findFirst({
          where: { netsuiteId: parseInt(records[x].id) },
        });
        if (purchaseorder) {
          purchaseorder = await prisma.purchaseOrder.update({
            where: { id: purchaseorder?.id },
            data: data,
          });
          console.log('updated netsuiteId', newResponse.data.id)
        } else {
          purchaseorder = await prisma.purchaseOrder.create({
            data: data,
          });
          console.log( "Created",
            "{ \n Purchase Order Number:" +
              newResponse.data.tranId +
              " \n ID: " +
              newResponse.data.id +
              " \n Created Date: " +
              newResponse.data.createdDate +
              " \n }"
          );
        }
  
        var itemPath = "record/v1/purchaseorder/" + records[x].id + "/item";
        var items = null;
        refetch2: try {
          items = await NsApi.request({
            path: itemPath,
          });
        } catch (err) {
          break refetch2;
        }
  
        var responseData = await processItemData(
          items.data.items,
          itemPath,
          purchaseorder
        );
  
        var vat = parseFloat(newResponse.data.total) - (parseFloat(newResponse.data.total) / 112) * 100;
          const tctd = addVat(responseData.totalCentralTlcDiscount)
          const ttd = addVat(responseData.totalTradeDiscount)
          console.log(newResponse.data.id, 'totalTradeDiscount',ttd)
          const tcdd = addVat(responseData.totalCentralDropDiscount)
          const tosd = addVat(responseData.totalOtherSpecialDiscount)
          const total_amount = newResponse.data.total - vat - tctd - ttd - tcdd - tosd
        
        await prisma.purchaseOrder.update({
          where: { id: purchaseorder?.id },
          data: {
            totalQuantity: responseData.quantity,
            totalCases: responseData.totalCase,
            totalCentralTlcDiscount: tctd,
            totalTradeDiscount: ttd,
            totalCentralDropDiscrount: tcdd,
            totalOtherSpecialDiscount: tosd,
            vat: vat,
            totalAmount: total_amount
          },
        });
  
        totalCount++;
      }
     
    }
  }
  if (hasMore) {
    refetch4: try {
      var response = await NsApi.request({
        path:
          "record/v1/purchaseorder?limit=" +
          limit +
          "&offset=" +
          page * limit +
          query,
      });
      records = response.data.items;
    } catch (err) {
      break refetch4;
    }
    await processPurchaseOrderData(
      records,
      query,
      response.data.hasMore,
      response.data.links[0].href,
      page + 1
    );
  }

  await prisma.notification.create({
    data: {
      title: "New Purchase Orders Alert ",
      description:
        "0 new purchase orders have been received, please review and take necessary actions.",
      type: notificationTypes.purchaseOrder,
      subsidiaryId: 1,
    },
  });
};


export const processItemData: any = async (
  records: string[] | any[],
  url: string,
  purchaseorder: PurchaseOrder
) => {
  var quantity = 0;
  var totalCase = 0;
  var totalCentralTlcDiscount = 0;
  var totalTradeDiscount = 0;
  var totalCentralDropDiscount = 0;
  var totalOtherSpecialDiscount = 0;

  await prisma.purchaseOrderItem.deleteMany({
    where: {
      purchaseOrderId: purchaseorder.id,
    },
  });
  for (var x = 0; x < records.length; x++) {
    var link: string = records[x].links[0].href;
    var id = link.substr(link.lastIndexOf("/") + 1);
    var newResponse = null;
    refetch3: try {
      newResponse = await NsApi.request({
        path: url + "/" + id,
      });
    } catch (err) {
      break refetch3;
    }

    var newResponse = await NsApi.request({
      path: url + "/" + id,
    });
    var item = newResponse.data;

    if (item.item.id == "730")
      totalCentralTlcDiscount += parseFloat(item.amount);
    else if (item.item.id == "728")
      totalTradeDiscount += parseFloat(item.amount);
    else if (item.item.id == "729")
      totalCentralDropDiscount += parseFloat(item.amount);
    else if (item.item.id == "731")
      totalOtherSpecialDiscount += parseFloat(item.amount);
    else {
      var itemData: any = await findItem(null, parseInt(item.item.id));
   
      var data = {
        // poNumber: newResponse.data.tranId,
        barcode: itemData?.barcode ?? "",
        description: item.item.refName ?? "",
        quantity: item.quantity ?? 0,
        cost: item.rate ?? item.cost,
        // rate: item.rate ?? 0,
        amount: item.amount ?? 0,
        netsuiteId: 0,
        itemId: itemData?.id,
        subsidiaryId: purchaseorder.subsidiaryId,
        purchaseOrderId: purchaseorder.id,
        lastModifiedDate: purchaseorder.lastModifiedDate,
      };
      quantity += parseInt(item.quantity ?? 0);
      if (itemData)
        totalCase +=
          itemData.conversionToCase != null && itemData.conversionToCase != 0
            ? parseInt(item.quantity ?? 0) / itemData.conversionToCase
            : 0;

        await prisma.purchaseOrderItem.create({
          data: data,
        });
    }
  }

  return {
    quantity: quantity,
    totalCase: totalCase,
    totalCentralTlcDiscount: totalCentralTlcDiscount,
    totalTradeDiscount: totalTradeDiscount,
    totalCentralDropDiscount: totalCentralDropDiscount,
    totalOtherSpecialDiscount: totalOtherSpecialDiscount,
  };
};

export const findPurchaseOrder = async (
  url: string | null,
  id: number | null
) => {
  var purchaseOrderId = id;

  if (!purchaseOrderId) {
    var netsuitePurchaseOrder = await NsApi.request({
      path: url,
    });

    netsuitePurchaseOrder = netsuitePurchaseOrder.data.items[0];
    purchaseOrderId = parseInt(netsuitePurchaseOrder.id);
  }
  var purchaseOrder = await prisma.purchaseOrder.findFirst({
    where: { netsuiteId: purchaseOrderId },
  });

  return purchaseOrder;
};
