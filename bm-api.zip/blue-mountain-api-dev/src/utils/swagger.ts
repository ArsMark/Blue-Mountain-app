import { Express } from "express";
import swaggerJsDoc, { Options } from "swagger-jsdoc";
import swaggerUi from "swagger-ui-express";

const options: Options = {
  definition: {
    openapi: "3.1.0",
    info: {
      title: "Blue Mountain",
      description: "API Documentaion",
      version: "1.0.0",
    },
    components: {
      securitySchemes: {
        bearerAuth: {
          type: "apiKey",
          name: "Authorization",
          in: "header",
          scheme: "bearer",
          bearerFormat: "JWT",
        },
      },
    },
  },
  apis: ["src/routes/*.ts"],
};

const spec = swaggerJsDoc(options);

const swagger = (app: Express) => {
  app.use("/api", swaggerUi.serve, swaggerUi.setup(spec));
};

export default swagger;
