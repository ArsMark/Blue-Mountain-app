import config from "./config";

const logger = (data: any) => {
  if (config.ENVIRONMENT === "DEVELOPMENT" || true) {
    console.log(data);
  }
};

export default logger;
