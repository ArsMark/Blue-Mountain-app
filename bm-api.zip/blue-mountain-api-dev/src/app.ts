import bodyParser from "body-parser";
import cookieParser from "cookie-parser";
import cors from "cors";
import ejs from "ejs";
import express from "express";
import morgan from "morgan";
import routes from "./routes";
import config from "./utils/config";
import swagger from "./utils/swagger";

const app = express();

app.set("views", "src/views");
app.set("view engine", ejs);
app.use(cors());
app.use(express.json());
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(morgan("tiny"));

app.get("/", (req, res) => res.render("index.ejs"));

app.use("/api", routes);

app.listen(config.PORT, async () => {
  process.env.TZ = config.TIME_ZONE;

  console.log(
    `Application is running at port ${config.PORT} in ${config.ENVIRONMENT} mode!`
  );

  swagger(app);
});
