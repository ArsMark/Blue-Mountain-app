import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import warehouseLocationController from "../controllers/warehouseLocationController";

const warehouseLocationRoute = Router();

/**
 * @swagger
 * /api/warehouseLocations:
 *   get:
 *     tags: [Warehouse Locations]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: q
 *         description: Search (optional)
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Success
 */

warehouseLocationRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        subsidiaryId: Joi.number(),
      })
    );

    const warehouseLocations =
      await warehouseLocationController.getWarehouseLocations(req.query);

    return res.status(200).send(warehouseLocations);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/warehouseLocations/{warehouseLocationId}:
 *   get:
 *     tags: [Warehouse Locations]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: warehouseLocationId
 *         description: Warehouse Location ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

warehouseLocationRoute.get(
  "/:warehouseLocationId",
  verifyUser,
  async (req, res) => {
    try {
      await validateFilter(
        req.params,
        Joi.object({
          warehouseLocationId: Joi.number(),
        })
      );
      const warehouseLocation =
        await warehouseLocationController.getWarehouseLocation(
          +req.params
        );

      return res.status(200).send(warehouseLocation);
    } catch (error: any) {
      if (isValidationError(error)) return res.status(400).send(error.message);

      logger(error);
      return res.sendStatus(500);
    }
  }
);

export default warehouseLocationRoute;
