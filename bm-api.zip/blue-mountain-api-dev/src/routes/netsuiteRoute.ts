import netsuiteController from "../controllers/netsuiteController";
import { Router } from "express";

const netsuiteRoute = Router();

netsuiteRoute.get("/subsidiary", netsuiteController.getSubsidiary);
netsuiteRoute.get("/vendor", netsuiteController.getVendor);
netsuiteRoute.get("/location", netsuiteController.getLocation);
netsuiteRoute.get("/inventoryItem", netsuiteController.getInventoryItem);
netsuiteRoute.get("/purchaseOrder", netsuiteController.getPurchaseOrder);
netsuiteRoute.get(
  "/vendorReturnAuthorization",
  netsuiteController.getVendorReturnAuthorization
);
netsuiteRoute.get("/creditMemo", netsuiteController.getCreditMemo);
netsuiteRoute.get("/journalEntries", netsuiteController.getJournalEntry);
netsuiteRoute.get("/itemReceipt", netsuiteController.getItemReceiptData);
netsuiteRoute.get("/billing", netsuiteController.getBillingData);
netsuiteRoute.get("/payment", netsuiteController.getPaymentData);
netsuiteRoute.get(
  "/itemFulfillment",
  netsuiteController.getItemFulfillmentData
);
netsuiteRoute.get("/processAllTable", netsuiteController.processAllTable);
netsuiteRoute.get("/update/vra", netsuiteController.getUpdateVRA);
netsuiteRoute.get(
  "/update/item-receipt",
  netsuiteController.getUpdateItemReceipt
);
netsuiteRoute.get(
  "/update/item-fulfillment",
  netsuiteController.getUpdateItemFulfillment
);
netsuiteRoute.get(
  "/update/purchase-order-item",
  netsuiteController.getUpdatePurchaseOrderItem
);

netsuiteRoute.get(
  "/update/debit-credit-memo",
  netsuiteController.getUpdateDebitCredit
);

netsuiteRoute.get(
  "/update/billing",
  netsuiteController.getupdateBilling
);

netsuiteRoute.get(
  "/update/warehouselocation",
  netsuiteController.getupdateWarehouseLocation
);

netsuiteRoute.get(
  "/update/payment",
  netsuiteController.getUpdatePayment
);

netsuiteRoute.get(
  "/update/userVendor",
  netsuiteController.getupdateUserVendor
);

netsuiteRoute.get(
  "/update/JournalEntry",
  netsuiteController.getupdateJournalEntry
);


export default netsuiteRoute;