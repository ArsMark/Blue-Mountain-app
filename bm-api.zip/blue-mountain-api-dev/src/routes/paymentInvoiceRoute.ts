import paymentInvoiceController from "../controllers/paymentInvoiceController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import activityLogController from "../controllers/activityLogController";

const paymentInvoiceRoute = Router();

/**
 * @swagger
 * /api/payments/invoices:
 *   get:
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each pagination (optional, required if page is defined)
 *         schema:
 *          type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *          type: string
 *          pattern: ^(asc|desc)$
 *       - in: query
 *         name: paymentAmount
 *         description: Payment Invoice amount (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: invoiceId
 *         description: Invoice ID (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *          type: number
 *     responses:
 *       200:
 *         description: Success
 */

paymentInvoiceRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        paymentAmount: Joi.number(),
        subsidiaryId: Joi.number(),
        invoiceId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: `viewed the payment invoices`,
    });

    const paymentInvoices = await paymentInvoiceController.getPaymentInvoices(
      req.query
    );

    return res.status(200).send(paymentInvoices);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/payments/invoices/{paymentInvoiceId}:
 *   get:
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: paymentInvoiceId
 *         description: Payment Invoice ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

paymentInvoiceRoute.get("/:paymentInvoiceId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        paymentInvoiceId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed a payment invoice`,
    });

    const paymentInvoice = await paymentInvoiceController.getPaymentInvoice(
      +req.params.paymentInvoiceId
    );

    return res.status(200).send(paymentInvoice);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/payments/invoices/seed:
//  *   post:
//  *     tags: [Seeders, Payments]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// paymentInvoiceRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const paymentInvoices =
//       await paymentInvoiceController.seedPaymentInvoices();

//     return res.status(201).send(paymentInvoices);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default paymentInvoiceRoute;
