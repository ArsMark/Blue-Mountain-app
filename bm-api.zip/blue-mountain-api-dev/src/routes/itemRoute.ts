import { Router } from "express";
import Joi from "joi";
import activityLogController from "../controllers/activityLogController";
import itemController from "../controllers/itemController";
import verifyUser from "../middlewares/verifyUser";
import logger from "../utils/logger";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import itemFulfillmentRoute from "./itemFulfillmentRoute";
import itemReceiptRoute from "./itemReceiptRoute";

const itemRoute = Router();

itemRoute.use("/receipts", itemReceiptRoute);
itemRoute.use("/fulfillments", itemFulfillmentRoute);

/**
 * @swagger
 * /api/items:
 *   get:
 *     tags: [Items]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each pagination (optional, required if page is defined)
 *         schema:
 *          type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *          type: string
 *          pattern: ^(asc|desc)$
 *       - in: query
 *         name: name
 *         description: Item name (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: barcode
 *         description: Item barcode (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: description
 *         description: Item description (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: cost
 *         description: Item cost (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: isRead
 *         description: Item read status (optional)
 *         schema:
 *          type: boolean
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *          type: number
 *     responses:
 *       200:
 *         description: Success
 */

itemRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        name: Joi.string(),
        barcode: Joi.string(),
        description: Joi.string(),
        cost: Joi.number(),
        isRead: Joi.boolean(),
        subsidiaryId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed the items`,
    });

    const items = await itemController.getItems({
      ...req.query,
      user: req.user,
    });

    return res.status(200).send(items);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/items/{itemId}:
 *   get:
 *     tags: [Items]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: itemId
 *         description: Item ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

itemRoute.get("/:itemId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        itemId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed an item`,
    });

    const item = await itemController.getItem({
      itemId: +req.params.itemId,
      userId: req.user.id,
      role: req.user.role
    });

    return res.status(200).send(item);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/items/seed:
//  *   post:
//  *     tags: [Seeders, Items]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// itemRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const items = await itemController.seedItems();

//     return res.status(201).send(items);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default itemRoute;
