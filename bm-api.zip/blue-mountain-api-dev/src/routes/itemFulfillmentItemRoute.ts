import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import itemFulfillmentItemController from "../controllers/itemFulfillmentItemController";
import activityLogController from "../controllers/activityLogController";

const itemFulfillmentItemRoute = Router();

/**
 * @swagger
 * /api/items/fulfillments/items:
 *   get:
 *     tags: [Items]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *     responses:
 *       200:
 *         description: Success
 */

itemFulfillmentItemRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        subsidiaryId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed the fulfillment items`,
    });

    const itemFulfillmentItems =
      await itemFulfillmentItemController.getItemFulfillmentItems(req.query);

    return res.status(200).send(itemFulfillmentItems);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/items/fulfillments/items/{itemFulfillmentItemId}:
 *   get:
 *     tags: [Items]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: itemFulfillmentItemId
 *         description: Item Fulfillment Item ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

itemFulfillmentItemRoute.get(
  "/:itemFulfillmentItemId",
  verifyUser,
  async (req, res) => {
    try {
      await validateFilter(
        req.params,
        Joi.object({
          itemFulfillmentItemId: Joi.number(),
        })
      );

      await activityLogController.addActivityLog({
        userId: req.body.id,
        action: `viewed a fulfillment item`,
      });

      const itemFulfillmentItem =
        await itemFulfillmentItemController.getItemFulfillmentItem(
          +req.params.itemFulfillmentItemId
        );

      return res.status(200).send(itemFulfillmentItem);
    } catch (error: any) {
      if (isValidationError(error)) return res.status(400).send(error.message);

      logger(error);
      return res.sendStatus(500);
    }
  }
);

// /**
//  * @swagger
//  * /api/items/fulfillments/items/seed:
//  *   post:
//  *     tags: [Items]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// itemFulfillmentItemRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const itemFulfillmentItems =
//       await itemFulfillmentItemController.seedItemFulfillmentItems();

//     return res.status(201).send(itemFulfillmentItems);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default itemFulfillmentItemRoute;
