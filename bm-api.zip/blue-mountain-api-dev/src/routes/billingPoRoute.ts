import billingPoController from "../controllers/billingPoController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import activityLogController from "../controllers/activityLogController";

const billingPoRoute = Router();

/**
 * @swagger
 * /api/billings/pos:
 *   get:
 *     tags: [Billings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: type
 *         description: Billing PO type (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: transactionNo
 *         description: Billing PO transaction Number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: grossAmount
 *         description: Billing PO gross amount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: taxAmount
 *         description: Billing PO tax amount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: netAmount
 *         description: Billing PO net amount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: discount
 *         description: Billing PO discount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: total
 *         description: Billing PO total (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

billingPoRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        type: Joi.string(),
        transactionNo: Joi.string(),
        grossAmount: Joi.number(),
        taxAmount: Joi.number(),
        netAmount: Joi.number(),
        discount: Joi.number(),
        total: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed the puchase orders`,
    });

    const billingPos = await billingPoController.getBillingPos(req.query);

    return res.status(200).send(billingPos);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/billings/pos/{billingPoId}:
 *   get:
 *     tags: [Billings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: billingPoId
 *         description: Billing PO ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

billingPoRoute.get("/:billingPoId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        billingPoId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed a puchase order`,
    });

    const billingPo = await billingPoController.getBillingPo(
      +req.params.billingPoId
    );

    return res.status(200).send(billingPo);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/billings/pos/seed:
//  *   post:
//  *     tags: [Seeders, Billings]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// billingPoRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const billingPos = await billingPoController.seedBiillingPos();

//     return res.status(201).send(billingPos);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default billingPoRoute;
