import { Router } from "express";
import Joi from "joi";
import { Payment, Subsidiary, Vendor } from "@prisma/client";

import activityLogController from "../controllers/activityLogController";
import paymentController from "../controllers/paymentController";
import verifyUser from "../middlewares/verifyUser";
import csv from "../utils/csv";
import logger from "../utils/logger";
import { isValidationError } from "../utils/validations";
import {
  dateRangeFormat,
  validateFilter,
} from "../utils/validations/filterValidation";
import paymentCreditMemoRoute from "./paymentCreditMemoRoute";
import paymentInvoiceRoute from "./paymentInvoiceRoute";

const paymentRoute = Router();

paymentRoute.use("/invoices", paymentInvoiceRoute);
paymentRoute.use("/creditMemos", paymentCreditMemoRoute);

/**
 * @swagger
 * /api/payments:
 *   get:
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: csv
 *         description: Result as CSV (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: q
 *         description: Search (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each pagination (optional, required if page is defined)
 *         schema:
 *          type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *          type: string
 *          pattern: ^(asc|desc)$
 *       - in: query
 *         name: transactionNo
 *         description: Payment transaction number (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: amount
 *         description: Payment amount (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: currency
 *         description: Currency (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: paymentMethod
 *         description: Payment method (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: bank
 *         description: Bank used for payment (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: checkNumber
 *         description: Check number (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: vendorName
 *         description: Vendor name (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: isRead
 *         description: Read status (optional)
 *         schema:
 *          type: boolean
 *       - in: query
 *         name: dateRange
 *         description: Filter by date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: releaseDateRange
 *         description: Filter by date released from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: cvDateRange
 *         description: CV date released from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: cvNumber
 *         description: CV Number (optional)
 *         schema:
 *          type: string
 *       - in: query
 *         name: debitMemo
 *         description: Debit Memo (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: creditMemo
 *         description: Credit Memo (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: journal
 *         description: Journal (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: netAmount
 *         description: Net Amount (optional)
 *         schema:
 *          type: number
 *       - in: query
 *         name: totalWithHoldingTax
 *         description: Total With Holding Tax (optional)
 *         schema:
 *          type: number
 *     responses:
 *       200:
 *         description: Success
 */

paymentRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        csv: Joi.boolean(),
        cvNumber: Joi.string(),
        debitMemo: Joi.number(),
        creditMemo: Joi.number(),
        journal: Joi.number(),
        netAmount: Joi.number(),
        totalWithHoldingTax: Joi.number(),
        transactionNo: Joi.string(),
        amount: Joi.number(),
        currency: Joi.number(),
        paymentMethod: Joi.string(),
        bank: Joi.string(),
        checkNumber: Joi.string(),
        vendorName: Joi.string(),
        subsidiaryId: Joi.number(),
        isRead: Joi.boolean(),
        cvDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        dateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        releaseDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: `viewed the payments`,
    });

    const payments: any = await paymentController.getPayments({
      ...req.query,
      user: req.user,
    });

    if (req.query.csv === "true") {
      type TData = Payment;
      const data: Array<
        TData & {
          subsidiary: Subsidiary;
          vendor: Vendor;
        }
      > = payments.payments;

      const csvData = data.map((data) => ({
        ["TRANSACTION #"]: data.transactionNo,
        ...(req.user.role !== "vendor" && {
          ["VENDOR NAME"]: data.vendor.name,
        }),
        ["CHECK DATE"]: data.date,
        ["AMOUNT"]: +data.amount,
        ["RELEASE DATE"]: data.releaseDate,
      }));

      return csv({
        response: res,
        filename: "payments",
        data: csvData,
      });
    }

    return res.status(200).send(payments);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/payments/{paymentId}:
 *   get:
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: paymentId
 *         description: Payment ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

paymentRoute.get("/:paymentId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        paymentId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed a payment`,
    });

    const payment = await paymentController.getPayment({
      paymentId: +req.params.paymentId,
      userId: req.user.id,
      role: req.user.role
    });

    return res.status(200).send(payment);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/payments/seed:
//  *   post:
//  *     tags: [Seeders, Payments]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// paymentRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const payments = await paymentController.seedPayments();

//     return res.status(201).send(payments);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default paymentRoute;
