import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import moduleController from "../controllers/moduleController";

const moduleRoute = Router();

/**
 * @swagger
 * /api/modules/count:
 *   get:
 *     tags: [Modules]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: isRead
 *         description: Read Status (Optional)
 *         schema:
 *           type: boolean
 *         example: false
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID
 *         schema:
 *           type: number
 *         required: true
 *     responses:
 *       200:
 *         description: Success
 */

moduleRoute.get("/count", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        isRead: Joi.boolean(),
        subsidiaryId: Joi.number().required(),
      })
    );

    const items = await moduleController.getModuleCounts({
      ...(req.query as any),
      user: req.user,
    });

    return res.status(200).send(items);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

export default moduleRoute;
