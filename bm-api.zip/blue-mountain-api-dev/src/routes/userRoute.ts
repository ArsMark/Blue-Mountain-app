import userController from "../controllers/userController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import activityLogController from "../controllers/activityLogController";
import verifyResetPassword from "../middlewares/verifyResetPassword";
import verifyRole from "../middlewares/verifyRole";

const userRoute = Router();

/**
 * @swagger
 *  /api/users:
 *    post:
 *      tags: [Users]
 *      requestBody:
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                userFirstName:
 *                  type: string
 *                  required: true
 *                userLastName:
 *                  type: string
 *                  required: true
 *                userEmail:
 *                  type: string
 *                  format: email
 *                  required: true
 *                userPassword:
 *                  type: string
 *                  format: password
 *                  required: true
 *                userRole:
 *                  type: string
 *                  required: true
 *                userVendorId:
 *                  type: number
 *      responses:
 *        201:
 *          description: Success
 */

userRoute.post("/", async (req, res) => {
  try {
    const {
      userFirstName,
      userLastName,
      userPassword,
      userRole,
      userEmail,
      userVendorId,
    } = req.body;

    await validateFilter(
      {
        userFirstName,
        userLastName,
        userPassword,
        userRole,
        userEmail,
        userVendorId,
      },
      Joi.object({
        userFirstName: Joi.string().required(),
        userLastName: Joi.string().required(),
        userEmail: Joi.string().required().email(),
        userPassword: Joi.string().required(),
        userRole: Joi.string().required(),
        userVendorId: Joi.number().min(1).when("userRole", {
          is: "vendor",
          then: Joi.required(),
          otherwise: Joi.forbidden(),
        }),
      })
    );

    const user = await userController.createUser({
      firstName: userFirstName,
      lastName: userLastName,
      password: userPassword,
      role: userRole,
      email: userEmail,
      vendorId: userVendorId,
    });

    return res.status(201).send(user);
  } catch (error: any) {
    console.log(error);

    if (isValidationError(error) || error.name === "user")
      return res.status(400).send(error.message);

    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/users:
 *   get:
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *     responses:
 *       200:
 *         description: Success
 */

userRoute.get(
  "/",
  verifyUser,
  verifyRole(["admin", "developer"]),
  async (req, res) => {
    try {
      await validateFilter(req.query);

      const users = await userController.getUsers(req.query);

      await activityLogController.addActivityLog({
        userId: req.body.id,
        action: `viewed a user details`,
      });

      return res.status(200).send(users);
    } catch (error: any) {
      console.log(error);

      if (isValidationError(error)) return res.status(400).send(error.message);

      return res.sendStatus(500);
    }
  }
);

/**
 * @swagger
 *  /api/users/changePassword:
 *    patch:
 *      tags: [Users]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                currentPassword:
 *                  type: string
 *                  required: true
 *                newPassword:
 *                  type: string
 *                  required: true
 *                confirmNewPassword:
 *                  type: string
 *                  required: true
 *      responses:
 *        200:
 *          description: Success
 */

userRoute.patch("/changePassword", verifyUser, async (req, res) => {
  try {
    const { id, currentPassword, newPassword, confirmNewPassword } = req.body;

    await validateFilter(
      { currentPassword, newPassword, confirmNewPassword },
      Joi.object({
        currentPassword: Joi.string().required(),
        newPassword: Joi.string().required(),
        confirmNewPassword: Joi.string()
          .required()
          .valid(Joi.ref("newPassword"))
          .messages({
            "any.only": "Passwords do not match",
          }),
      })
    );

    const user = await userController.updateUserPassword({
      userId: id,
      currentPassword,
      newPassword: confirmNewPassword,
    });

    return res.status(200).send(user);
  } catch (error: any) {
    if (isValidationError(error) || error.name === "user")
      return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 *  /api/users/resetPasswordLink:
 *    post:
 *      tags: [Users]
 *      requestBody:
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                email:
 *                  type: string
 *                  format: email
 *                  required: true
 *                link:
 *                  type: string
 *                  required: true
 *      responses:
 *        201:
 *          description: Success
 */

userRoute.post("/resetPasswordLink", async (req, res) => {
  try {
    const { email, link } = req.body;

    await validateFilter(
      { email, link },
      Joi.object({
        email: Joi.string().email().required(),
        link: Joi.string().required(),
      })
    );

    const user = await userController.sendResetPasswordLink({ email, link });

    return res.status(201).send(user);
  } catch (error: any) {
    if (isValidationError(error) || error.name === "user")
      return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 *  /api/users/resetPassword:
 *    patch:
 *      tags: [Users]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                newPassword:
 *                  type: string
 *                  required: true
 *                confirmNewPassword:
 *                  type: string
 *                  required: true
 *      responses:
 *        200:
 *          description: Success
 */

userRoute.patch("/resetPassword", verifyResetPassword, async (req, res) => {
  try {
    const { newPassword, confirmNewPassword, id } = req.body;

    await validateFilter(
      { newPassword, confirmNewPassword },
      Joi.object({
        newPassword: Joi.string().required(),
        confirmNewPassword: Joi.string()
          .required()
          .valid(Joi.ref("newPassword"))
          .messages({
            "any.only": "Passwords do not match",
          }),
      })
    );

    const user = await userController.updateUserPassword({
      userId: id,
      reset: true,
      newPassword: confirmNewPassword,
    });

    return res.status(200).send(user);
  } catch (error: any) {
    if (isValidationError(error) || error.name === "user")
      return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 *  /api/users/verifyResetPasswordToken:
 *    get:
 *      tags: [Users]
 *      security:
 *        - bearerAuth: []
 *      responses:
 *        200:
 *          description: Success
 */

userRoute.get(
  "/verifyResetPasswordToken",
  verifyResetPassword,
  async (req, res) => {
    try {
      return res.status(200).send(req.body);
    } catch (error: any) {
      logger(error);
      return res.sendStatus(500);
    }
  }
);

export default userRoute;
