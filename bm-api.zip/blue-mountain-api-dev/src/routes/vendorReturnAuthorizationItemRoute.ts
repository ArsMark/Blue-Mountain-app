import vendorReturnAuthorizationItemController from "../controllers/vendorReturnAuthorizationItemController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import activityLogController from "../controllers/activityLogController";

const vendorReturnAuthorizationItemRoute = Router();

/**
 * @swagger
 * /api/vendors/returnAuthorizations/items:
 *   get:
 *     tags: [Vendors]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: grossNet
 *         description: Gross/Net (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: subsidiaryId
 *         description: SubsidiaryId (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: totalAmount
 *         description: Total Amount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: quantity
 *         description: Quantity (optional)
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

vendorReturnAuthorizationItemRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        grossNet: Joi.number(),
        subsidiaryId: Joi.number(),
        totalAmount: Joi.string(),
        quantity: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed the vendor authorization items`,
    });

    const vendorReturnAuthorizationItems: any =
      await vendorReturnAuthorizationItemController.getVendorReturnAuthorizationItems(
        req.query
      );

    return res.status(200).send(vendorReturnAuthorizationItems);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/vendors/returnAuthorizations/items/{vendorReturnAuthorizationItemId}:
 *   get:
 *     tags: [Vendors]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: vendorReturnAuthorizationItemId
 *         description: Vendor Return Authorization Item ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

vendorReturnAuthorizationItemRoute.get(
  "/:vendorReturnAuthorizationItemId",
  verifyUser,
  async (req, res) => {
    try {
      await validateFilter(
        req.params,
        Joi.object({
          vendorReturnAuthorizationItemId: Joi.number(),
        })
      );

      await activityLogController.addActivityLog({
        userId: req.body.id,
        action: `viewed a vendor authorization item`,
      });

      const vendorReturnAuthorizationItem =
        await vendorReturnAuthorizationItemController.getVendorReturnAuthorizationItem(
          +req.params.vendorReturnAuthorizationItemId
        );

      return res.status(200).send(vendorReturnAuthorizationItem);
    } catch (error: any) {
      if (isValidationError(error)) return res.status(400).send(error.message);

      logger(error);
      return res.sendStatus(500);
    }
  }
);

// /**
//  * @swagger
//  * /api/vendors/returnAuthorizations/items/seed:
//  *   post:
//  *     tags: [Vendors]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// vendorReturnAuthorizationItemRoute.post(
//   "/seed",
//   verifyUser,
//   async (req, res) => {
//     try {
//       const vendorReturnAuthorizationItems =
//         await vendorReturnAuthorizationItemController.seedVendorReturnAuthorizationItems();

//       return res.status(201).send(vendorReturnAuthorizationItems);
//     } catch (error) {
//       logger(error);
//       return res.sendStatus(500);
//     }
//   }
// );

export default vendorReturnAuthorizationItemRoute;
