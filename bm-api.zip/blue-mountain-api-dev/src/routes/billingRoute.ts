import { Router } from "express";
import Joi from "joi";
import activityLogController from "../controllers/activityLogController";
import billingController from "../controllers/billingController";
import verifyUser from "../middlewares/verifyUser";
import csv from "../utils/csv";
import logger from "../utils/logger";
import { isValidationError } from "../utils/validations";
import {
  dateRangeFormat,
  validateFilter,
} from "../utils/validations/filterValidation";
import billingPoRoute from "./billingPoRoute";
import { Prisma, PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
const billingRoute = Router();
import multer from 'multer';
const upload = multer({ 
  storage: multer.memoryStorage() 
});
billingRoute.use("/pos", billingPoRoute);

/**
 * @swagger
 * /api/billings:
 *   get:
 *     tags: [Billings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: terms
 *         description: Billing terms (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: currency
 *         description: Billing currency (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: poNumber
 *         description: Billing PO number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: billingNumber
 *         description: Billing number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: vendorName
 *         description: Vendor name (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: dueDateRange
 *         description: Filter by due date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: transactionDateRange
 *         description: Filter by transaction date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: subsidiaryId
 *         description: SubsidiaryId (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: counterReceiptNumber
 *         description: Counter Receipt Number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: supplierInvoiceReference
 *         description: Supplier Invoice Reference (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: grossAmount
 *         description: Gross Amount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: withHoldingTax
 *         description: With Holding Tax (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: docStartDateRange
 *         description: Filter by doc start date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: docEndDateRange
 *         description: Filter by doc end date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: dateModifiedRange
 *         description: Filter by modified date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: cbrStatus
 *         description: CBR Status (optional)
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Success
 */

billingRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        docStartDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        docEndDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        dateModifiedRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        cbrStatus: Joi.string(),
        counterReceiptNumber: Joi.string(),
        supplierInvoiceReference: Joi.string(),
        grossAmount: Joi.number(),
        withHoldingTax: Joi.number(),
        terms: Joi.string(),
        currency: Joi.string(),
        poNumber: Joi.string(),
        billingNumber: Joi.string(),
        vendorName: Joi.string(),
        subsidiaryId: Joi.number(),
        dueDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        transactionDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: "viewed billings",
    });

    const billings = await billingController.getBilligs({
      ...req.query,
      user: req.user,
    });

    return res.status(200).send(billings);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/billings/monthly:
 *   get:
 *     tags: [Billings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: csv
 *         description: Result as CSV (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: q
 *         description: Search (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: vendorName
 *         description: Vendor Name (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: docDateRange
 *         description: Filter by doc date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: postDateRange
 *         description: Filter by posted date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: isRead
 *         description: Read Status (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: warehouseLocationId
 *         description: Warehouse Location ID (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: cbrStatus
 *         description: CBR Status (optional)
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Success
 */

billingRoute.get("/monthly", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        csv: Joi.boolean(),
        isRead: Joi.boolean(),
        subsidiaryId: Joi.number(),
        vendorName: Joi.string(),
        warehouseLocationId: Joi.number(),
        cbrStatus: Joi.string(),
        docDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        postDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
      })
    );
    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: "viewed monthly billings",
    });

    const billings: any = await billingController.getMonthlyBillings({
      ...req.query,
      user: req.user,
    });


    if (req.query.csv === "true") {
      type TData = {
        transactionMonth: string;
        startDate: Date;
        endDate: Date;
        dateModified: Date;
        cbrStatus: string;
        isRead: boolean;
        vendorId: number;
        vendorName: string;
      };
      const data: Array<TData> = billings.billings;

      const csvData = data.map((data) => {
        return {
          ...(req.user.role === "vendor" && {
            ["VENDOR NAME"]: data.vendorName,
          }),
          ["DOC START DATE"]: data.startDate,
          ["DOC END DATE"]: data.endDate,
          ["DATE MODIFIED"]: data.dateModified,
          ["CRB STATUS"]: data.cbrStatus,
          ["READ STATUS"]: data.isRead ? "read" : "unread",
        };
      });

      return csv({
        response: res,
        filename: "billings",
        data: csvData,
      });
    }

    return res.status(200).send(billings);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/billings/monthly/{yearMonth}:
 *   get:
 *     tags: [Billings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: yearMonth
 *         description: Year-Month (yyyy-mm)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}$
 *       - in: query
 *         name: vendorId
 *         description: Vendor ID
 *         schema:
 *           type: number
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

billingRoute.get("/monthly/:yearMonth", verifyUser, async (req, res) => {
  try {
    const yearMonth = req.params.yearMonth;

    await validateFilter(
      { ...req.query, yearMonth },
      Joi.object({
        vendorId: Joi.number().required(),
        yearMonth: Joi.string()
          .required()
          .regex(/^[0-9]{4}-[0-9]{2}$/, `"yyyy-mm"`),
        subsidiaryId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: `viewed the ${yearMonth} billings`,
    });

    const billings = await billingController.getBillingsByYearMonth({
      ...(req.query as any),
      yearMonth,
      user: req.user,
    });
    return res.status(200).send(billings);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/billings/cbrStatuses:
 *   get:
 *     tags: [Billings,Statuses]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

billingRoute.get("/cbrStatuses", verifyUser, async (req, res) => {
  try {
    const cbrStatuses = await billingController.getCbrStatuses();

    return res.status(200).send(cbrStatuses);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/billings/{billingId}:
 *   get:
 *     tags: [Billings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: billingId
 *         description: Billing ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

billingRoute.get("/:billingId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        billingId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: `viewed a billing`,
    });

    const billing = await billingController.getBilling({
      billingId: +req.params.billingId,
      userId: req.user.id,
      role: req.user.role
    });

    return res.status(200).send(billing);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});


billingRoute.post("/upsertBilling", verifyUser, async (req, res) => {
  try {
    await billingController.upsertBillingByNumber(req, res);
  } catch (error: any) {
    console.error("Error in upsertBilling route: ", error);
  }
});


billingRoute.post("/upload-billings",verifyUser, upload.single('excelFile'), async (req, res) => {
  try {
    await billingController.processExcelFile(req, res); 
    console.log("File data: ", req.file); 
  } catch (error: any) {
    console.error("Error in upload-billings route: ", error);
  }
});

billingRoute.post("/update-transaction-month", verifyUser, upload.single('excelFile'), async (req, res) => {
  try {
    return await billingController.updateTransactionMonth(req, res);
    console.log("Transaction month update file processed.");
  } catch (error: any) {
    console.error("Error in update-transaction-month route: ", error);
  }
});

export default billingRoute;
