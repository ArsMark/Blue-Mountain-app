import vendorController from "../controllers/vendorController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import vendorReturnAuthorizationRoute from "./vendorReturnAuthorizationRoute";
import activityLogController from "../controllers/activityLogController";

const vendorRoute = Router();

vendorRoute.use("/returnAuthorizations", vendorReturnAuthorizationRoute);

/**
 * @swagger
 * /api/vendors:
 *   get:
 *     tags: [Vendors]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *     responses:
 *       200:
 *         description: Success
 */

vendorRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(req.query);

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed the vendors`,
    });

    const vendors = await vendorController.getVendors(req.query);

    res.send(vendors);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/vendors/{vendorId}:
 *   get:
 *     tags: [Vendors]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: vendorId
 *         description: Vendor ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

vendorRoute.get("/:vendorId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        vendorId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed a vendor`,
    });

    const vendor = await vendorController.getVendor(+req.params.vendorId);

    return res.status(200).send(vendor);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/vendors/seed:
//  *   post:
//  *     tags: [Seeders, Vendors]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// vendorRoute.post("/seed", async (req, res) => {
//   try {
//     const vendors = await vendorController.seedVendors();

//     return res.status(201).send(vendors);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default vendorRoute;
