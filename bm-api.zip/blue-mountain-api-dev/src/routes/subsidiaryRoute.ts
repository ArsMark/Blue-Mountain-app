import { Router } from "express";
import Joi from "joi";
import activityLogController from "../controllers/activityLogController";
import subsidiaryController from "../controllers/subsidiaryController";
import verifyUser from "../middlewares/verifyUser";
import logger from "../utils/logger";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";

const subsidiaryRoute = Router();

/**
 * @swagger
 * /api/subsidiaries:
 *   get:
 *     tags: [Subsidiaries]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *     responses:
 *       200:
 *         description: Success
 */

subsidiaryRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(req.query);

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed the subsidiaries`,
    });

    const subsidiaries = await subsidiaryController.getSubsidiaries(req.query);

    return res.status(200).send(subsidiaries);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/subsidiaries/{subsidiaryId}:
 *   get:
 *     tags: [Subsidiaries]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: subsidiaryId
 *         description: Subsidiary ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

subsidiaryRoute.get("/:subsidiaryId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        subsidiaryId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed a subsidiary`,
    });

    const subsidiary = await subsidiaryController.getSubsidiary(
      +req.params.subsidiaryId
    );

    return res.status(200).send(subsidiary);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/subsidiaries/init:
//  *   post:
//  *     tags: [Subsidiaries]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// subsidiaryRoute.post("/init", verifyUser, async (req, res) => {
//   try {
//     const subsidiaries = await subsidiaryController.seedSubsidiaries();

//     return res.status(201).send(subsidiaries);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default subsidiaryRoute;
