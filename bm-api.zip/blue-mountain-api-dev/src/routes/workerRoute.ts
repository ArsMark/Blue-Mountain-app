import { Request, Response, Router } from "express";
import {jobQueue} from "../helpers/queue/jobQueue"

const workerRoute = Router()

workerRoute.get("/status", async (req: Request, res:Response) => {
    try {
        
        const activeJobs = await jobQueue.getActive();
        const waitingJobs = await jobQueue.getWaiting();
        const isFetching = activeJobs.length > 0 || waitingJobs.length > 0;
        const isBillFetching = activeJobs.filter((job: any) =>job.name == "pullBillingData").length > 0
        const isBillOnQueue = isBillFetching ? false : waitingJobs.filter((job: any) =>job.name == "pullBillingData").length > 0
        const isPaymentFetching = activeJobs.filter((job: any) =>job.name == "pullPaymentData").length > 0
        const isPaymentOnQueue = isPaymentFetching ? false : waitingJobs.filter((job: any) =>job.name == "pullPaymentData").length > 0
        return res.status(200).json({
            message:"Worker Status Check",
            data:{
                activeJobs,
                waitingJobs,
                bill:{
                    isFetching: isBillFetching,
                    onQueue: isBillOnQueue
                },
                payment : {
                    isFetching: isPaymentFetching,
                    onQueue: isPaymentOnQueue
                },
                isFetching
            },
            code:200
        })
    } catch (error: any) {
        return res.status(500).json({
            message : "Internal Server Error",
            code: 500
        })
    }
})

export default workerRoute;