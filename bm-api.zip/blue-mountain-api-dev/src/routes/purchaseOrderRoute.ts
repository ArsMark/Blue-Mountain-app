import purchaseOrderController from "../controllers/purchaseOrderController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import {
  dateRangeFormat,
  validateFilter,
} from "../utils/validations/filterValidation";
import purchaseOrderItemRoute from "./purchaseOrderItemRoute";
import activityLogController from "../controllers/activityLogController";
import {
  PurchaseOrder,
  Subsidiary,
  Vendor,
  WarehouseLocation,
} from "@prisma/client";
import csv from "../utils/csv";

const purchaseOrderRoute = Router();

purchaseOrderRoute.use("/items", purchaseOrderItemRoute);

/**
 * @swagger
 * /api/purchaseOrders:
 *   get:
 *     tags: [Purchase Orders]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: csv
 *         description: Result as CSV (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: q
 *         description: Search (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: poNumber
 *         description: PO number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: preparedBy
 *         description: Name of person who prepared the purchase order  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: checkedBy
 *         description: Name of person who checked the purchase order  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: approvedBy
 *         description: Name of person who approved the purchase order  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: remarks
 *         description: Remarks  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: totalAmount
 *         description: Total amount  (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: totalAmount
 *         description: Shipping address  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: terms
 *         description: Terms  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: terms
 *         description: Terms  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: totalCases
 *         description: Total cases  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: deliveryArea
 *         description: Delivery Area  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: vendorName
 *         description: Vendor name  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: deliveryDateRange
 *         description: Filter by delivery date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: poDateRange
 *         description: Filter by PO date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: subsidiaryId
 *         description: SubsidiaryID (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: isRead
 *         description: Read Status (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: warehouseLocationId
 *         description: Warehouse Location ID (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: documentStatus
 *         description: Document Status (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: status
 *         description: Purchase Order Status (optional)
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Success
 */

purchaseOrderRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        csv: Joi.boolean(),
        poNumber: Joi.string(),
        preparedBy: Joi.string(),
        checkedBy: Joi.string(),
        remarks: Joi.string(),
        approvedBy: Joi.string(),
        totalAmount: Joi.number(),
        shippingAddress: Joi.string(),
        warehouseLocationId: Joi.number(),
        terms: Joi.string(),
        totalCases: Joi.string(),
        deliveryArea: Joi.string(),
        vendorName: Joi.string(),
        subsidiaryId: Joi.number(),
        isRead: Joi.boolean(),
        documentStatus: Joi.string(),
        status: Joi.string(),
        deliveryDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        poDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: `viewed the purchase orders`,
    });

    const purchaseOrders: any = await purchaseOrderController.getPurchaseOrders(
      { ...req.query, user: req.user }
    );

    if (req.query.csv === "true") {
      type TData = PurchaseOrder;
      const data: Array<
        TData & {
          subsidiary: Subsidiary;
          vendor: Vendor;
          warehouseLocation: WarehouseLocation;
          isRead: boolean;
        }
      > = purchaseOrders.purchaseOrders;

      const csvData = data.map((data) => {
        return {
          ["PO NUMBER"]: data.poNumber,
          ...(req.user.role !== "vendor" && {
            ["VENDOR NAME"]: data.vendor.name,
          }),
          ["DATE"]: data.poDate,
          ["TOTAL QUANTITY"]: data.totalQuantity,
          ["DOCUMENT STATUS"]: data.documentStatus,
          ["STORE/WAREHOUSE LOCATION"]: data.warehouseLocation.address,
          ["AMOUNT"]: +data.totalAmount,
          ["READ STATUS"]: data.isRead ? "read" : "unread",
        };
      });

      return csv({
        response: res,
        filename: "purchase_orders",
        data: csvData,
      });
    }

    return res.status(200).send(purchaseOrders);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/purchaseOrders/documentStatuses:
 *   get:
 *     tags: [Purchase Orders,Statuses]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

purchaseOrderRoute.get("/documentStatuses", verifyUser, async (req, res) => {
  try {
    let role: string | undefined = req.query.role as string;
    // Ensure role is a string, otherwise set a default value

    const documentStatuses =
      await purchaseOrderController.getDocumentStatuses(req.user.role);

    return res.status(200).send(documentStatuses);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/purchaseOrders/statuses:
 *   get:
 *     tags: [Purchase Orders,Statuses]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

purchaseOrderRoute.get("/statuses", verifyUser, async (req, res) => {
  try {
    const statuses = await purchaseOrderController.getStatuses();

    return res.status(200).send(statuses);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/purchaseOrders/{purchaseOrderId}:
 *   get:
 *     tags: [Purchase Orders]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: purchaseOrderId
 *         description: Purchase Order ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

purchaseOrderRoute.get("/:purchaseOrderId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        purchaseOrderId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed a purchase order`,
    });

    const purchaseOrder = await purchaseOrderController.getPurchaseOrder({
      purchaseOrderId: +req.params.purchaseOrderId,
      userId: req.user.id,
      role: req.user.role
    });

    return res.status(200).send(purchaseOrder);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/purchaseOrders/seed:
//  *   post:
//  *     tags: [Seeders, Purchase Orders]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// purchaseOrderRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const purchaseOrders = await purchaseOrderController.seedPurchaseOrders();

//     return res.status(201).send(purchaseOrders);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default purchaseOrderRoute;
