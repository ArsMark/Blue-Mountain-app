import itemReceiptController from "../controllers/itemReceiptController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import {
  dateRangeFormat,
  validateFilter,
} from "../utils/validations/filterValidation";
import itemReceiptItemsRoute from "./itemReceiptItemsRoute";
import activityLogController from "../controllers/activityLogController";
import {
  ItemReceipt,
  Subsidiary,
  Vendor,
  WarehouseLocation,
} from "@prisma/client";
import csv from "../utils/csv";

const itemReceiptRoute = Router();

itemReceiptRoute.use("/items", itemReceiptItemsRoute);

/**
 * @swagger
 * /api/items/receipts:
 *   get:
 *     tags: [Items]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: csv
 *         description: Result as CSV (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: q
 *         description: Search (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: poNumber
 *         description: PO number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: supplierInvoiceReference
 *         description: Supplier invoice reference (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: preparedBy
 *         description: Name of person who prepared the item receipt  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: checkedBy
 *         description: Name of person who checked the item receipt  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: approvedBy
 *         description: Name of person who approved the item receipt  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: receivedBy
 *         description: Name of person who received the item receipt  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: vendorName
 *         description: Vendor name  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: receivedDateRange
 *         description: Filter by date received from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: poDateRange
 *         description: Filter by PO date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID  (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: isRead
 *         description: Read Status  (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: status
 *         description: Status  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: warehouseLocationId
 *         description: Warehouse Location ID (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: vendorInvoiceNumber
 *         description: Vendor Invoice Number  (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: totalQuantity
 *         description: Total Quantity  (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: amount
 *         description: Amount  (optional)
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

itemReceiptRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        csv: Joi.boolean(),
        totalQuantity: Joi.number(),
        amount: Joi.number(),
        poNumber: Joi.string(),
        supplierInvoiceReference: Joi.string(),
        preparedBy: Joi.string(),
        checkedBy: Joi.string(),
        approvedBy: Joi.string(),
        receivedBy: Joi.string(),
        subsidiaryId: Joi.number(),
        vendorName: Joi.string(),
        isRead: Joi.boolean(),
        status: Joi.string(),
        warehouseLocationId: Joi.number(),
        vendorInvoiceNumber: Joi.string(),
        irNumber: Joi.string(),
        receivedDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        poDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: `viewed the item receipts`,
    });

    const itemReceipts: any = await itemReceiptController.getItemReceipts({
      ...req.query,
      user: req.user,
    });

    if (req.query.csv === "true") {
      type TData = ItemReceipt & {
        vendor: Vendor;
        warehouseLocation: WarehouseLocation;
        subsidiary: Subsidiary;
        isRead: boolean;
      };
      const data: Array<TData> = itemReceipts.itemReceipts;

      const csvData = data.map((data) => {
        return {
          ["P.O. NO."]: data.poNumber,
          ["VENDOR INVOICE NO."]: data.vendorInvoiceNumber,
          ["IR NUMBER"]: data.irNumber,
          ...(data.vendor && {
            ["VENDOR NAME"]: data.vendor.name,
          }),
          ["RECEIVED DATE"]: data.receivedDate,
          ["STORE/WAREHOUSE LOCATION"]: data.warehouseLocation.address,
          ["TOTAL AMOUNT"]: +data.amount,
          ["READ STATUS"]: data.isRead ? "read" : "unread",
        };
      });

      return csv({
        response: res,
        filename: "item_receipts",
        data: csvData,
      });
    }

    return res.status(200).send(itemReceipts);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/items/receipts/statuses:
 *   get:
 *     tags: [Items,Statuses]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

itemReceiptRoute.get("/statuses", verifyUser, async (req, res) => {
  try {
    const statuses = await itemReceiptController.getStatuses();

    return res.status(200).send(statuses);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/items/receipts/{itemReceiptId}:
 *   get:
 *     tags: [Items]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: itemReceiptId
 *         description: Item Receipt ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

itemReceiptRoute.get("/:itemReceiptId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        itemReceiptId: Joi.number(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed an item receipt`,
    });

    const itemReceipt = await itemReceiptController.getItemReceipt({
      itemReceiptId: +req.params.itemReceiptId,
      userId: req.user.id,
      role:  req.user.role
    });

    return res.status(200).send(itemReceipt);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/items/receipts/seed:
//  *   post:
//  *     tags: [Seeders, Items]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// itemReceiptRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const itemReceipts = await itemReceiptController.seedItemReceipts();

//     return res.status(201).send(itemReceipts);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default itemReceiptRoute;
