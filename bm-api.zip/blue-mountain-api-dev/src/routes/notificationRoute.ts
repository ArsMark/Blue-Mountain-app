import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import notificationController from "../controllers/notificationController";
import { notificationTypes } from "../data/notificationTypes";
import verifyRole from "../middlewares/verifyRole";

const notificationRoute = Router();

/**
 * @swagger
 * /api/notifications:
 *   get:
 *     tags: [Notifications]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: subsidiaryId
 *         description: Subsidiary ID (optional)
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

notificationRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        subsidiaryId: Joi.number(),
      })
    );

    const notifications = await notificationController.getNotifications({
      ...req.query,
      user: req.user,
    });

    return res.status(200).send(notifications);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/notifications:
 *   post:
 *     tags: [Notifications]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *                 required: true
 *               description:
 *                 type: string
 *                 required: true
 *               type:
 *                 type: string
 *                 required: true
 *               subsidiaryId:
 *                 type: number
 *                 required: true
 *     responses:
 *       201:
 *         description: Success
 */

notificationRoute.post(
  "/",
  verifyUser,
  verifyRole(["developer"]),
  async (req, res) => {
    try {
      const { title, description, type, subsidiaryId, role } = req.body;
      const notifTypes = Object.values(notificationTypes);

      await validateFilter(
        { title, description, type, subsidiaryId, role },
        Joi.object({
          subsidiaryId: Joi.number().required(),
          title: Joi.string().required(),
          description: Joi.string().required(),
          type: Joi.string()
            .valid(...notifTypes)
            .required()
            .messages({
              "any.only": `Type must only be ${notifTypes
                .map((notifType) => `"${notifType}"`)
                .slice(0, notifTypes.length - 1)
                .join(", ")}, or "${notifTypes[notifTypes.length - 1]}"`,
            }),
          role: Joi.string().valid("admin").messages({
            "any.only": "Seeding failed, you must be an admin to continue",
          }),
        })
      );
      const notifications = await notificationController.addNotification({
        subsidiaryId,
        title,
        description,
        type,
      });
      return res.status(201).send(notifications);
    } catch (error: any) {
      if (isValidationError(error)) return res.status(400).send(error.message);

      logger(error);
      return res.sendStatus(500);
    }
  }
);

/**
 * @swagger
 * /api/notifications/types:
 *   get:
 *     tags: [Notifications]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

notificationRoute.get("/types", verifyUser, async (req, res) => {
  try {
    const notifTypes = Object.values(notificationTypes);

    return res.status(200).send(notifTypes);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

// /**
//  * @swagger
//  * /api/notifications/seed:
//  *   post:
//  *     tags: [Notifications, Seeders]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       200:
//  *         description: Success
//  */

// notificationRoute.post("/seed",verifyUser, async (req, res) => {
//   try {
//     const notifications = await notificationController.seedNotifications();

//     return res.status(200).send(notifications);
//   } catch (error: any) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default notificationRoute;
