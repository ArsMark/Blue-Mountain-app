import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import departmentController from "../controllers/departmentController";
import messageController from "../controllers/messageController";

const messageRoute = Router();

/**
 * @swagger
 * /api/messages:
 *   get:
 *     tags: [Messages]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

messageRoute.get("/", verifyUser, async (req, res) => {
  try {
    const messages = await messageController.getMessages();

    return res.status(200).send(messages);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/messages/{messageId}:
 *   get:
 *     tags: [Messages]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: messageId
 *         description: Message ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

messageRoute.get("/:messageId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        messageId: Joi.number().required(),
      })
    );

    const message = await messageController.getMessage(+req.params.messageId);

    return res.status(200).send(message);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/messages:
 *   post:
 *     tags: [Messages]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               fullName:
 *                 type: string
 *                 required: true
 *               senderEmail:
 *                 type: string
 *                 required: true
 *               departmentId:
 *                 type: number
 *                 required: true
 *               subject:
 *                 type: string
 *                 required: true
 *               content:
 *                 type: string
 *                 required: true
 *     responses:
 *       201:
 *         description: Success
 */

messageRoute.post("/", verifyUser, async (req, res) => {
  try {
    const { fullName, senderEmail, departmentId, subject, content } = req.body;
    await validateFilter(
      { fullName, senderEmail, departmentId, subject, content },
      Joi.object({
        fullName: Joi.string().required(),
        senderEmail: Joi.string().required().email(),
        departmentId: Joi.number().required(),
        subject: Joi.string().required(),
        content: Joi.string().required(),
      })
    );

    const department = await messageController.sendMessage({
      fullName,
      email: senderEmail,
      departmentId,
      subject,
      content,
    });

    return res.status(201).send(department);
  } catch (error: any) {
    if (isValidationError(error) || error.name === "department")
      return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

export default messageRoute;
