import activityLogController from "../controllers/activityLogController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import csv from "../utils/csv";
import { ActivityLog, User } from "@prisma/client";

const activityLogRoute = Router();

/**
 * @swagger
 * /api/activityLogs:
 *   get:
 *     tags: [Activity Logs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: csv
 *         description: Result as CSV (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: q
 *         description: Search (optional)
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Success
 */

activityLogRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        csv: Joi.boolean(),
      })
    );

    const activityLogs: any = await activityLogController.getActivityLogs({
      ...req.query,
      user: req.user,
    });

    if (req.query.csv === "true") {
      type TData = ActivityLog & { user: User };
      const data: Array<TData> = activityLogs.activityLogs;

      const csvData = data.map((data) => ({
        activity: data.action,
        date: data.createdAt,
        time: data.createdAt.toLocaleTimeString(),
      }));

      return csv({
        response: res,
        filename: "activity_logs",
        data: csvData,
      });
    }

    return res.status(200).send(activityLogs);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/activityLogs/{activityLogId}:
 *   get:
 *     tags: [Activity Logs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: activityLogId
 *         description: Activity Log ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

activityLogRoute.get("/:activityLogId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        activityLogId: Joi.number().required(),
      })
    );

    const activityLog = await activityLogController.getActivityLog(
      +req.params.activityLogId
    );

    return res.status(200).send(activityLog);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/activityLogs:
 *   post:
 *     tags: [Activity Logs]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               action:
 *                 type: string
 *                 required: true
 *     responses:
 *       201:
 *         description: Success
 */

activityLogRoute.post("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      { action: req.body.action },
      Joi.object({
        action: Joi.string().required().lowercase(),
      })
    );

    const activityLog = await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `${req.body.action}`,
    });

    return res.status(201).send(activityLog);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

export default activityLogRoute;
