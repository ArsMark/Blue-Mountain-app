import userController from "../controllers/userController";
import { Router } from "express";
import logger from "../utils/logger";
import { isValidationError } from "../utils/validations";
import { validateLogin } from "../utils/validations/authValidation";
import { compareSync } from "bcrypt";
import verifyUser from "../middlewares/verifyUser";
import {
  TokenName,
  generateAccessToken,
  generateRefreshedAccessToken,
} from "../utils/token";
import config from "../utils/config";
import activityLogController from "../controllers/activityLogController";
import { User } from "@prisma/client";

const authRoute = Router();

/**
 * @swagger
 *  /api/auth/login:
 *    post:
 *      tags: [Authentication]
 *      requestBody:
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                email:
 *                  type: string
 *                  format: email
 *                  required: true
 *                password:
 *                  type: string
 *                  format: password
 *                  required: true
 *      responses:
 *        200:
 *          description: Success
 */

authRoute.post("/login", async (req, res) => {
  try {
    await validateLogin(req.body);
    const user = await userController.getUser({
      email: req.body.email,
      includePassword: true,
    });

    if (!compareSync(req.body.password, `${user?.password}`)) {
      return res.status(400).send("Invalid email/password");
    }

    const { password, ...userWithoutPassword } = user as User;

    const accessToken = generateAccessToken(userWithoutPassword);
    const refreshedToken = generateRefreshedAccessToken(userWithoutPassword);

    res.cookie(TokenName.refreshedToken, refreshedToken, {
      maxAge: 1000 * 60 * 60 * 24, //24 hours
      httpOnly: true,
      secure: config.ENVIRONMENT !== "DEVELOPMENT",
    });

    await activityLogController.addActivityLog({
      userId: +`${user?.id}`,
      action: `logged-in`,
    });

    return res.status(200).json({ [TokenName.accessToken]: accessToken });
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/auth/me:
 *   get:
 *     tags: [Authentication]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

authRoute.get("/me", verifyUser, async (req, res) => {
  try {
    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `viewed an account information`,
    });

    res.send(req.body);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/auth/logout:
 *   get:
 *     tags: [Authentication]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

authRoute.get("/logout", verifyUser, async (req, res) => {
  try {
    await activityLogController.addActivityLog({
      userId: req.body.id,
      action: `logged-out`,
    });

    res.clearCookie(TokenName.refreshedToken);
    return res.status(204).send("Logout success");
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

export default authRoute;
