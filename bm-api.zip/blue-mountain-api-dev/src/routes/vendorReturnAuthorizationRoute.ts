import vendorReturnAuthorizationController from "../controllers/vendorReturnAuthorizationController";
import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import {
  dateRangeFormat,
  validateFilter,
} from "../utils/validations/filterValidation";
import vendorReturnAuthorizationItemRoute from "./vendorReturnAuthorizationItemRoute";
import activityLogController from "../controllers/activityLogController";
import csv from "../utils/csv";
import {
  Subsidiary,
  Vendor,
  VendorReturnAuthorization,
  WarehouseLocation,
} from "@prisma/client";

const vendorReturnAuthorizationRoute = Router();

vendorReturnAuthorizationRoute.use(
  "/items",
  vendorReturnAuthorizationItemRoute
);

/**
 * @swagger
 * /api/vendors/returnAuthorizations:
 *   get:
 *     tags: [Vendors]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: csv
 *         description: Result as CSV (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: q
 *         description: Search (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: documentStatus
 *         description: Document status (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: warehouseLocationId
 *         description: Warehouse Location ID (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: itemFulFillmentNumber
 *         description: Item fulfillment number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: vendorName
 *         description: Vendor name (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: fulfillmentDate
 *         description: Filter by fulfillment date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: pullOutDate
 *         description: Filter by pull out date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: subsidiaryId
 *         description: SubsidiaryId (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: vraNumber
 *         description: VRA Number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: vraStatus
 *         description: VRA Status (optional)
 *         schema:
 *           type: status
 *       - in: query
 *         name: quantity
 *         description: Quantity (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: preparedBy
 *         description: Prepared By (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: totalAmount
 *         description: Total Amount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: isRead
 *         description: Read status (optional)
 *         schema:
 *           type: boolean
 *     responses:
 *       200:
 *         description: Success
 */

vendorReturnAuthorizationRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        csv: Joi.boolean(),
        totalAmount: Joi.number(),
        documetStatus: Joi.string(),
        warehouseLocation: Joi.string(),
        itemFulFillmentNumber: Joi.string(),
        warehouseLocationId: Joi.number(),
        isRead: Joi.boolean(),
        vendorName: Joi.string(),
        subsidiaryId: Joi.number(),
        vraStatus: Joi.string(),
        pullOutDate: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        fulfillmentDate: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
        quantity: Joi.number(),
        vraNumber: Joi.string(),
        preparedBy: Joi.string(),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: `viewed the vendor return authorizations`,
    });

    const vendorReturnAuthorizations: any =
      await vendorReturnAuthorizationController.getVendorReturnAuthorizations({
        ...req.query,
        user: req.user,
      });

    if (req.query.csv === "true") {
      type TData = VendorReturnAuthorization;
      const data: Array<
        TData & {
          subsidiary: Subsidiary;
          vendor: Vendor;
          warehouseLocation: WarehouseLocation;
          isRead: boolean;
        }
      > = vendorReturnAuthorizations.vendorReturnAuthorizations;

      const csvData = data.map((data) => {
        return {
          ["VRA #"]: data.vraNumber,
          ...(req.user.role !== "vendor" && {
            ["VENDOR NAME"]: data.vendor.name,
          }),
          ["LOCATION/WAREHOUSE"]: data.warehouseLocation.address,
          ["PULLOUT DATE"]: data?.pullOutDate,
          ["QUANTITY"]: data.quantity,
          ["TOTAL AMOUNT"]: +data.totalAmount,
          ["READ STATUS"]: data.isRead ? "read" : "unread",
          ["VRA STATUS"]: data.vraStatus,
        };
      });

      return csv({
        response: res,
        filename: "vendor_return_authorizations",
        data: csvData,
      });
    }

    return res.status(200).send(vendorReturnAuthorizations);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/vendors/returnAuthorizations/vraStatuses:
 *   get:
 *     tags: [Vendors,Statuses]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

vendorReturnAuthorizationRoute.get(
  "/vraStatuses",
  verifyUser,
  async (req, res) => {
    try {
      const statuses =
        await vendorReturnAuthorizationController.getVraStatuses();

      return res.status(200).send(statuses);
    } catch (error: any) {
      logger(error);
      return res.sendStatus(500);
    }
  }
);

/**
 * @swagger
 * /api/vendors/returnAuthorizations/{vendorReturnAuthorizationId}:
 *   get:
 *     tags: [Vendors]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: vendorReturnAuthorizationId
 *         description: Vendor Return Authorization ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

vendorReturnAuthorizationRoute.get(
  "/:vendorReturnAuthorizationId",
  verifyUser,
  async (req, res) => {
    try {
      await validateFilter(
        req.params,
        Joi.object({
          vendorReturnAuthorizationId: Joi.number(),
        })
      );

      await activityLogController.addActivityLog({
        userId: req.body.id,
        action: `viewed a vendor return authorization`,
      });

      const vendorReturnAuthorization =
        await vendorReturnAuthorizationController.getVendorReturnAuthorization({
          vendorReturnAuthorizationId: +req.params.vendorReturnAuthorizationId,
          userId: req.user.id,
          role: req.user.role
        });

      return res.status(200).send(vendorReturnAuthorization);
    } catch (error: any) {
      if (isValidationError(error)) return res.status(400).send(error.message);

      logger(error);
      return res.sendStatus(500);
    }
  }
);

// /**
//  * @swagger
//  * /api/vendors/returnAuthorizations/seed:
//  *   post:
//  *     tags: [Vendors]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// vendorReturnAuthorizationRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const vendorReturnAuthorizations =
//       await vendorReturnAuthorizationController.seedVendorReturnAuthorizations();

//     return res.status(201).send(vendorReturnAuthorizations);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default vendorReturnAuthorizationRoute;
