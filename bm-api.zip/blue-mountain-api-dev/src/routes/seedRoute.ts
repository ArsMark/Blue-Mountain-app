import { Router } from "express";
import billingController from "../controllers/billingController";
import billingPoController from "../controllers/billingPoController";
import debitCreditMemoController from "../controllers/debitCreditMemoController";
import departmentController from "../controllers/departmentController";
import itemController from "../controllers/itemController";
import itemFulfillmentController from "../controllers/itemFulfillmentController";
import itemFulfillmentItemController from "../controllers/itemFulfillmentItemController";
import itemReceiptController from "../controllers/itemReceiptController";
import itemReceiptItemsController from "../controllers/itemReceiptItemsController";
import notificationController from "../controllers/notificationController";
import paymentController from "../controllers/paymentController";
import paymentInvoiceController from "../controllers/paymentInvoiceController";
import purchaseOrderController from "../controllers/purchaseOrderController";
import purchaseOrderItemController from "../controllers/purchaseOrderItemController";
import subsidiaryController from "../controllers/subsidiaryController";
import vendorController from "../controllers/vendorController";
import vendorReturnAuthorizationController from "../controllers/vendorReturnAuthorizationController";
import vendorReturnAuthorizationItemController from "../controllers/vendorReturnAuthorizationItemController";
import warehouseLocationController from "../controllers/warehouseLocationController";
import config from "../utils/config";
import logger from "../utils/logger";

const seedRoute = Router();

/**
 * @swagger
 * /api/seeds:
 *   post:
 *     tags: [Seeders]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       201:
 *         description: Success
 */

seedRoute.post("/", async (req, res) => {
  if (config.ENVIRONMENT !== "DEVELOPMENT") {
    return res.sendStatus(405);
  }

  try {
    const subsidiaries = await subsidiaryController.seedSubsidiaries();
    const warehouseLocations =
      await warehouseLocationController.seedWarehouseLocation();
    const vendors = await vendorController.seedVendors();
    const payments = await paymentController.seedPayments();
    const billings = await billingController.seedBiillings();
    const items = await itemController.seedItems();
    const vendorReturnAuthorizations =
      await vendorReturnAuthorizationController.seedVendorReturnAuthorizations();
    const itemFulfillments =
      await itemFulfillmentController.seedItemFulfillments();
    const vendorReturnAuthorizationItems =
      await vendorReturnAuthorizationItemController.seedVendorReturnAuthorizationItems();
    const debitCreditMemos =
      await debitCreditMemoController.seedDebitCreditMemos();
    const billingPos = await billingPoController.seedBiillingPos();
    const paymentInvoices =
      await paymentInvoiceController.seedPaymentInvoices();
    const itemReceipts = await itemReceiptController.seedItemReceipts();
    const itemReceiptItems =
      await itemReceiptItemsController.seedItemReceiptItems();
    // const purchaseOrders = await purchaseOrderController.seedPurchaseOrders();
    const purchaseOrderItems =
      await purchaseOrderItemController.seedPurchaseOrderItems();
    const itemFulfillmentItems =
      await itemFulfillmentItemController.seedItemFulfillmentItems();
    const departments = await departmentController.seedDepartments();
    const notifications = await notificationController.seedNotifications();

    return res.status(201).send({
      notifications,
      departments,
      warehouseLocations,
      billings,
      items,
      subsidiaries,
      payments,
      vendors,
      billingPos,
      // purchaseOrders,
      purchaseOrderItems,
      paymentInvoices,
      itemReceipts,
      itemReceiptItems,
      itemFulfillments,
      itemFulfillmentItems,
      vendorReturnAuthorizations,
      vendorReturnAuthorizationItems,
      debitCreditMemos,
    });
  } catch (error) {
    logger(error);
    return res.sendStatus(500);
  }
});

export default seedRoute;
