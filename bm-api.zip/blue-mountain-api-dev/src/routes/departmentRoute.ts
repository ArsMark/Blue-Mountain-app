import { Router } from "express";
import Joi from "joi";
import logger from "../utils/logger";
import verifyUser from "../middlewares/verifyUser";
import { isValidationError } from "../utils/validations";
import { validateFilter } from "../utils/validations/filterValidation";
import departmentController from "../controllers/departmentController";
import verifyRole from "../middlewares/verifyRole";

const departmentRoute = Router();

/**
 * @swagger
 * /api/departments:
 *   get:
 *     tags: [Departments]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

departmentRoute.get("/", verifyUser, async (req, res) => {
  try {
    const departments = await departmentController.getDepartments();

    return res.status(200).send(departments);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/departments/{departmentId}:
 *   get:
 *     tags: [Departments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: departmentId
 *         description: Department ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

departmentRoute.get("/:departmentId", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.params,
      Joi.object({
        departmentId: Joi.number().required(),
      })
    );

    const department = await departmentController.getDepartment(
      +req.params.departmentId
    );

    return res.status(200).send(department);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/departments:
 *   post:
 *     tags: [Departments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               departmentName:
 *                 type: string
 *                 required: true
 *               departmentEmail:
 *                 type: string
 *                 required: true
 *     responses:
 *       201:
 *         description: Success
 */

departmentRoute.post(
  "/",
  verifyUser,
  verifyRole(["developer"]),
  async (req, res) => {
    try {
      const { departmentEmail, departmentName, role } = req.body;
      await validateFilter(
        { departmentName, departmentEmail, role },
        Joi.object({
          departmentName: Joi.string().required(),
          departmentEmail: Joi.string().email().required(),
          role: Joi.string().valid("admin").messages({
            "any.only": "Seeding failed, you must be an admin to continue",
          }),
        })
      );

      const department = await departmentController.addDepartment({
        name: departmentName,
        email: departmentEmail,
      });

      return res.status(201).send(department);
    } catch (error: any) {
      if (isValidationError(error)) return res.status(400).send(error.message);

      logger(error);
      return res.sendStatus(500);
    }
  }
);

/**
 * @swagger
 * /api/departments/init:
 *   post:
 *     tags: [Departments]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       201:
 *         description: Success
 */

departmentRoute.post("/init", verifyUser, async (req, res) => {
  try {
    const departments = await departmentController.seedDepartments();

    return res.status(201).send(departments);
  } catch (error) {
    logger(error);
    return res.sendStatus(500);
  }
});

export default departmentRoute;
