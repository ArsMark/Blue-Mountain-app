import { DebitCreditMemo, Subsidiary, Vendor } from "@prisma/client";
import { Router } from "express";
import Joi from "joi";
import activityLogController from "../controllers/activityLogController";
import creditMemoController from "../controllers/CreditMemoController";
import verifyUser from "../middlewares/verifyUser";
import csv from "../utils/csv";
import logger from "../utils/logger";
import { isValidationError } from "../utils/validations";
import {
  dateRangeFormat,
  validateFilter,
} from "../utils/validations/filterValidation";

const creditMemoRoute = Router();

/**
 * @swagger
 * /api/debitCreditMemos:
 *   get:
 *     tags: [Debit Credit Memos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: csv
 *         description: Result as CSV (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: q
 *         description: Search (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: page
 *         description: Show data in pagination (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: limit
 *         description: Show how many data to each page (optional, required if page is defined)
 *         schema:
 *           type: number
 *       - in: query
 *         name: sort
 *         description: Sort results (optional)
 *         schema:
 *           type: string
 *           pattern: ^(asc|desc)$
 *       - in: query
 *         name: total
 *         description: Total (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: status
 *         description: Status (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: checkAmount
 *         description: Check Amount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: postingType
 *         description: Posting Type (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: isRead
 *         description: Read Status (optional)
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: docDateRange
 *         description: Filter by document date from(yyyy-mm-dd),to(yyyy-mm-dd) (optional)
 *         schema:
 *           type: string
 *           pattern: ^[0-9]{4}-[0-9]{2}-[0-9]{2},[0-9]{4}-[0-9]{2}-[0-9]{2}$
 *       - in: query
 *         name: subsidiaryId
 *         description: SubsidiaryId (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: referenceNumber
 *         description: Rerefernce Number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: debitCreditMemoStatus
 *         description: Debit Credit Memo Status (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: preparedBy
 *         description: Prepared By (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: approvedBy
 *         description: Approved By (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: checkedBy
 *         description: Checked By (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: receivedBy
 *         description: Received By (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: billTo
 *         description: Bill To (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: billingAddress
 *         description: BillingAddress (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: documentNumber
 *         description: Document Number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: debitCreditMemoNumber
 *         description: Debit Credit Memo Number (optional)
 *         schema:
 *           type: string
 *       - in: query
 *         name: checkAmount
 *         description: Check Amount (optional)
 *         schema:
 *           type: number
 *       - in: query
 *         name: vendorName
 *         description: Vendor Name (optional)
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Success
 */

creditMemoRoute.get("/", verifyUser, async (req, res) => {
  try {
    await validateFilter(
      req.query,
      Joi.object({
        csv: Joi.boolean(),
        referenceNumber: Joi.string(),
        debitCreditMemoStatus: Joi.string(),
        debitCreditMemoNumber: Joi.string(),
        documentNumber: Joi.string(),
        vendorName: Joi.string(),
        particular: Joi.string(),
        preparedBy: Joi.string(),
        approvedBy: Joi.string(),
        checkedBy: Joi.string(),
        receivedBy: Joi.string(),
        billTo: Joi.string(),
        billingAddress: Joi.string(),
        total: Joi.number(),
        status: Joi.string(),
        checkNumber: Joi.number(),
        checkAmount: Joi.number(),
        postingType: Joi.string(),
        isRead: Joi.boolean(),
        subsidiaryId: Joi.number(),
        docDateRange: Joi.string().regex(
          dateRangeFormat,
          `"yyyy-mm-dd,yyyy-mm-dd"`
        ),
      })
    );

    await activityLogController.addActivityLog({
      userId: req.user.id,
      action: `viewed the debit and credit memos`,
    });

    const debitCreditMemos: any =
      await creditMemoController.getCreditMemos({
        ...req.query,
        user: req.user,
      });

    if (req.query.csv === "true") {
      type TData = DebitCreditMemo;
      const data: Array<
        TData & {
          subsidiary: Subsidiary;
          vendor: Vendor;
          isRead: boolean;
        }
      > = debitCreditMemos.debitCreditMemos;

      const csvData = data.map((data) => ({
        ["DM/CM #"]: data.debitCreditMemoNumber,
        ["POSTING TYPE"]: data.postingType,
        ...(req.user.role !== "vendor" && {
          ["VENDOR NAME"]: data.vendor.name,
        }),
        ["DOCUMENT DATE"]: data.documentDate,
        ["TOTAL"]: data.total,
        ["DM/CM STATUS"]: data.debitCreditMemoStatus,
        ["READ STATUS"]: data.isRead ? "read" : "unread",
      }));

      return csv({
        response: res,
        filename: "debit_credit_memos",
        data: csvData,
      });
    }

    return res.status(200).send(debitCreditMemos);
  } catch (error: any) {
    if (isValidationError(error)) return res.status(400).send(error.message);

    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/debitCreditMemos/statuses:
 *   get:
 *     tags: [Debit Credit Memos,Statuses]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

creditMemoRoute.get("/statuses", verifyUser, async (req, res) => {
  try {
    const statuses = await creditMemoController.getStatuses();

    return res.status(200).send(statuses);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/debitCreditMemos/postingTypes:
 *   get:
 *     tags: [Debit Credit Memos]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 */

creditMemoRoute.get("/posting-types", verifyUser, async (req, res) => {
  try {
    const postingTypes = await creditMemoController.getPostingTypes();

    return res.status(200).send(postingTypes);
  } catch (error: any) {
    logger(error);
    return res.sendStatus(500);
  }
});

/**
 * @swagger
 * /api/debitCreditMemos/{debitCreditMemoId}:
 *   get:
 *     tags: [Debit Credit Memos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: debitCreditMemoId
 *         description: Debit Credit Memo ID
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Success
 */

creditMemoRoute.get(
  "/:debitCreditMemoId",
  verifyUser,
  async (req, res) => {
    try {
      await validateFilter(
        req.params,
        Joi.object({
          debitCreditMemoId: Joi.number(),
        })
      );

      await activityLogController.addActivityLog({
        userId: req.user.id,
        action: `viewed a debit and credit memo`,
      });

      const debitCreditMemo =
        await creditMemoController.getCreditMemo({
          debitCreditMemoId: +req.params.debitCreditMemoId,
          userId: req.user.id,
          role: req.user.role
        });

      return res.status(200).send(debitCreditMemo);
    } catch (error: any) {
      if (isValidationError(error)) return res.status(400).send(error.message);

      logger(error);
      return res.sendStatus(500);
    }
  }
);

// /**
//  * @swagger
//  * /api/debitCreditMemos/seed:
//  *   post:
//  *     tags: [Seeders, Debit Credit Memos]
//  *     security:
//  *       - bearerAuth: []
//  *     responses:
//  *       201:
//  *         description: Success
//  */

// creditMemoRoute.post("/seed", verifyUser, async (req, res) => {
//   try {
//     const debitCreditMemos =
//       await creditMemoController.seedDebitCreditMemos();

//     return res.status(201).send(debitCreditMemos);
//   } catch (error) {
//     logger(error);
//     return res.sendStatus(500);
//   }
// });

export default creditMemoRoute;
