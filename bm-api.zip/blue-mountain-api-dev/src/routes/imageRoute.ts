import { Router } from "express";
import { validateFilter } from "../utils/validations/filterValidation";
import Joi from "joi";
import { isValidationError } from "../utils/validations";
import path from "path";
import verifyUser from "../middlewares/verifyUser";
import { existsSync } from "fs";
import { error } from "console";

const imageRoute = Router();

/**
 * @swagger
 * /api/images/{image}:
 *   get:
 *     tags: [Images]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: image
 *         required: true
 *         description: Image Path
 *         schema:
 *           type: string
 *           pattern: ^\/[a-zA-Z0-9_\-/]+(\.(jpg|jpeg|png))$
 *     responses:
 *       200:
 *         description: Success
 */

imageRoute.get("/", async (req, res) => {
  try {
    const { image } = req.query;

    await validateFilter(
      { image },
      Joi.object({
        image: Joi.string().regex(
          /^\/[a-zA-Z0-9_\-/]+(\.(jpg|jpeg|png))$/,
          "Image path must be a valid path e.g. /items/item-1.jpg"
        ),
      })
    );

    // image must always be no /assets/images on its path and should only start after the /assets/images e.g. /subsidiaries.png

    const imagePath = path.join(
      __dirname,
      `../../public/assets/images/${image}`
    );

    if (!existsSync(imagePath)) {
      const error = new Error("Image does not exist");
      error.name = "image";
      throw error;
    }

    res.sendFile(imagePath);
  } catch (error: any) {
    console.error(error);

    if (isValidationError(error) || error.name === "image")
      return res.status(400).send(error.message);

    res.sendStatus(500);
  }
});

export default imageRoute;
